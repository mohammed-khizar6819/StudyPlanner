package com.studyplan.app.di

import android.content.Context
import androidx.room.Room
import com.studyplan.app.data.db.AppDatabase
import com.studyplan.app.data.db.dao.*
import com.studyplan.app.data.repository.*
import com.studyplan.app.domain.repository.*
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): AppDatabase =
        Room.databaseBuilder(ctx, AppDatabase::class.java, AppDatabase.DATABASE_NAME)
            .fallbackToDestructiveMigration()   // Phase 2 → production migrations added later
            .build()

    // ── DAOs ─────────────────────────────────────────────────────
    @Provides fun provideSubjectDao(db: AppDatabase)       = db.subjectDao()
    @Provides fun provideLectureDao(db: AppDatabase)       = db.lectureDao()
    @Provides fun provideScheduleEntryDao(db: AppDatabase) = db.scheduleEntryDao()
    @Provides fun provideNoteDao(db: AppDatabase)          = db.noteDao()
    @Provides fun provideSessionLogDao(db: AppDatabase)    = db.sessionLogDao()
    @Provides fun provideSettingsDao(db: AppDatabase)      = db.settingsDao()
    @Provides fun provideMetaDao(db: AppDatabase)          = db.metaDao()
    @Provides fun provideSavedPlanDao(db: AppDatabase)     = db.savedPlanDao()
}

/** Separate @Binds module — binds interface → implementation */
@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {
    @Binds @Singleton abstract fun bindSubjectRepo(impl: SubjectRepositoryImpl): SubjectRepository
    @Binds @Singleton abstract fun bindLectureRepo(impl: LectureRepositoryImpl): LectureRepository
    @Binds @Singleton abstract fun bindScheduleRepo(impl: ScheduleRepositoryImpl): ScheduleRepository
    @Binds @Singleton abstract fun bindNoteRepo(impl: NoteRepositoryImpl): NoteRepository
    @Binds @Singleton abstract fun bindSessionLogRepo(impl: SessionLogRepositoryImpl): SessionLogRepository
    @Binds @Singleton abstract fun bindSettingsRepo(impl: SettingsRepositoryImpl): SettingsRepository
    @Binds @Singleton abstract fun bindMetaRepo(impl: MetaRepositoryImpl): MetaRepository
    @Binds @Singleton abstract fun bindSavedPlanRepo(impl: SavedPlanRepositoryImpl): SavedPlanRepository
}
