@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyplan.app.ui.theme.BodyFontFamily
import com.studyplan.app.ui.theme.StudyPlanRadius
import com.studyplan.app.ui.theme.studyColors

// ═══════════════════════════════════════════════════════════════════
//  ALERT BANNER — info / warn / error variants
//  Matches HTML .alert, .alert-warn, .alert-error, .alert-info
// ═══════════════════════════════════════════════════════════════════

enum class AlertType { INFO, WARN, ERROR }

@Composable
fun AlertBanner(
    type:     AlertType,
    message:  String,
    modifier: Modifier    = Modifier,
    action:   (@Composable () -> Unit)? = null,
) {
    val colors = MaterialTheme.studyColors
    val (bg, border, fg, icon) = when (type) {
        AlertType.INFO  -> Quadruple(
            colors.primaryL, colors.focusBorder, colors.text,
            Icons.Outlined.CalendarMonth,
        )
        AlertType.WARN  -> Quadruple(
            colors.alertWarnBg, colors.borderStrong, colors.alertWarnText,
            Icons.Outlined.Warning,
        )
        AlertType.ERROR -> Quadruple(
            colors.alertErrorBg, colors.red.copy(alpha = 0.3f), colors.red,
            Icons.Outlined.ErrorOutline,
        )
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(StudyPlanRadius.md))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(StudyPlanRadius.md))
            .padding(horizontal = 12.dp, vertical = 10.dp),
    ) {
        Icon(icon, contentDescription = null, tint = fg,
            modifier = Modifier.size(14.dp).align(Alignment.Top).padding(top = 1.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            text       = message,
            fontFamily = BodyFontFamily,
            fontWeight = FontWeight.Normal,
            fontSize   = 13.sp,
            color      = fg,
            lineHeight = 20.sp,
            modifier   = Modifier.weight(1f),
        )
        if (action != null) {
            Spacer(Modifier.width(8.dp))
            action()
        }
    }
}

/** Rich alert with bold segments — built via AnnotatedString */
@Composable
fun AlertBannerRich(
    type:     AlertType,
    parts:    List<AlertPart>,  // alternating normal/bold text
    modifier: Modifier = Modifier,
    action:   (@Composable () -> Unit)? = null,
) {
    val colors = MaterialTheme.studyColors
    val fg = when (type) {
        AlertType.INFO  -> colors.text
        AlertType.WARN  -> colors.alertWarnText
        AlertType.ERROR -> colors.red
    }
    val annotated = buildAnnotatedString {
        parts.forEach { part ->
            if (part.bold) withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = fg)) { append(part.text) }
            else append(part.text)
        }
    }
    AlertBanner(
        type     = type,
        message  = annotated.toString(),
        modifier = modifier,
        action   = action,
    )
}

data class AlertPart(val text: String, val bold: Boolean = false)

/** Simple tuple for destructuring */
private data class Quadruple<A,B,C,D>(val a: A, val b: B, val c: C, val d: D)
private operator fun <A,B,C,D> Quadruple<A,B,C,D>.component1() = a
private operator fun <A,B,C,D> Quadruple<A,B,C,D>.component2() = b
private operator fun <A,B,C,D> Quadruple<A,B,C,D>.component3() = c
private operator fun <A,B,C,D> Quadruple<A,B,C,D>.component4() = d
