package com.studyplan.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.studyplan.app.domain.model.SavedPlan

@Entity(tableName = "saved_plans")
data class SavedPlanEntity(
    @PrimaryKey val id:   String,
    val name:         String,
    val savedAt:      String,
    val subjectCount: Int,
    val lectureCount: Int,
    val snapshotJson: String,
) {
    fun toDomain() = SavedPlan(id, name, savedAt, subjectCount, lectureCount, snapshotJson)
    companion object {
        fun fromDomain(p: SavedPlan) = SavedPlanEntity(p.id, p.name, p.savedAt,
            p.subjectCount, p.lectureCount, p.snapshotJson)
    }
}
