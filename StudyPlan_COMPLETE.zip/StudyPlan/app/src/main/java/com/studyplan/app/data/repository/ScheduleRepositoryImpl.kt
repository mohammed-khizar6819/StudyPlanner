package com.studyplan.app.data.repository
import com.studyplan.app.data.db.dao.ScheduleEntryDao
import com.studyplan.app.data.db.entity.ScheduleEntryEntity
import com.studyplan.app.domain.model.ScheduleEntry
import com.studyplan.app.domain.model.ScheduleEntryStatus
import com.studyplan.app.domain.repository.ScheduleRepository
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ScheduleRepositoryImpl @Inject constructor(
    private val dao: ScheduleEntryDao,
) : ScheduleRepository {
    override fun observeForDate(date: String)               = dao.observeForDate(date).map { it.map { e -> e.toDomain() } }
    override suspend fun getForDate(date: String)           = dao.getForDate(date).map { it.toDomain() }
    override suspend fun getInRange(s: String, e: String)   = dao.getInRange(s, e).map { it.toDomain() }
    override suspend fun getBeforeDate(date: String)        = dao.getBeforeDate(date).map { it.toDomain() }
    override suspend fun getForLecture(lid: String)         = dao.getForLecture(lid).map { it.toDomain() }
    override suspend fun getDatesFrom(start: String)        = dao.getDatesFrom(start)
    override suspend fun insert(e: ScheduleEntry)           = dao.insert(ScheduleEntryEntity.fromDomain(e))
    override suspend fun insertAll(entries: List<ScheduleEntry>) = dao.insertAll(entries.map { ScheduleEntryEntity.fromDomain(it) })
    override suspend fun updateCompletion(id: Long, completed: Long, status: ScheduleEntryStatus) =
        dao.updateCompletion(id, completed, status)
    override suspend fun deleteForDate(date: String)        = dao.deleteForDate(date)
    override suspend fun deleteFromDate(date: String)       = dao.deleteFromDate(date)
    override suspend fun deletePastIncompleteForLectures(ids: List<String>, today: String) =
        dao.deletePastIncompleteForLectures(ids, today)
    override suspend fun deleteAll()                        = dao.deleteAll()
}
