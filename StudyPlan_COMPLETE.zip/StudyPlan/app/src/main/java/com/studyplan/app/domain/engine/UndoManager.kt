package com.studyplan.app.domain.engine

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Port of HTML UndoManager.
 * Stores one pending undo action with a 5.5-second auto-expiry window.
 * Exposes a StateFlow so the UI can show/hide the undo toast reactively.
 */
@Singleton
class UndoManager @Inject constructor() {

    data class PendingAction(val label: String, val undo: suspend () -> Unit)

    private val _pending = MutableStateFlow<PendingAction?>(null)
    val pending: StateFlow<PendingAction?> = _pending.asStateFlow()

    private var expiryJob: Job? = null

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    /**
     * Register a new undo action. Cancels any previous pending action.
     * Auto-expires after 5500ms (matches HTML 5.5s timeout).
     */
    fun register(label: String, undo: suspend () -> Unit) {
        expiryJob?.cancel()
        _pending.value = PendingAction(label, undo)
        expiryJob = scope.launch {
            delay(5_500)
            _pending.value = null
        }
    }

    /**
     * Execute the pending undo action immediately.
     * @return true if an action was executed, false if none pending.
     */
    suspend fun execute(): Boolean {
        val action = _pending.value ?: return false
        expiryJob?.cancel()
        _pending.value = null
        action.undo()
        return true
    }

    /** Dismiss without executing (e.g. user navigates away) */
    fun dismiss() {
        expiryJob?.cancel()
        _pending.value = null
    }
}
