package com.studyplan.app.domain.repository
import com.studyplan.app.domain.model.AppMeta
import kotlinx.coroutines.flow.Flow

interface MetaRepository {
    fun observe(): Flow<AppMeta?>
    suspend fun get(): AppMeta?
    suspend fun upsert(meta: AppMeta)
    suspend fun updateLastBuiltDate(date: String)
    suspend fun setOnboarded()
    suspend fun deleteAll()
}
