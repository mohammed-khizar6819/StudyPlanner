@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.animation

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.runtime.*
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt

// ═══════════════════════════════════════════════════════════════════
//  ANIMATION CONSTANTS — exact port of HTML CSS @keyframes
// ═══════════════════════════════════════════════════════════════════

/** pageFade: opacity 0→1 + translateY 6dp→0. Used on screen entry. */
const val PAGE_FADE_MS   = 300
/** cardUp: opacity 0→1 + translateY 10dp→0. Used on card stagger. */
const val CARD_UP_MS     = 280
/** modalUp: opacity 0→1 + scale 0.97→1 + translateY 8dp→0 */
const val MODAL_UP_MS    = 200
/** toastSlide: opacity 0→1 + translateY 12dp→0 */
const val TOAST_SLIDE_MS = 220
/** Theme crossfade */
const val THEME_FADE_MS  = 180
/** Progress bar fill animation */
const val PROGRESS_MS    = 600
/** Counter animation (ease-out cubic, 900ms) */
const val COUNTER_MS     = 900

// ── Card stagger delays (matches HTML nth-child delays) ───────────
val CARD_STAGGER_DELAYS = intArrayOf(0, 40, 80, 120, 160, 200, 240, 280)
val TABLE_ROW_DELAYS    = intArrayOf(15, 30, 45, 60, 75, 90, 105, 120)

// ── Easing curves ────────────────────────────────────────────────
val SpringDecay    = spring<Float>(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMedium)
val EaseOutCubic   = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)   // cubic-bezier(0.22,1,0.36,1)
val EaseOut        = CubicBezierEasing(0f, 0f, 0.2f, 1f)

/** pageFade enter transition used by NavHost */
fun pageFadeEnter(): EnterTransition =
    fadeIn(animationSpec = tween(PAGE_FADE_MS, easing = EaseOut)) +
    slideIn(animationSpec = tween(PAGE_FADE_MS, easing = EaseOut)) { IntOffset(0, 18) }

/** pageFade exit transition used by NavHost */
fun pageFadeExit(): ExitTransition =
    fadeOut(animationSpec = tween(PAGE_FADE_MS))

/** cardUp: staggered fade+slide-up for list items */
fun cardUpEnter(delayMs: Int = 0): EnterTransition =
    fadeIn(animationSpec  = tween(CARD_UP_MS, delayMillis = delayMs, easing = EaseOutCubic)) +
    slideIn(animationSpec = tween(CARD_UP_MS, delayMillis = delayMs, easing = EaseOutCubic)) {
        IntOffset(0, 28)
    }

/** modalUp: dialog entry */
fun modalUpEnter(): EnterTransition =
    fadeIn(animationSpec   = tween(MODAL_UP_MS)) +
    scaleIn(initialScale   = 0.97f, animationSpec = tween(MODAL_UP_MS)) +
    slideIn(animationSpec  = tween(MODAL_UP_MS)) { IntOffset(0, 20) }

fun modalUpExit(): ExitTransition =
    fadeOut(animationSpec  = tween(MODAL_UP_MS)) +
    scaleOut(targetScale   = 0.97f, animationSpec = tween(MODAL_UP_MS))

/** Animates a float value from 0 to [target] — drives progress bars */
@Composable
fun animatedProgress(target: Float, delayMs: Int = 0): Float {
    var triggered by remember { mutableStateOf(false) }
    LaunchedEffect(target) { triggered = true }
    val animValue by animateFloatAsState(
        targetValue   = if (triggered) target else 0f,
        animationSpec = tween(PROGRESS_MS, delayMillis = delayMs, easing = EaseOut),
        label         = "progress",
    )
    return animValue
}

/**
 * Animates an integer counter from 0 → [target] with ease-out cubic.
 * Matches HTML UI.animateCounters() — 900ms duration.
 */
@Composable
fun animatedCounter(target: Int): Int {
    var value by remember { mutableIntStateOf(0) }
    LaunchedEffect(target) {
        val startMs  = System.currentTimeMillis()
        val duration = COUNTER_MS.toLong()
        while (true) {
            val elapsed  = System.currentTimeMillis() - startMs
            val progress = (elapsed.toFloat() / duration).coerceIn(0f, 1f)
            // ease-out cubic: 1 - (1-t)^3
            val eased = 1f - (1f - progress) * (1f - progress) * (1f - progress)
            value = (eased * target).roundToInt()
            if (progress >= 1f) break
            kotlinx.coroutines.delay(16)
        }
        value = target
    }
    return value
}
