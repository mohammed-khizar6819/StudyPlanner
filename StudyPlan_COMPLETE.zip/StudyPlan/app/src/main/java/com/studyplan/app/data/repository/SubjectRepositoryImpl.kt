package com.studyplan.app.data.repository
import com.studyplan.app.data.db.dao.SubjectDao
import com.studyplan.app.data.db.entity.SubjectEntity
import com.studyplan.app.domain.model.Subject
import com.studyplan.app.domain.repository.SubjectRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SubjectRepositoryImpl @Inject constructor(
    private val dao: SubjectDao,
) : SubjectRepository {
    override fun observeAll() = dao.observeAll().map { it.map { e -> e.toDomain() } }
    override suspend fun getAll()           = dao.getAll().map { it.toDomain() }
    override suspend fun getById(id: String) = dao.getById(id)?.toDomain()
    override suspend fun insert(s: Subject)  = dao.insert(SubjectEntity.fromDomain(s))
    override suspend fun insertAll(list: List<Subject>) = dao.insertAll(list.map { SubjectEntity.fromDomain(it) })
    override suspend fun update(s: Subject)  = dao.update(SubjectEntity.fromDomain(s))
    override suspend fun delete(id: String)  = dao.deleteById(id)
    override suspend fun deleteAll()         = dao.deleteAll()
}
