package com.studyplan.app.data.db.dao

import androidx.room.*
import com.studyplan.app.data.db.entity.SavedPlanEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedPlanDao {
    @Query("SELECT * FROM saved_plans ORDER BY savedAt DESC")
    fun observeAll(): Flow<List<SavedPlanEntity>>

    @Query("SELECT * FROM saved_plans ORDER BY savedAt DESC")
    suspend fun getAll(): List<SavedPlanEntity>

    @Query("SELECT * FROM saved_plans WHERE id = :id")
    suspend fun getById(id: String): SavedPlanEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(plan: SavedPlanEntity)

    @Query("DELETE FROM saved_plans WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM saved_plans")
    suspend fun deleteAll()
}
