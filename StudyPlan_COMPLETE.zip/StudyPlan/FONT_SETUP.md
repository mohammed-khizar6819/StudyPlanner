# Font Setup Instructions

## Required Font Files

Place all `.ttf` files in:
```
app/src/main/res/font/
```

---

## Option A — Download from Google Fonts (Recommended)

### 1. Bricolage Grotesque
URL: https://fonts.google.com/specimen/Bricolage+Grotesque

Download and rename files exactly as shown:

| Download name | Save as |
|---|---|
| BricolageGrotesque[opsz,wght].ttf → subset Regular (400) | `bricolage_grotesque_regular.ttf` |
| BricolageGrotesque[opsz,wght].ttf → subset Medium (500) | `bricolage_grotesque_medium.ttf` |
| BricolageGrotesque[opsz,wght].ttf → subset SemiBold (600) | `bricolage_grotesque_semibold.ttf` |
| BricolageGrotesque[opsz,wght].ttf → subset Bold (700) | `bricolage_grotesque_bold.ttf` |
| BricolageGrotesque[opsz,wght].ttf → subset ExtraBold (800) | `bricolage_grotesque_extrabold.ttf` |

> Bricolage Grotesque is a variable font. In Android Studio you can use the
> variable font directly — duplicate the file 5 times with the names above,
> or use the Downloadable Fonts API (Option B).

### 2. Figtree
URL: https://fonts.google.com/specimen/Figtree

| Download name | Save as |
|---|---|
| Figtree-Light.ttf (300) | `figtree_light.ttf` |
| Figtree-Regular.ttf (400) | `figtree_regular.ttf` |
| Figtree-Medium.ttf (500) | `figtree_medium.ttf` |
| Figtree-SemiBold.ttf (600) | `figtree_semibold.ttf` |
| Figtree-Bold.ttf (700) | `figtree_bold.ttf` |

### 3. JetBrains Mono
URL: https://fonts.google.com/specimen/JetBrains+Mono

| Download name | Save as |
|---|---|
| JetBrainsMono-Regular.ttf (400) | `jetbrains_mono_regular.ttf` |
| JetBrainsMono-Medium.ttf (500) | `jetbrains_mono_medium.ttf` |

---

## Option B — Android Studio Downloadable Fonts API (No bundling needed)

This avoids adding ~1–2 MB of font files to the APK. Fonts are downloaded
from Google at first run and cached on device.

### Steps in Android Studio:
1. Open `res/font/` in the Resource Manager
2. Click `+` → `More resources` → `Font`
3. Search for each font name
4. Select weights needed → click OK
5. Android Studio generates `font_certs.xml` and `preloaded_fonts.xml` automatically

Then update `Type.kt` to use the generated `FontFamily` references instead of
the manually defined ones.

### Alternatively — use `res/font/*.xml` descriptors:

Example `res/font/figtree_regular.xml`:
```xml
<?xml version="1.0" encoding="utf-8"?>
<font-family xmlns:app="http://schemas.android.com/apk/res-auto"
    app:fontProviderAuthority="com.google.android.gms.fonts"
    app:fontProviderPackage="com.google.android.gms"
    app:fontProviderQuery="Figtree"
    app:fontProviderCerts="@array/com_google_android_gms_fonts_certs">
</font-family>
```

---

## Final File List in `res/font/`

```
res/font/
├── bricolage_grotesque_regular.ttf
├── bricolage_grotesque_medium.ttf
├── bricolage_grotesque_semibold.ttf
├── bricolage_grotesque_bold.ttf
├── bricolage_grotesque_extrabold.ttf
├── figtree_light.ttf
├── figtree_regular.ttf
├── figtree_medium.ttf
├── figtree_semibold.ttf
├── figtree_bold.ttf
├── jetbrains_mono_regular.ttf
└── jetbrains_mono_medium.ttf
```

> **Important:** Android resource file names must be lowercase with underscores only.
> Do NOT use hyphens or spaces in the filename.
