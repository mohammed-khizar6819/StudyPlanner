package com.studyplan.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.studyplan.app.worker.MidnightRebuildScheduler
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class StudyPlanApplication : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory:       HiltWorkerFactory
    @Inject lateinit var midnightScheduler:   MidnightRebuildScheduler

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        // Schedule midnight rebuild (KEEP — no-op if already registered)
        midnightScheduler.schedule()
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(
            CHANNEL_DAILY_REMINDER, "Daily Study Reminder",
            NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Reminds you to start your daily study session"
        })
        nm.createNotificationChannel(NotificationChannel(
            CHANNEL_STUDY_ALARM, "Study Alarm",
            NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Alarm notification at your set study time"
        })
    }

    companion object {
        const val CHANNEL_DAILY_REMINDER = "daily_reminder"
        const val CHANNEL_STUDY_ALARM    = "study_alarm"
    }
}
