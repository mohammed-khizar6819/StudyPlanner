package com.studyplan.app.domain.repository
import com.studyplan.app.domain.model.Lecture
import com.studyplan.app.domain.model.LectureStatus
import kotlinx.coroutines.flow.Flow

interface LectureRepository {
    fun observeAll(): Flow<List<Lecture>>
    suspend fun getAll(): List<Lecture>
    suspend fun getBySubject(subjectId: String): List<Lecture>
    fun observeBySubject(subjectId: String): Flow<List<Lecture>>
    suspend fun getById(id: String): Lecture?
    suspend fun getByStatus(status: LectureStatus): List<Lecture>
    suspend fun getPendingAndPartial(): List<Lecture>
    suspend fun maxSequenceForSubject(subjectId: String): Int
    suspend fun insert(lecture: Lecture)
    suspend fun insertAll(lectures: List<Lecture>)
    suspend fun update(lecture: Lecture)
    suspend fun updateProgress(lecture: Lecture)
    suspend fun delete(id: String)
    suspend fun deleteBySubject(subjectId: String)
    suspend fun deleteAll()
}
