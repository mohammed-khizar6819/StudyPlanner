package com.studyplan.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studyplan.app.ui.onboarding.OnboardingScreen
import com.studyplan.app.ui.onboarding.OnboardingViewModel
import com.studyplan.app.ui.scaffold.AppScaffold
import com.studyplan.app.ui.scaffold.ThemeViewModel
import com.studyplan.app.ui.theme.StudyPlanTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    private val themeVm:     ThemeViewModel     by viewModels()
    private val onboardingVm: OnboardingViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)

        // Keep splash while theme + onboarding state are loading
        splash.setKeepOnScreenCondition {
            themeVm.isLoading.value || onboardingVm.showOnboarding.value == null
        }

        enableEdgeToEdge()

        setContent {
            val isDark          by themeVm.isDarkTheme.collectAsStateWithLifecycle()
            val showOnboarding  by onboardingVm.showOnboarding.collectAsStateWithLifecycle()

            StudyPlanTheme(darkTheme = isDark) {
                when (showOnboarding) {
                    null  -> Unit  // still loading — splash is visible
                    true  -> {
                        // Show onboarding wizard
                        OnboardingScreen(
                            onComplete = { name, code, start, deadline, hours, buffer ->
                                onboardingVm.completeOnboarding(
                                    name, code, start, deadline, hours, buffer)
                            },
                        )
                    }
                    false -> {
                        // Normal app
                        AppScaffold(
                            isDarkTheme   = isDark,
                            onThemeToggle = { themeVm.toggleTheme() },
                        )
                    }
                }
            }
        }
    }
}
