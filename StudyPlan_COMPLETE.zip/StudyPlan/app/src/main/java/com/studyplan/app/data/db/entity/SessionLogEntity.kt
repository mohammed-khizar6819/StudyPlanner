package com.studyplan.app.data.db.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.studyplan.app.domain.model.SessionLog

@Entity(
    tableName = "session_logs",
    indices   = [Index("date"), Index("lectureId")],
)
data class SessionLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date:      String,
    val hour:      Int,
    val seconds:   Long,
    val lectureId: String,
    val subjectId: String,
) {
    fun toDomain() = SessionLog(id, date, hour, seconds, lectureId, subjectId)
    companion object {
        fun fromDomain(l: SessionLog) =
            SessionLogEntity(l.id, l.date, l.hour, l.seconds, l.lectureId, l.subjectId)
    }
}
