package com.studyplan.app.domain.model

/**
 * App metadata — mirrors the HTML meta object.
 * Single-row table in Room.
 */
data class AppMeta(
    val initialized:        Boolean,
    val version:            Int,            // schema version (5 in HTML)
    val lastBuiltDate:      String,         // YYYY-MM-DD of last buildSchedule
    val onboarded:          Boolean,
    val achievedMilestones: List<String>,   // milestone IDs already shown
)
