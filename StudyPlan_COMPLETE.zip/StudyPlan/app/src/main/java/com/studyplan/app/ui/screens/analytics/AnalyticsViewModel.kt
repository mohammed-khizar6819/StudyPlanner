@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.analytics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studyplan.app.domain.engine.*
import com.studyplan.app.domain.model.SessionLog
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AnalyticsUiState(
    val isLoading:       Boolean       = true,
    val weekly:          WeeklyStats   = WeeklyStats.empty(),
    val overall:         AppStats      = AppStats.empty(),
    val consistency:     ConsistencyScore.Result = ConsistencyScore.Result(0, "—", "green"),
    val sessionLogs:     List<SessionLog> = emptyList(),
)

@HiltViewModel
class AnalyticsViewModel @Inject constructor(
    private val statsEngine:       StatsEngine,
    private val consistencyScore:  ConsistencyScore,
    private val reportCard:        ReportCard,
) : ViewModel() {

    private val _state = MutableStateFlow(AnalyticsUiState())
    val state: StateFlow<AnalyticsUiState> = _state.asStateFlow()

    private val _shareText = MutableSharedFlow<String>()
    val shareText: SharedFlow<String> = _shareText.asSharedFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            val weekly      = statsEngine.getWeeklyStats()
            val overall     = statsEngine.getStats()
            val consistency = consistencyScore.compute()
            _state.update {
                it.copy(
                    isLoading    = false,
                    weekly       = weekly,
                    overall      = overall,
                    consistency  = consistency,
                    sessionLogs  = weekly.sessionLogs,
                )
            }
        }
    }

    fun shareReport() {
        viewModelScope.launch {
            val text = reportCard.formatAsText()
            _shareText.emit(text)
        }
    }
}
