package com.studyplan.app.data.repository
import com.studyplan.app.data.db.dao.SessionLogDao
import com.studyplan.app.data.db.entity.SessionLogEntity
import com.studyplan.app.domain.model.SessionLog
import com.studyplan.app.domain.repository.SessionLogRepository
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SessionLogRepositoryImpl @Inject constructor(
    private val dao: SessionLogDao,
) : SessionLogRepository {
    override suspend fun getAll()                = dao.getAll().map { it.toDomain() }
    override suspend fun insert(log: SessionLog) = dao.insert(SessionLogEntity.fromDomain(log)).let {}
    override suspend fun insertAll(list: List<SessionLog>) = dao.insertAll(list.map { SessionLogEntity.fromDomain(it) })
    override suspend fun pruneToLimit(maxCount: Int) {
        val count = dao.count()
        if (count > maxCount) dao.pruneOldest(count - maxCount)
    }
    override suspend fun deleteAll() = dao.deleteAll()
}
