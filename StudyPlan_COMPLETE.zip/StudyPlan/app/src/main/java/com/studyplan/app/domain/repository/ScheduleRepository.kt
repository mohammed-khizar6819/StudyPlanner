package com.studyplan.app.domain.repository
import com.studyplan.app.domain.model.ScheduleEntry
import com.studyplan.app.domain.model.ScheduleEntryStatus
import kotlinx.coroutines.flow.Flow

interface ScheduleRepository {
    fun observeForDate(date: String): Flow<List<ScheduleEntry>>
    suspend fun getForDate(date: String): List<ScheduleEntry>
    suspend fun getInRange(start: String, end: String): List<ScheduleEntry>
    suspend fun getBeforeDate(date: String): List<ScheduleEntry>
    suspend fun getForLecture(lectureId: String): List<ScheduleEntry>
    suspend fun getDatesFrom(start: String): List<String>
    suspend fun insert(entry: ScheduleEntry): Long
    suspend fun insertAll(entries: List<ScheduleEntry>)
    suspend fun updateCompletion(id: Long, completed: Long, status: ScheduleEntryStatus)
    suspend fun deleteForDate(date: String)
    suspend fun deleteFromDate(date: String)
    suspend fun deletePastIncompleteForLectures(lectureIds: List<String>, today: String)
    suspend fun deleteAll()
}
