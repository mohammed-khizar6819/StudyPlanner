package com.studyplan.app.domain.model

/**
 * Domain model — mirrors the HTML lecture object exactly.
 */
data class Lecture(
    val id:           String,
    val subjectId:    String,
    val sequence:     Int,          // ordering within subject
    val lectureNum:   String,       // display number e.g. "61" or "01"
    val name:         String,
    val duration:     Long,         // total duration in seconds
    val remaining:    Long,         // seconds left to study
    val status:       LectureStatus,
    val completedOn:  String?,      // YYYY-MM-DD or null
    val todayStudied: Long,         // seconds studied today (replace-semantics)
    val todayDate:    String?,      // date of todayStudied, or null
    val chapter:      String,       // chapter / topic label
    val tags:         List<LectureTag>,
    val difficulty:   LectureDifficulty,
)
