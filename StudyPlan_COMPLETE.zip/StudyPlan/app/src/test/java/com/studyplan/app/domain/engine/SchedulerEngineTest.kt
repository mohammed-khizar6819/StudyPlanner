package com.studyplan.app.domain.engine

import com.studyplan.app.domain.model.*
import org.junit.Assert.*
import org.junit.Test

/**
 * Unit tests for SchedulerEngine pure-logic helpers.
 * Repository-dependent methods (buildSchedule, getTodayPlan, etc.)
 * are covered by integration tests using Room in-memory DB.
 */
class SchedulerEngineTest {

    // ── QueueItem mutation ────────────────────────────────────────

    @Test fun `QueueItem remaining decrements correctly`() {
        val item = SchedulerEngine.QueueItem("lec_1", 3600L, false, false)
        item.remaining -= 1800L
        assertEquals(1800L, item.remaining)
    }

    @Test fun `QueueItem remaining can reach zero`() {
        val item = SchedulerEngine.QueueItem("lec_1", 1800L, false, false)
        item.remaining -= 1800L
        assertEquals(0L, item.remaining)
        assertTrue(item.remaining <= 0)
    }

    // ── TimeUtils integration via engine helpers ───────────────────

    @Test fun `buffer day check - Sunday excluded`() {
        val bufferDay = 0  // Sunday
        val sunday    = "2024-01-07"
        assertEquals(bufferDay, TimeUtils.dayOfWeek(sunday))
    }

    @Test fun `vacation date check`() {
        val vacations = listOf("2024-06-15", "2024-07-04")
        assertTrue(vacations.contains("2024-06-15"))
        assertFalse(vacations.contains("2024-06-16"))
    }

    @Test fun `exam lock check - N days before deadline`() {
        val deadline    = "2024-07-01"
        val examLockDays = 7
        val tooClose    = "2024-06-28"  // 3 days before → locked
        val safe        = "2024-06-20"  // 11 days before → ok

        val daysToDeadlineFromClose = TimeUtils.diffDays(tooClose, deadline)
        val daysToDeadlineFromSafe  = TimeUtils.diffDays(safe, deadline)

        assertTrue(daysToDeadlineFromClose < examLockDays)
        assertFalse(daysToDeadlineFromSafe < examLockDays)
    }

    // ── Intensity ramp calculation ────────────────────────────────

    @Test fun `ramp multiplier is 1 at start date`() {
        val startDate = "2024-01-01"
        val endDate   = "2024-06-01"
        val date      = startDate
        val totalDays = TimeUtils.diffDays(startDate, endDate).toDouble()
        val elapsed   = 0.0
        val t         = (elapsed / totalDays).coerceIn(0.0, 1.0)
        val baseHours = 4.0
        val peakHours = 8.0
        val rampHours = baseHours + (peakHours - baseHours) * t
        assertEquals(4.0, rampHours, 0.001)
    }

    @Test fun `ramp multiplier is max at end date`() {
        val startDate = "2024-01-01"
        val endDate   = "2024-06-01"
        val totalDays = TimeUtils.diffDays(startDate, endDate).toDouble()
        val elapsed   = totalDays
        val t         = (elapsed / totalDays).coerceIn(0.0, 1.0)
        val baseHours = 4.0
        val peakHours = 8.0
        val rampHours = baseHours + (peakHours - baseHours) * t
        assertEquals(8.0, rampHours, 0.001)
    }

    @Test fun `ramp multiplier is midpoint at halfway`() {
        val startDate = "2024-01-01"
        val endDate   = "2024-07-01"  // ~182 days
        val totalDays = TimeUtils.diffDays(startDate, endDate).toDouble()
        val elapsed   = totalDays / 2
        val t         = elapsed / totalDays
        val rampHours = 4.0 + (8.0 - 4.0) * t
        assertEquals(6.0, rampHours, 0.1)
    }

    // ── Partial complete replace-semantics ────────────────────────

    @Test fun `replace semantics - new amount replaces old`() {
        val duration    = 7200L  // 2h lecture
        val prevStudied = 1800L  // 30m logged before
        val newLogged   = 3600L  // now logging 1h

        // Restore: remaining was (duration - prevStudied) before
        val restoredRem = minOf(duration, (duration - prevStudied) + prevStudied)
        val done        = minOf(newLogged, restoredRem)
        val newRem      = maxOf(0L, restoredRem - done)

        assertEquals(3600L, done)
        assertEquals(3600L, newRem)  // 2h total - 1h logged = 1h remaining
    }

    @Test fun `replace semantics - second log larger than first`() {
        val duration    = 7200L
        val prevStudied = 1800L
        val newLogged   = 5400L  // logging 1.5h > previous 0.5h

        val restoredRem = minOf(duration, (duration - prevStudied) + prevStudied)
        val done        = minOf(newLogged, restoredRem)
        val newRem      = maxOf(0L, restoredRem - done)

        assertEquals(5400L, done)
        assertEquals(1800L, newRem)
    }

    @Test fun `replace semantics - logging full duration marks complete`() {
        val duration    = 3600L
        val prevStudied = 0L
        val newLogged   = 3600L

        val restoredRem = minOf(duration, (duration - prevStudied) + prevStudied)
        val done        = minOf(newLogged, restoredRem)
        val newRem      = maxOf(0L, restoredRem - done)

        assertEquals(3600L, done)
        assertEquals(0L, newRem)
        assertEquals(LectureStatus.COMPLETE, if (newRem == 0L) LectureStatus.COMPLETE else LectureStatus.PARTIAL)
    }
}
