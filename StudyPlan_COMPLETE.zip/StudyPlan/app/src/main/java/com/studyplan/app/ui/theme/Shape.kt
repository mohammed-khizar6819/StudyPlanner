package com.studyplan.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

// ═══════════════════════════════════════════════════════════════════
//  SHAPE TOKENS
//  CSS mapping:
//    --r-sm = 6dp  → extraSmall
//    --r    = 8dp  → small / medium
//    --r-lg = 12dp → large
//    100dp pill    → extraLarge (for toasts, tags)
// ═══════════════════════════════════════════════════════════════════

// Named radius constants for direct use in Modifier.clip / background
object StudyPlanRadius {
    val sm   = 6.dp
    val md   = 8.dp
    val lg   = 12.dp
    val pill = 100.dp
}

// Material3 Shapes — used by the MaterialTheme shape system
val StudyPlanShapes = Shapes(
    extraSmall = RoundedCornerShape(StudyPlanRadius.sm),
    small      = RoundedCornerShape(StudyPlanRadius.md),
    medium     = RoundedCornerShape(StudyPlanRadius.md),
    large      = RoundedCornerShape(StudyPlanRadius.lg),
    extraLarge = RoundedCornerShape(StudyPlanRadius.pill),
)
