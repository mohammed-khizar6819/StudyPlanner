package com.studyplan.app.domain.model

/** Used for spaced-repetition weighting in the revision engine */
enum class LectureDifficulty(val value: String, val weight: Double) {
    EASY("easy",     0.5),
    MEDIUM("medium", 1.0),
    HARD("hard",     2.0);
    companion object {
        fun from(value: String?) = entries.firstOrNull { it.value == value } ?: MEDIUM
    }
}
