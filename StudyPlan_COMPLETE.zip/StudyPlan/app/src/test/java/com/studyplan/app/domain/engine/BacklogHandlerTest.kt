package com.studyplan.app.domain.engine

import org.junit.Assert.*
import org.junit.Test
import kotlin.math.ceil
import kotlin.math.min

/**
 * Pure logic tests for BacklogHandler strategy calculations.
 * Repository-dependent tests covered by integration tests.
 */
class BacklogHandlerTest {

    @Test fun `EXTEND_DEADLINES adds 14 days to deadline`() {
        val original = "2024-07-01"
        val extended = TimeUtils.addDays(original, 14)
        assertEquals("2024-07-15", extended)
    }

    @Test fun `INCREASE_HOURS caps at 24`() {
        val current = 23.5
        val newHours = min(24.0, current + 1.0)
        assertEquals(24.0, newHours, 0.001)
    }

    @Test fun `INCREASE_HOURS increments normally when under 24`() {
        val current = 6.0
        val newHours = min(24.0, current + 1.0)
        assertEquals(7.0, newHours, 0.001)
    }

    @Test fun `REDISTRIBUTE calculates extra hours correctly`() {
        val backlogSecs   = 18000L  // 5h backlog
        val redistributeDays = 7
        val extra = ceil(backlogSecs / (redistributeDays * 3600.0)).toLong()
        assertEquals(1L, extra)  // ceil(5/7) = 1 extra hour/day
    }

    @Test fun `REDISTRIBUTE large backlog`() {
        val backlogSecs   = 108000L  // 30h backlog
        val redistributeDays = 7
        val extra = ceil(backlogSecs / (redistributeDays * 3600.0)).toLong()
        assertEquals(5L, extra)  // ceil(30/7) = 5 extra hours/day
    }

    @Test fun `REDISTRIBUTE hours cap at 16`() {
        val current = 14.0
        val extra   = 5L
        val newHours = min(16.0, current + extra.toDouble())
        assertEquals(16.0, newHours, 0.001)
    }
}
