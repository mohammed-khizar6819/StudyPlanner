package com.studyplan.app.domain.model

/**
 * A named snapshot of the entire app state.
 * The snapshotJson field holds the full StudyPlanBackup serialized as JSON.
 */
data class SavedPlan(
    val id:           String,
    val name:         String,
    val savedAt:      String,   // YYYY-MM-DD
    val subjectCount: Int,
    val lectureCount: Int,
    val snapshotJson: String,   // full backup JSON blob
)
