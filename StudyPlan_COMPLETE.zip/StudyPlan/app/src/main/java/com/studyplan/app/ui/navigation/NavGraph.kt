@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.studyplan.app.ui.animation.pageFadeEnter
import com.studyplan.app.ui.animation.pageFadeExit
import com.studyplan.app.ui.screens.analytics.AnalyticsScreen
import com.studyplan.app.ui.screens.calendar.CalendarScreen
import com.studyplan.app.ui.screens.dashboard.DashboardScreen
import com.studyplan.app.ui.screens.flashcards.FlashcardsScreen
import com.studyplan.app.ui.screens.lectures.LecturesScreen
import com.studyplan.app.ui.screens.notes.NotesScreen
import com.studyplan.app.ui.screens.settings.SettingsScreen
import com.studyplan.app.ui.screens.subjects.SubjectsScreen
import com.studyplan.app.ui.screens.timer.TimerScreen
import com.studyplan.app.ui.screens.today.TodayScreen

@Composable
fun StudyPlanNavGraph(
    navController:  NavHostController,
    modifier:       Modifier = Modifier,
) {
    NavHost(
        navController      = navController,
        startDestination   = Screen.Dashboard.route,
        modifier           = modifier,
        enterTransition    = { pageFadeEnter() },
        exitTransition     = { pageFadeExit() },
        popEnterTransition = { pageFadeEnter() },
        popExitTransition  = { pageFadeExit() },
    ) {
        composable(Screen.Dashboard.route)  {
            DashboardScreen(onNavigateToSubjects = { navController.navigate(Screen.Subjects.route) })
        }
        composable(Screen.Today.route)      { TodayScreen() }
        composable(Screen.Subjects.route)   { SubjectsScreen() }
        composable(Screen.Lectures.route)   { LecturesScreen() }
        composable(Screen.Analytics.route)  { AnalyticsScreen() }
        composable(Screen.Notes.route)      { NotesScreen() }
        composable(Screen.Timer.route)      { TimerScreen() }
        composable(Screen.Calendar.route)   { CalendarScreen() }
        composable(Screen.Flashcards.route) { FlashcardsScreen() }
        composable(Screen.Settings.route)   { SettingsScreen() }
    }
}
