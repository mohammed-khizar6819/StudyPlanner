package com.studyplan.app.data.db.dao

import androidx.room.*
import com.studyplan.app.data.db.entity.MetaEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MetaDao {
    @Query("SELECT * FROM meta WHERE id = 1")
    fun observe(): Flow<MetaEntity?>

    @Query("SELECT * FROM meta WHERE id = 1")
    suspend fun get(): MetaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(meta: MetaEntity)

    @Query("UPDATE meta SET lastBuiltDate = :date WHERE id = 1")
    suspend fun updateLastBuiltDate(date: String)

    @Query("UPDATE meta SET onboarded = 1 WHERE id = 1")
    suspend fun setOnboarded()

    @Query("UPDATE meta SET achievedMilestones = :milestones WHERE id = 1")
    suspend fun updateMilestones(milestones: List<String>)

    @Query("DELETE FROM meta")
    suspend fun deleteAll()
}
