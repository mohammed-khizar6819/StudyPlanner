@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.analytics

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyplan.app.domain.engine.*
import com.studyplan.app.domain.model.SessionLog
import com.studyplan.app.ui.animation.EaseOut
import com.studyplan.app.ui.theme.*
import kotlin.math.*

// ═══════════════════════════════════════════════════════════════════
//  1. WEEKLY BAR CHART
//  Shows planned (thin gray) vs studied (thick primary) per day.
//  Matches HTML .wr-days-chart exactly.
// ═══════════════════════════════════════════════════════════════════
@Composable
fun WeeklyBarChart(
    days:     List<DayStats>,
    modifier: Modifier = Modifier,
) {
    val colors   = MaterialTheme.studyColors
    val maxSecs  = days.maxOfOrNull { maxOf(it.plannedSecs, it.studiedSecs) }
        .takeIf { it != null && it > 0 } ?: 1L

    // Animate bars from 0
    var triggered by remember { mutableStateOf(false) }
    LaunchedEffect(days) { triggered = true }
    val animProg by animateFloatAsState(
        if (triggered) 1f else 0f,
        tween(600, easing = EaseOut), label = "weekBar"
    )

    Column(modifier = modifier.fillMaxWidth()) {
        // Legend
        Row(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.padding(bottom = 8.dp),
        ) {
            LegendItem(colors.borderStrong, "Planned")
            LegendItem(colors.primary,      "Studied")
        }
        // Day rows
        days.forEach { day ->
            DayRow(
                day      = day,
                maxSecs  = maxSecs,
                animProg = animProg,
                colors   = colors,
            )
        }
    }
}

@Composable
private fun LegendItem(color: Color, label: String) {
    val colors = MaterialTheme.studyColors
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(width = 14.dp, height = 3.dp)
            .clip(RoundedCornerShape(2.dp)).background(color))
        Spacer(Modifier.width(5.dp))
        Text(label, fontFamily = BodyFontFamily, fontSize = 11.sp, color = colors.text3)
    }
}

@Composable
private fun DayRow(
    day:      DayStats,
    maxSecs:  Long,
    animProg: Float,
    colors:   com.studyplan.app.ui.theme.StudyPlanColors,
) {
    val isMissed = !day.isBuffer && !day.isFuture && day.missedCount > 0 && day.studiedSecs == 0L
    val isGreat  = day.pct >= 90

    val rowBg = when {
        isMissed -> colors.missedRowBg
        isGreat  -> colors.cardDoneBg
        else     -> Color.Transparent
    }
    val rowBd = when {
        isMissed -> colors.wrMissedBorder
        isGreat  -> colors.wrGreatBorder
        else     -> Color.Transparent
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(rowBg)
            .border(1.dp, rowBd, RoundedCornerShape(6.dp))
            .padding(horizontal = 10.dp, vertical = 7.dp),
    ) {
        // Day name + date
        Column(modifier = Modifier.width(60.dp)) {
            Row(verticalAlignment = Alignment.Baseline) {
                Text(day.dayName, fontFamily = BodyFontFamily, fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp, color = colors.text2)
                if (day.date == TimeUtils.today()) {
                    Spacer(Modifier.width(3.dp))
                    Text("•", fontSize = 10.sp, color = colors.primary)
                }
            }
            Text(day.date.substring(8), fontFamily = MonoFontFamily,
                fontSize = 10.sp, color = colors.text3)
        }

        // Bar
        Box(modifier = Modifier.weight(1f).height(14.dp)) {
            if (day.isBuffer) {
                Text("Rest", fontFamily = BodyFontFamily, fontSize = 11.sp,
                    color = colors.text3,
                    modifier = Modifier.align(Alignment.CenterStart))
            } else {
                // Planned bar (thin, behind)
                val plannedW = if (maxSecs > 0) (day.plannedSecs.toFloat() / maxSecs) * animProg else 0f
                val studiedW = if (maxSecs > 0) (day.studiedSecs.toFloat() / maxSecs) * animProg else 0f
                Box(
                    modifier = Modifier
                        .fillMaxWidth(plannedW)
                        .height(3.dp)
                        .align(Alignment.Center)
                        .clip(RoundedCornerShape(2.dp))
                        .background(colors.borderStrong),
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth(studiedW)
                        .height(10.dp)
                        .align(Alignment.CenterStart)
                        .clip(RoundedCornerShape(5.dp))
                        .background(colors.primary),
                )
                if (isMissed) {
                    Text("missed", fontFamily = BodyFontFamily, fontSize = 10.sp,
                        color = colors.red, fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.CenterEnd))
                }
            }
        }

        // Hours display
        Spacer(Modifier.width(10.dp))
        Box(modifier = Modifier.width(90.dp), contentAlignment = Alignment.CenterEnd) {
            if (day.studiedSecs > 0) {
                Row(verticalAlignment = Alignment.Baseline) {
                    Text(TimeUtils.toDisplay(day.studiedSecs), fontFamily = BodyFontFamily,
                        fontWeight = FontWeight.Bold, fontSize = 12.sp, color = colors.text)
                    if (day.plannedSecs > 0 && day.studiedSecs != day.plannedSecs) {
                        Spacer(Modifier.width(2.dp))
                        Text("/ ${TimeUtils.toDisplay(day.plannedSecs)}",
                            fontFamily = BodyFontFamily, fontSize = 10.sp, color = colors.text3)
                    }
                }
            } else if (!day.isBuffer) {
                Text(if (day.plannedSecs > 0) TimeUtils.toDisplay(day.plannedSecs) else "—",
                    fontFamily = BodyFontFamily, fontSize = 11.sp, color = colors.text3)
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
//  2. CONSISTENCY ARC (semicircle gauge)
//  Matches HTML AnalyticsExtras._renderConsistency()
// ═══════════════════════════════════════════════════════════════════
@Composable
fun ConsistencyArc(
    result:   ConsistencyScore.Result,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.studyColors
    val fgColor = when (result.colorToken) {
        "green"  -> colors.green
        "yellow" -> colors.yellow
        else     -> colors.red
    }

    var triggered by remember { mutableStateOf(false) }
    LaunchedEffect(result.score) { triggered = true }
    val animScore by animateFloatAsState(
        if (triggered) result.score.toFloat() else 0f,
        tween(900, easing = EaseOut), label = "arc"
    )

    val textMeasurer = rememberTextMeasurer()

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(140.dp, 80.dp)) {
            val stroke     = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
            val arcRect    = androidx.compose.ui.geometry.Rect(
                left   = 10.dp.toPx(),
                top    = 10.dp.toPx(),
                right  = size.width - 10.dp.toPx(),
                bottom = size.height * 2 - 10.dp.toPx(),
            )
            // Track
            drawArc(color = colors.border, startAngle = 180f, sweepAngle = 180f,
                useCenter = false, style = stroke, topLeft = arcRect.topLeft,
                size = Size(arcRect.width, arcRect.height))
            // Fill
            val sweep = (animScore / 100f) * 180f
            if (sweep > 0f) {
                drawArc(color = fgColor, startAngle = 180f, sweepAngle = sweep,
                    useCenter = false, style = stroke, topLeft = arcRect.topLeft,
                    size = Size(arcRect.width, arcRect.height))
            }
        }
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 32.dp),
        ) {
            Text("${animScore.toInt()}", fontFamily = HeadingFontFamily,
                fontWeight = FontWeight.Bold, fontSize = 28.sp, color = fgColor)
            Text(result.label, fontFamily = BodyFontFamily, fontSize = 11.sp,
                color = colors.text3)
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
//  3. TIME-OF-DAY HEATMAP (24 vertical bars)
//  Matches HTML AnalyticsExtras._renderTODHeatmap()
// ═══════════════════════════════════════════════════════════════════
@Composable
fun TODHeatmap(
    logs:     List<SessionLog>,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.studyColors
    val hourTotals = remember(logs) {
        val arr = LongArray(24)
        logs.forEach { arr[it.hour] = arr[it.hour] + it.seconds }
        arr
    }
    val maxVal = hourTotals.maxOrNull().takeIf { it != null && it > 0 } ?: 1L

    var triggered by remember { mutableStateOf(false) }
    LaunchedEffect(logs) { triggered = true }
    val animProg by animateFloatAsState(
        if (triggered) 1f else 0f,
        tween(700, easing = EaseOut), label = "tod"
    )

    Row(
        verticalAlignment     = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        modifier              = modifier
            .fillMaxWidth()
            .height(64.dp),
    ) {
        hourTotals.forEachIndexed { hour, secs ->
            val fraction = (secs.toFloat() / maxVal) * animProg
            val barH     = maxOf(2.dp, (58.dp * fraction))
            val lbl      = when (hour) {
                0  -> "12a"; 6  -> "6a"; 12 -> "12p"; 18 -> "6p"; else -> ""
            }
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
                modifier            = Modifier.weight(1f),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(barH)
                        .clip(RoundedCornerShape(2.dp))
                        .background(if (secs > 0) colors.primary else colors.border),
                )
                if (lbl.isNotEmpty()) {
                    Text(lbl, fontFamily = MonoFontFamily, fontSize = 7.sp,
                        color = colors.text3)
                } else {
                    Spacer(Modifier.height(9.dp))
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
//  4. WEEKLY VELOCITY CHART (8-week bar chart)
//  Matches HTML AnalyticsExtras._renderVelocity()
// ═══════════════════════════════════════════════════════════════════
@Composable
fun VelocityChart(
    weekly:   WeeklyStats,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.studyColors
    // Compute 8-week lecture counts from session history
    val today = TimeUtils.today()
    val weekCounts = remember(weekly) {
        (7 downTo 0).map { w ->
            var count = 0
            for (d in 0..6) {
                val date = TimeUtils.addDays(today, (-(w * 7) + d - 6).toLong())
                count += weekly.days.firstOrNull { it.date == date }?.doneCount ?: 0
            }
            count
        }
    }
    val maxCount = weekCounts.maxOrNull().takeIf { it != null && it > 0 } ?: 1

    var triggered by remember { mutableStateOf(false) }
    LaunchedEffect(weekly) { triggered = true }
    val animProg by animateFloatAsState(
        if (triggered) 1f else 0f, tween(700, easing = EaseOut), label = "vel"
    )

    Row(
        verticalAlignment     = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier              = modifier.fillMaxWidth().height(80.dp),
    ) {
        weekCounts.forEachIndexed { i, count ->
            val isLast   = i == weekCounts.lastIndex
            val fraction = (count.toFloat() / maxCount) * animProg
            val barH     = maxOf(4.dp, (72.dp * fraction))
            val alpha    = if (isLast) 1f else 0.3f + (i * 0.09f)

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
                modifier            = Modifier.weight(1f),
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(barH)
                        .clip(RoundedCornerShape(3.dp))
                        .background(
                            if (isLast) colors.primary
                            else colors.borderStrong.copy(alpha = alpha)
                        ),
                )
                Spacer(Modifier.height(3.dp))
                Text(if (isLast) "Now" else "W${weekCounts.size - 1 - i}",
                    fontFamily = MonoFontFamily, fontSize = 8.sp, color = colors.text3)
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
//  5. CHAIN CALENDAR (5-week study streak grid)
//  Matches HTML AnalyticsExtras._renderChain()
// ═══════════════════════════════════════════════════════════════════
@Composable
fun ChainCalendar(
    weekly:   WeeklyStats,
    modifier: Modifier = Modifier,
) {
    val colors  = MaterialTheme.studyColors
    val today   = TimeUtils.today()
    val weeks   = 5
    val dowNames = listOf("S","M","T","W","T","F","S")

    Column(modifier = modifier.fillMaxWidth()) {
        // Day-of-week header
        Row(modifier = Modifier.fillMaxWidth()) {
            Spacer(Modifier.width(32.dp))
            dowNames.forEach { d ->
                Text(d, fontFamily = BodyFontFamily, fontWeight = FontWeight.Bold,
                    fontSize = 10.sp, color = colors.text3, textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(4.dp))

        // Build 5-week grid
        val startOffset = (weeks - 1) * 7 + TimeUtils.dayOfWeek(today)
        val startDate   = TimeUtils.addDays(today, -startOffset.toLong())

        (0 until weeks).forEach { w ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier          = Modifier.fillMaxWidth(),
            ) {
                val weekStart    = TimeUtils.addDays(startDate, (w * 7).toLong())
                val monthLabel   = java.time.LocalDate.parse(weekStart)
                    .month.name.take(3).lowercase().replaceFirstChar { it.uppercase() }
                Text(monthLabel, fontFamily = MonoFontFamily, fontSize = 9.sp,
                    color = colors.text3, modifier = Modifier.width(32.dp))

                (0 until 7).forEach { d ->
                    val date     = TimeUtils.addDays(weekStart, d.toLong())
                    val isFuture = date > today
                    val isToday  = date == today
                    val studied  = weekly.days.any { it.date == date &&
                        (it.studiedSecs > 0 || it.doneCount > 0) }
                    val hasPlan  = weekly.days.any { it.date == date && it.plannedSecs > 0 }
                    val isMissed = !isFuture && !isToday && hasPlan && !studied

                    val cellBg = when {
                        isToday  -> colors.primary
                        studied  -> colors.green
                        isMissed -> colors.redX
                        else     -> colors.heat0
                    }
                    val cellBd = when {
                        isToday  -> colors.primary
                        isMissed -> colors.red.copy(.2f)
                        else     -> Color.Transparent
                    }
                    val day    = date.substring(8).trimStart('0').ifEmpty { "0" }

                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .padding(2.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(cellBg)
                            .border(1.dp, cellBd, RoundedCornerShape(4.dp)),
                    ) {
                        Text(day, fontFamily = MonoFontFamily, fontSize = 10.sp,
                            color = if (isToday || studied) colors.bg else colors.text3)
                    }
                }
            }
            Spacer(Modifier.height(3.dp))
        }

        // Legend
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf(
                colors.green   to "Studied",
                colors.redX    to "Missed",
                colors.heat0   to "Future/Rest",
            ).forEach { (c, label) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(10.dp)
                        .clip(RoundedCornerShape(2.dp)).background(c))
                    Spacer(Modifier.width(4.dp))
                    Text(label, fontFamily = BodyFontFamily, fontSize = 10.sp,
                        color = colors.text3)
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
//  6. PREDICTION CHART (Canvas line chart — actual vs required pace)
//  Mirrors HTML PredChart
// ═══════════════════════════════════════════════════════════════════
@Composable
fun PredictionChart(
    weekly:  WeeklyStats,
    overall: AppStats,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.studyColors
    val today  = TimeUtils.today()

    if (weekly.days.isEmpty()) return

    // Build 14-day window: 7 past + 7 future
    val allDays = (6 downTo -7).map { i -> TimeUtils.addDays(today, -i.toLong()) }
    val totalSecs = overall.completedSecs + overall.remainingSecs
    if (totalSecs == 0L) return

    // Actual progress points (past 7 days)
    var runningCompleted = overall.completedSecs - weekly.weekStudiedSecs
    val actualPoints = allDays.mapIndexedNotNull { i, date ->
        if (date > today) return@mapIndexedNotNull null
        val dayStudied = weekly.days.firstOrNull { it.date == date }?.studiedSecs ?: 0L
        runningCompleted += dayStudied
        Pair(i.toFloat() / (allDays.size - 1).toFloat(),
             runningCompleted.toFloat() / totalSecs.toFloat())
    }

    // Required pace line (straight from current to 100%)
    val daysLeft     = overall.studyDaysLeft.coerceAtLeast(1)
    val startFraction = overall.completedSecs.toFloat() / totalSecs
    val requiredPoints = listOf(
        Pair(6f / (allDays.size - 1).toFloat(), startFraction),
        Pair(1f, 1f),
    )

    var triggered by remember { mutableStateOf(false) }
    LaunchedEffect(weekly) { triggered = true }
    val animProg by animateFloatAsState(
        if (triggered) 1f else 0f, tween(800, easing = EaseOut), label = "pred"
    )

    Canvas(modifier = modifier.fillMaxWidth().height(100.dp)) {
        val w = size.width
        val h = size.height

        fun pointX(t: Float) = t * w
        fun pointY(v: Float) = h - (v * h * animProg)

        // Required pace (dashed gray)
        if (requiredPoints.size >= 2) {
            val path = Path()
            path.moveTo(pointX(requiredPoints[0].first), pointY(requiredPoints[0].second))
            path.lineTo(pointX(requiredPoints[1].first), pointY(requiredPoints[1].second))
            drawPath(path, colors.borderStrong,
                style = Stroke(width = 1.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 4f))))
        }

        // Actual progress (solid primary)
        if (actualPoints.size >= 2) {
            val path = Path()
            path.moveTo(pointX(actualPoints[0].first), pointY(actualPoints[0].second))
            actualPoints.drop(1).forEach { (t, v) ->
                path.lineTo(pointX(t), pointY(v))
            }
            drawPath(path, colors.primary, style = Stroke(width = 2.dp.toPx(),
                cap = StrokeCap.Round, join = StrokeJoin.Round))
        }

        // Today line
        val todayX = pointX(6f / (allDays.size - 1).toFloat())
        drawLine(colors.text3.copy(.4f), Offset(todayX, 0f), Offset(todayX, h),
            strokeWidth = 1.dp.toPx(),
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f)))
    }
}

// ═══════════════════════════════════════════════════════════════════
//  WEEK SUMMARY ROW — totals strip below the bar chart
// ═══════════════════════════════════════════════════════════════════
@Composable
fun WeekSummaryRow(weekly: WeeklyStats, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.studyColors
    Row(
        horizontalArrangement = Arrangement.SpaceEvenly,
        modifier              = modifier.fillMaxWidth(),
    ) {
        listOf(
            TimeUtils.toDisplay(weekly.weekStudiedSecs) to "STUDIED",
            "${weekly.weekDone}"    to "DONE",
            "${weekly.weekMissed}"  to "MISSED",
            "${weekly.streak} days" to "STREAK",
            "${weekly.completionRate}%" to "COMPLETION",
        ).forEach { (value, label) ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(value, fontFamily = HeadingFontFamily, fontWeight = FontWeight.Bold,
                    fontSize = 14.sp, color = colors.text, letterSpacing = (-0.42).sp)
                Text(label, fontFamily = BodyFontFamily, fontWeight = FontWeight.Bold,
                    fontSize = 8.sp, color = colors.text3, letterSpacing = 0.8.sp)
            }
        }
    }
}
