@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.lectures

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studyplan.app.domain.engine.*
import com.studyplan.app.domain.model.*
import com.studyplan.app.domain.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// ── Filter / Sort state ───────────────────────────────────────────
data class LectureFilter(
    val subjectId: String?        = null,
    val status:    LectureStatus? = null,
    val tag:       LectureTag?    = null,
    val query:     String         = "",
)
enum class LectureSort { SEQUENCE, NAME, STATUS, DURATION }

data class LecturesUiState(
    val isLoading:    Boolean            = true,
    val lectures:     List<Lecture>      = emptyList(),  // all (unfiltered)
    val filtered:     List<Lecture>      = emptyList(),  // displayed
    val subjects:     List<Subject>      = emptyList(),
    val filter:       LectureFilter      = LectureFilter(),
    val sort:         LectureSort        = LectureSort.SEQUENCE,
    val selected:     Set<String>        = emptySet(),   // bulk-selection IDs
    val showImport:   Boolean            = false,
)

@HiltViewModel
class LecturesViewModel @Inject constructor(
    private val lectureRepo:     LectureRepository,
    private val subjectRepo:     SubjectRepository,
    private val noteRepo:        NoteRepository,
    private val schedulerEngine: SchedulerEngine,
    private val statsEngine:     StatsEngine,
) : ViewModel() {

    private val _state = MutableStateFlow(LecturesUiState())
    val state: StateFlow<LecturesUiState> = _state.asStateFlow()

    private val _toast = MutableSharedFlow<String>()
    val toast: SharedFlow<String> = _toast.asSharedFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            val lectures = lectureRepo.getAll()
            val subjects = subjectRepo.getAll()
            val current  = _state.value
            _state.update {
                it.copy(
                    isLoading = false,
                    lectures  = lectures,
                    subjects  = subjects,
                    filtered  = applyFilter(lectures, current.filter, current.sort),
                )
            }
        }
    }

    fun setFilter(filter: LectureFilter) {
        _state.update {
            it.copy(filter = filter, filtered = applyFilter(it.lectures, filter, it.sort))
        }
    }

    fun setSort(sort: LectureSort) {
        _state.update {
            it.copy(sort = sort, filtered = applyFilter(it.lectures, it.filter, sort))
        }
    }

    fun toggleSelect(id: String) {
        _state.update {
            val sel = if (id in it.selected) it.selected - id else it.selected + id
            it.copy(selected = sel)
        }
    }

    fun selectAll() {
        _state.update { it.copy(selected = it.filtered.map { l -> l.id }.toSet()) }
    }

    fun clearSelection() { _state.update { it.copy(selected = emptySet()) } }

    fun addLecture(
        subjectId: String, lectureNum: String, name: String,
        durationStr: String, chapter: String, tags: List<LectureTag>,
    ) {
        viewModelScope.launch {
            val dur = TimeUtils.toSeconds(durationStr)
            if (name.isBlank()) { _toast.emit("Name required"); return@launch }
            if (dur <= 0) { _toast.emit("Enter duration like 01:30:00"); return@launch }
            val maxSeq = lectureRepo.maxSequenceForSubject(subjectId)
            lectureRepo.insert(Lecture(
                id = "lec_${System.currentTimeMillis()}",
                subjectId = subjectId, sequence = maxSeq + 1,
                lectureNum = lectureNum.ifBlank { "${maxSeq + 1}" },
                name = name, duration = dur, remaining = dur,
                status = LectureStatus.PENDING, completedOn = null,
                todayStudied = 0, todayDate = null,
                chapter = chapter, tags = tags, difficulty = LectureDifficulty.MEDIUM,
            ))
            schedulerEngine.buildSchedule(forceRebuildToday = true)
            statsEngine.invalidate()
            _toast.emit("Lecture added!")
            load()
        }
    }

    fun editLecture(
        lecture: Lecture, name: String, durationStr: String,
        remainingStr: String, chapter: String, tags: List<LectureTag>,
        status: LectureStatus, difficulty: LectureDifficulty,
    ) {
        viewModelScope.launch {
            val newDur = TimeUtils.toSeconds(durationStr)
            val newRem = TimeUtils.toSeconds(remainingStr)
            if (name.isBlank()) { _toast.emit("Name required"); return@launch }
            if (newDur <= 0) { _toast.emit("Invalid duration"); return@launch }

            val finalRem = when (status) {
                LectureStatus.COMPLETE -> 0L
                LectureStatus.PENDING  -> newDur
                LectureStatus.PARTIAL  -> newRem.coerceIn(0, newDur)
            }
            val finalStatus = if (finalRem == 0L) LectureStatus.COMPLETE
                              else if (finalRem == newDur) LectureStatus.PENDING
                              else LectureStatus.PARTIAL
            val completedOn = if (finalStatus == LectureStatus.COMPLETE)
                lecture.completedOn ?: TimeUtils.today() else null

            lectureRepo.updateProgress(lecture.copy(
                name = name, duration = newDur, remaining = finalRem,
                status = finalStatus, completedOn = completedOn,
                chapter = chapter, tags = tags, difficulty = difficulty,
                todayStudied = if (finalStatus == LectureStatus.PENDING) 0L else lecture.todayStudied,
                todayDate    = if (finalStatus == LectureStatus.PENDING) null else lecture.todayDate,
            ))
            schedulerEngine.buildSchedule(forceRebuildToday = true)
            statsEngine.invalidate()
            _toast.emit("Updated!")
            load()
        }
    }

    fun deleteLecture(id: String) {
        viewModelScope.launch {
            lectureRepo.delete(id)
            noteRepo.deleteForLecture(id)
            schedulerEngine.buildSchedule(forceRebuildToday = true)
            statsEngine.invalidate()
            _toast.emit("Lecture deleted")
            load()
        }
    }

    fun deleteSelected() {
        viewModelScope.launch {
            val ids = _state.value.selected.toList()
            ids.forEach {
                lectureRepo.delete(it)
                noteRepo.deleteForLecture(it)
            }
            schedulerEngine.buildSchedule(forceRebuildToday = true)
            statsEngine.invalidate()
            _toast.emit("${ids.size} lectures deleted")
            clearSelection()
            load()
        }
    }

    fun markSelectedDone() {
        viewModelScope.launch {
            val today = TimeUtils.today()
            _state.value.selected.forEach { id ->
                val lec = lectureRepo.getById(id) ?: return@forEach
                if (lec.status != LectureStatus.COMPLETE) {
                    lectureRepo.updateProgress(lec.copy(
                        remaining = 0, status = LectureStatus.COMPLETE,
                        completedOn = today))
                }
            }
            schedulerEngine.buildSchedule(forceRebuildToday = true)
            statsEngine.invalidate()
            _toast.emit("Marked done")
            clearSelection()
            load()
        }
    }

    fun quickLog(lectureId: String, seconds: Long) {
        viewModelScope.launch {
            val today = TimeUtils.today()
            val lec   = lectureRepo.getById(lectureId) ?: return@launch
            val prev  = if (lec.todayDate == today) lec.todayStudied else 0L
            val ok    = schedulerEngine.partialComplete(lectureId, prev + seconds)
            if (ok) _toast.emit("+${TimeUtils.toDisplay(seconds)} logged!")
            else    _toast.emit("Already complete")
            load()
        }
    }

    fun setDifficulty(lectureId: String, difficulty: LectureDifficulty) {
        viewModelScope.launch {
            val lec = lectureRepo.getById(lectureId) ?: return@launch
            lectureRepo.update(lec.copy(difficulty = difficulty))
            _toast.emit("Marked as ${difficulty.value}")
            load()
        }
    }

    fun importLectures(subjectId: String, parsed: List<ParsedLecture>) {
        viewModelScope.launch {
            if (parsed.isEmpty()) { _toast.emit("No lectures to import"); return@launch }
            val maxSeq = lectureRepo.maxSequenceForSubject(subjectId)
            val base   = System.currentTimeMillis()
            parsed.forEachIndexed { idx, pl ->
                val dur = TimeUtils.toSeconds(pl.durStr)
                if (dur <= 0) return@forEachIndexed
                lectureRepo.insert(Lecture(
                    id = "lec_${base}_${idx}",
                    subjectId = subjectId, sequence = maxSeq + idx + 1,
                    lectureNum = pl.num.ifBlank { "${maxSeq + idx + 1}" },
                    name = pl.name, duration = dur, remaining = dur,
                    status = LectureStatus.PENDING, completedOn = null,
                    todayStudied = 0, todayDate = null, chapter = "",
                    tags = emptyList(), difficulty = LectureDifficulty.MEDIUM,
                ))
            }
            schedulerEngine.buildSchedule(forceRebuildToday = true)
            statsEngine.invalidate()
            _toast.emit("Imported ${parsed.size} lectures!")
            load()
        }
    }

    // ── Parser — mirrors HTML PDFImport.parse() regex logic ──────
    fun parseText(raw: String): List<ParsedLecture> {
        // Pattern: optional number, name, duration (hh:mm:ss or h:mm:ss)
        val patterns = listOf(
            Regex("""^\s*(\d+)[.\s)\-]+(.+?)\s+(\d{1,3}:\d{2}:\d{2})\s*$"""),
            Regex("""^\s*(\d+)[.\s)\-]+(.+?)\s+(\d{1,3}:\d{2})\s*$"""),
            Regex("""^(.+?)\s+(\d{1,3}:\d{2}:\d{2})\s*$"""),
        )
        return raw.lines()
            .mapIndexedNotNull { idx, line ->
                val trimmed = line.trim()
                if (trimmed.isBlank()) return@mapIndexedNotNull null
                for (pattern in patterns) {
                    val m = pattern.matchEntire(trimmed) ?: continue
                    return@mapIndexedNotNull when (m.groupValues.size) {
                        4 -> ParsedLecture(m.groupValues[1], m.groupValues[2].trim(), m.groupValues[3])
                        3 -> ParsedLecture("", m.groupValues[1].trim(), m.groupValues[2])
                        else -> null
                    }
                }
                null
            }
    }

    private fun applyFilter(
        all:    List<Lecture>,
        filter: LectureFilter,
        sort:   LectureSort,
    ): List<Lecture> {
        return all
            .filter { lec ->
                (filter.subjectId == null || lec.subjectId == filter.subjectId) &&
                (filter.status    == null || lec.status    == filter.status)    &&
                (filter.tag       == null || filter.tag in lec.tags)            &&
                (filter.query.isBlank()   || lec.name.contains(filter.query, ignoreCase = true) ||
                    lec.chapter.contains(filter.query, ignoreCase = true))
            }
            .sortedWith(when (sort) {
                LectureSort.SEQUENCE -> compareBy({ it.subjectId }, { it.sequence })
                LectureSort.NAME     -> compareBy { it.name.lowercase() }
                LectureSort.STATUS   -> compareBy({ it.status.ordinal }, { it.sequence })
                LectureSort.DURATION -> compareByDescending { it.duration }
            })
    }
}

data class ParsedLecture(
    val num:    String,
    val name:   String,
    val durStr: String,
    var selected: Boolean = true,
)
