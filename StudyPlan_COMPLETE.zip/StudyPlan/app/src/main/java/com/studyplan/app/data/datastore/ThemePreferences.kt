package com.studyplan.app.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

// ── DataStore singleton ───────────────────────────────────────────
private val Context.themeDataStore: DataStore<Preferences>
    by preferencesDataStore(name = "studyplan_preferences")

@Singleton
class ThemePreferences @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    private val DARK_THEME_KEY = booleanPreferencesKey("dark_theme")

    /** Emits true when dark theme is active. Defaults to false (light). */
    val isDarkTheme: Flow<Boolean> = context.themeDataStore.data
        .map { prefs -> prefs[DARK_THEME_KEY] ?: false }

    suspend fun setDarkTheme(isDark: Boolean) {
        context.themeDataStore.edit { prefs ->
            prefs[DARK_THEME_KEY] = isDark
        }
    }
}
