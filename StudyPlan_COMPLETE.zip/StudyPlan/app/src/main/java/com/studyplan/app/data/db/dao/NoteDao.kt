package com.studyplan.app.data.db.dao

import androidx.room.*
import com.studyplan.app.data.db.entity.NoteEntity
import com.studyplan.app.domain.model.NoteType
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes ORDER BY createdAt DESC")
    suspend fun getAll(): List<NoteEntity>

    @Query("SELECT * FROM notes WHERE lectureId = :lectureId ORDER BY createdAt DESC")
    fun observeForLecture(lectureId: String): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE lectureId = :lectureId ORDER BY createdAt DESC")
    suspend fun getForLecture(lectureId: String): List<NoteEntity>

    @Query("SELECT * FROM notes WHERE type = :type ORDER BY createdAt DESC")
    suspend fun getByType(type: NoteType): List<NoteEntity>

    @Query("SELECT * FROM notes WHERE lectureId = :lectureId AND type = 'key' ORDER BY createdAt DESC")
    suspend fun getKeyPointsForLecture(lectureId: String): List<NoteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(note: NoteEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(notes: List<NoteEntity>)

    @Query("UPDATE notes SET resolved = :resolved WHERE id = :id")
    suspend fun setResolved(id: String, resolved: Boolean)

    @Delete
    suspend fun delete(note: NoteEntity)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM notes WHERE lectureId = :lectureId")
    suspend fun deleteForLecture(lectureId: String)

    @Query("DELETE FROM notes")
    suspend fun deleteAll()
}
