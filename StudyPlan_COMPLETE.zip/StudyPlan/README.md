# StudyPlan Android — Phase 1 Complete

## What Was Built

Phase 1 delivers a **runnable app skeleton** with the full design system, navigation
shell, adaptive layout, and animated theme switching. Every subsequent phase drops
code into the established structure without restructuring anything.

---

## Project Structure

```
StudyPlan/
├── gradle/
│   └── libs.versions.toml          ← Version catalog (all deps in one place)
├── build.gradle.kts                ← Root build file (plugin declarations only)
├── settings.gradle.kts             ← Project name + module include
├── gradle.properties               ← JVM args, Gradle flags, Kotlin options
│
└── app/
    ├── build.gradle.kts            ← App-level deps: Compose, Room, Hilt, Moshi…
    ├── proguard-rules.pro          ← R8 keep rules for Room/Hilt/Moshi/Navigation
    │
    └── src/main/
        ├── AndroidManifest.xml     ← Permissions, Activity, Receivers, Providers
        │
        ├── java/com/studyplan/app/
        │   │
        │   ├── StudyPlanApplication.kt      ← @HiltAndroidApp, WorkManager config,
        │   │                                   notification channel creation
        │   ├── MainActivity.kt              ← Single activity, splash, edge-to-edge,
        │   │                                   theme state → StudyPlanTheme
        │   │
        │   ├── alarm/
        │   │   ├── AlarmReceiver.kt         ← BroadcastReceiver: posts alarm notif
        │   │   └── BootReceiver.kt          ← Reschedules alarm after reboot
        │   │
        │   ├── data/
        │   │   └── datastore/
        │   │       └── ThemePreferences.kt  ← DataStore: persists dark/light pref
        │   │
        │   ├── di/
        │   │   └── AppModule.kt             ← Hilt @Module (ThemePreferences)
        │   │                                   Phase 2 adds DB + Repositories
        │   │
        │   └── ui/
        │       ├── theme/
        │       │   ├── Color.kt             ← Full design token system
        │       │   │                           LightStudyPlanColors + DarkStudyPlanColors
        │       │   │                           Exact port of all :root + [data-theme="dark"]
        │       │   │                           CSS variables. SubjectColors palette.
        │       │   ├── Type.kt              ← BricolageGrotesque / Figtree / JetBrainsMono
        │       │   │                           Full typography scale (display→label)
        │       │   ├── Shape.kt             ← r=8dp / r-sm=6dp / r-lg=12dp tokens
        │       │   └── Theme.kt             ← StudyPlanTheme composable
        │       │                               Animated color crossfade (180ms)
        │       │                               MaterialTheme.studyColors extension
        │       │
        │       ├── navigation/
        │       │   ├── Screen.kt            ← Sealed class: 10 typed destinations
        │       │   │                           + icons, labels, keyboard shortcut keys
        │       │   └── NavGraph.kt          ← NavHost with pageFade transitions
        │       │
        │       ├── scaffold/
        │       │   ├── AppScaffold.kt       ← Adaptive layout:
        │       │   │                           ≥600dp → permanent 240dp sidebar
        │       │   │                           <600dp → ModalNavigationDrawer
        │       │   │                           + mobile TopAppBar
        │       │   ├── SidebarContent.kt    ← Brand, nav items, progress widget,
        │       │   │                           theme toggle, motivational quote
        │       │   └── ThemeViewModel.kt    ← isDarkTheme StateFlow, toggleTheme()
        │       │                               isLoading flag for splash screen
        │       │
        │       └── screens/
        │           ├── PlaceholderScreen.kt ← Shared stub composable
        │           ├── dashboard/DashboardScreen.kt    ← Phase 5
        │           ├── today/TodayScreen.kt            ← Phase 5
        │           ├── subjects/SubjectsScreen.kt      ← Phase 6
        │           ├── lectures/LecturesScreen.kt      ← Phase 6
        │           ├── analytics/AnalyticsScreen.kt    ← Phase 8
        │           ├── notes/NotesScreen.kt            ← Phase 7
        │           ├── timer/TimerScreen.kt            ← Phase 9
        │           ├── calendar/CalendarScreen.kt      ← Phase 8
        │           ├── flashcards/FlashcardsScreen.kt  ← Phase 7
        │           └── settings/SettingsScreen.kt      ← Phase 10
        │
        └── res/
            ├── values/
            │   ├── strings.xml         ← App name, nav labels, notif strings
            │   └── themes.xml          ← Splash screen theme + NoActionBar base
            │
            ├── drawable/
            │   ├── ic_splash_icon.xml          ← 3-bar brand mark (108×108dp)
            │   ├── ic_notification.xml         ← Monochrome notif icon (24dp)
            │   ├── ic_launcher_foreground.xml  ← Adaptive icon foreground
            │   └── ic_launcher_background.xml  ← Solid #111111 background
            │
            ├── mipmap-anydpi-v26/
            │   ├── ic_launcher.xml             ← Adaptive icon definition
            │   └── ic_launcher_round.xml       ← Round adaptive icon
            │
            └── xml/
                ├── file_provider_paths.xml     ← FileProvider paths for JSON export
                ├── backup_rules.xml            ← Auto Backup include/exclude rules
                └── data_extraction_rules.xml   ← Cloud backup + D2D transfer rules

```

---

## Design System — Token Reference

| CSS Variable | Kotlin Token | Light | Dark |
|---|---|---|---|
| `--bg` | `colors.bg` | `#FAFAFA` | `#111111` |
| `--surface` | `colors.surface` | `#FFFFFF` | `#1A1A1A` |
| `--surface2` | `colors.surface2` | `#F5F5F5` | `#222222` |
| `--hover` | `colors.hover` | `#F0F0F0` | `#2A2A2A` |
| `--border` | `colors.border` | `#E8E8E8` | `#2E2E2E` |
| `--border-strong` | `colors.borderStrong` | `#D0D0D0` | `#3A3A3A` |
| `--text` | `colors.text` | `#111111` | `#EEEEEE` |
| `--text2` | `colors.text2` | `#555555` | `#AAAAAA` |
| `--text3` | `colors.text3` | `#999999` | `#666666` |
| `--green` | `colors.green` | `#16a34a` | `#22c55e` |
| `--red` | `colors.red` | `#dc2626` | `#ef4444` |
| `--yellow` | `colors.yellow` | `#ca8a04` | `#eab308` |
| `--blue` | `colors.blue` | `#2563eb` | `#60a5fa` |
| `--heat-0..4` | `colors.heat0..heat4` | `#F0F0F0→#111` | `#222→#EEE` |

Usage: `val colors = MaterialTheme.studyColors`

---

## Navigation

| Screen | Route | Shortcut |
|---|---|---|
| Dashboard | `dashboard` | D |
| Today's Plan | `today` | T |
| Subjects | `subjects` | S |
| Lectures | `lectures` | L |
| Analytics | `analytics` | A |
| Notes & Doubts | `notes` | N |
| Timer | `timer` | P |
| Calendar | `calendar` | C |
| Flashcards | `flashcards` | F |
| Settings | `settings` | — |

---

## Phase 1 Checklist

- [x] Gradle version catalog (`libs.versions.toml`)
- [x] Root + app `build.gradle.kts` with all Phase 1–10 dependencies
- [x] `settings.gradle.kts`
- [x] `gradle.properties` (JVM, parallel, caching flags)
- [x] `AndroidManifest.xml` (all permissions + components declared)
- [x] `StudyPlanApplication.kt` (Hilt, WorkManager, notification channels)
- [x] `MainActivity.kt` (splash, edge-to-edge, theme state)
- [x] Design system — `Color.kt` (all CSS tokens → Kotlin, light + dark)
- [x] Design system — `Type.kt` (3 font families, full scale)
- [x] Design system — `Shape.kt` (r-sm/r/r-lg/pill tokens)
- [x] Design system — `Theme.kt` (animated 180ms crossfade, `studyColors` extension)
- [x] `ThemePreferences.kt` (DataStore dark/light persistence)
- [x] `AppModule.kt` (Hilt DI module)
- [x] `ThemeViewModel.kt` (StateFlow, toggle, splash loading flag)
- [x] `Screen.kt` (10 typed destinations, icons, shortcut keys)
- [x] `NavGraph.kt` (NavHost, pageFade entry animation)
- [x] `AppScaffold.kt` (adaptive: permanent sidebar ≥600dp / drawer <600dp)
- [x] `SidebarContent.kt` (brand, nav items, active indicator bar, progress widget,
        theme toggle, motivational quote)
- [x] 10 placeholder screen stubs (one per package, ready for implementation)
- [x] `AlarmReceiver.kt` + `BootReceiver.kt` (stubs, fully wired in Phase 9)
- [x] All drawable vector assets (splash icon, notification icon, launcher icons)
- [x] All resource XML (strings, themes, file_provider_paths, backup_rules,
        data_extraction_rules)
- [x] `proguard-rules.pro` (Room, Hilt, Moshi, Navigation, WorkManager)
- [x] `FONT_SETUP.md` (font download + placement instructions)

---

## How to Open in Android Studio

1. Open Android Studio Ladybug (2024.2.1) or newer
2. `File → Open` → select the `phase1/` folder
3. Let Gradle sync complete
4. Follow `FONT_SETUP.md` to add font files to `app/src/main/res/font/`
5. Run on emulator (API 26+) or physical device
6. You should see: sidebar with all 10 nav items, theme toggle working,
   correct fonts and monochrome colors in both light and dark modes

---

## Next: Phase 2 — Data Layer

Phase 2 implements:
- All Room entities (Subject, Lecture, ScheduleEntry, Note, SessionLog,
  Settings, Meta, SavedPlan)
- DAOs with all queries needed by the scheduling engine
- `AppDatabase` (version 1, schema export)
- Repository interfaces + Room-backed implementations
- Hilt database module
- JSON schema matching `studyPlanner_v3` format (HTML cross-compatibility)
- Seed/init logic (equivalent of `Store.init()`)
