@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.calendar

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studyplan.app.domain.engine.TimeUtils
import com.studyplan.app.domain.model.ScheduleEntryStatus
import com.studyplan.app.ui.components.*
import com.studyplan.app.ui.components.dialog.StudyPlanDialog
import com.studyplan.app.ui.theme.*
import java.time.Month
import java.time.YearMonth

@Composable
fun CalendarScreen(vm: CalendarViewModel = hiltViewModel()) {
    val state  by vm.state.collectAsStateWithLifecycle()
    val colors  = MaterialTheme.studyColors
    val toast   = LocalToastHost.current

    LaunchedEffect(Unit) { vm.toast.collect { toast.show(it) } }

    var newVacDate by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.bg)
            .verticalScroll(rememberScrollState()),
    ) {
        PageHeader(title = "Schedule Calendar",
            subtitle = "Visual overview of your study plan")

        if (state.isLoading) {
            Box(Modifier.fillMaxWidth().height(300.dp), Alignment.Center) {
                CircularProgressIndicator(color = colors.text, strokeWidth = 2.dp,
                    modifier = Modifier.size(28.dp))
            }
        } else {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {

                // ── Month nav ─────────────────────────────────────
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment     = Alignment.CenterVertically,
                    modifier              = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                ) {
                    Text(
                        "${Month.of(state.month).name.lowercase()
                            .replaceFirstChar { it.uppercase() }} ${state.year}",
                        fontFamily = HeadingFontFamily, fontWeight = FontWeight.Bold,
                        fontSize = 18.sp, color = colors.text, letterSpacing = (-0.54).sp,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        CalNavBtn(Icons.Outlined.ChevronLeft)  { vm.navigate(-1) }
                        SmButton("Today", onClick = { vm.goToToday() },
                            variant = ButtonVariant.OUTLINE)
                        CalNavBtn(Icons.Outlined.ChevronRight) { vm.navigate(1) }
                    }
                }

                // ── Legend ────────────────────────────────────────
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.padding(bottom = 8.dp)) {
                    listOf(
                        colors.primary                 to "Today",
                        colors.surface2                to "Rest Day",
                        colors.redX                    to "Vacation",
                        colors.green.copy(.3f)          to "Studied",
                        colors.red.copy(.15f)           to "Missed",
                    ).forEach { (c, label) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(9.dp).clip(CircleShape).background(c))
                            Spacer(Modifier.width(4.dp))
                            Text(label, fontFamily = BodyFontFamily, fontSize = 10.sp,
                                color = colors.text3)
                        }
                    }
                }

                // ── Calendar grid ─────────────────────────────────
                CalendarGrid(state = state, onDayClick = { vm.selectDay(it) })
                Spacer(Modifier.height(28.dp))

                // ── Vacation section ──────────────────────────────
                SectionTitle("Vacation / Leave Days")
                Spacer(Modifier.height(8.dp))

                // Add vacation date
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    DatePickerField(
                        value       = newVacDate,
                        onSelect    = { newVacDate = it },
                        modifier    = Modifier.weight(1f),
                        placeholder = "Add vacation date",
                    )
                    PrimaryButton("Add") {
                        if (newVacDate.isBlank()) {
                            toast.show("Pick a date first", true)
                        } else {
                            vm.addVacationDate(newVacDate)
                            newVacDate = ""
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))

                // Vacation list
                if (state.vacationDates.isEmpty()) {
                    Text("No vacation days added yet.", fontFamily = BodyFontFamily,
                        fontSize = 13.sp, color = colors.text3)
                } else {
                    state.vacationDates.forEach { dateStr ->
                        Row(
                            verticalAlignment     = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(colors.surface)
                                .border(1.dp, colors.border, RoundedCornerShape(6.dp))
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                                .padding(bottom = 4.dp),
                        ) {
                            Text(TimeUtils.formatDisplay(dateStr), fontFamily = MonoFontFamily,
                                fontSize = 13.sp, color = colors.text)
                            IconButton(
                                onClick  = { vm.removeVacationDate(dateStr) },
                                modifier = Modifier.size(28.dp),
                            ) {
                                Icon(Icons.Outlined.Close, "Remove vacation date",
                                    tint = colors.text3, modifier = Modifier.size(14.dp))
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                }
                Spacer(Modifier.height(32.dp))
            }
        }
    }

    // Day detail bottom sheet
    state.selectedDay?.let { day ->
        if (day.entries.isNotEmpty()) {
            CalendarDaySheet(
                day      = day,
                onDismiss = { vm.selectDay(null) },
            )
        }
    }
}

// ── Calendar Grid ─────────────────────────────────────────────────
@Composable
private fun CalendarGrid(
    state:      CalendarUiState,
    onDayClick: (CalendarDayInfo) -> Unit,
) {
    val colors    = MaterialTheme.studyColors
    val ym        = YearMonth.of(state.year, state.month)
    val firstDay  = "%04d-%02d-01".format(state.year, state.month)
    val startDow  = TimeUtils.dayOfWeek(firstDay)   // 0 = Sun
    val today     = TimeUtils.today()

    // Day-of-week header
    val dowNames = listOf("Sun","Mon","Tue","Wed","Thu","Fri","Sat")
    Row(modifier = Modifier.fillMaxWidth()) {
        dowNames.forEach { d ->
            Text(d, fontFamily = BodyFontFamily, fontWeight = FontWeight.SemiBold,
                fontSize = 10.sp, color = colors.text3, textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f))
        }
    }
    Spacer(Modifier.height(4.dp))

    // Build 6-week grid
    val totalCells = startDow + ym.lengthOfMonth()
    val rows       = (totalCells + 6) / 7

    for (row in 0 until rows) {
        Row(modifier = Modifier.fillMaxWidth()) {
            for (col in 0 until 7) {
                val cellIdx = row * 7 + col
                val dayNum  = cellIdx - startDow + 1

                if (dayNum < 1 || dayNum > ym.lengthOfMonth()) {
                    Box(modifier = Modifier.weight(1f).aspectRatio(1f))
                } else {
                    val dateStr = "%04d-%02d-%02d".format(state.year, state.month, dayNum)
                    val info    = state.days[dateStr]
                    CalendarDayCell(
                        dayNum   = dayNum,
                        dateStr  = dateStr,
                        info     = info,
                        isToday  = dateStr == today,
                        modifier = Modifier.weight(1f),
                        onClick  = { info?.let { onDayClick(it) } },
                    )
                }
            }
        }
        Spacer(Modifier.height(2.dp))
    }
}

// ── Calendar Day Cell ─────────────────────────────────────────────
@Composable
private fun CalendarDayCell(
    dayNum:  Int,
    dateStr: String,
    info:    CalendarDayInfo?,
    isToday: Boolean,
    modifier: Modifier = Modifier,
    onClick:  () -> Unit,
) {
    val colors  = MaterialTheme.studyColors

    val (bg, textColor, borderColor) = when {
        isToday             -> Triple(colors.primary,           colors.onPrimary, colors.primary)
        info?.isVacation == true -> Triple(colors.redX,         colors.red,       colors.red.copy(.25f))
        info?.isRestDay  == true -> Triple(colors.surface2,     colors.text3,     colors.border)
        info?.studied    == true -> Triple(colors.green.copy(.2f), colors.green,  colors.green.copy(.3f))
        info?.missed     == true -> Triple(colors.red.copy(.08f),  colors.red,    colors.red.copy(.15f))
        else                     -> Triple(colors.surface,      colors.text3,     colors.border)
    }

    val hasEntries = (info?.entries?.isNotEmpty() == true)

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .aspectRatio(1f)
            .padding(2.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
            .then(
                if (hasEntries || isToday) Modifier.clickable(
                    indication = null,
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                    onClick = onClick,
                ) else Modifier
            ),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text       = dayNum.toString(),
                fontFamily = MonoFontFamily,
                fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                fontSize   = 11.sp,
                color      = textColor,
            )
            // Dot indicator if entries exist
            if (hasEntries && !isToday) {
                Box(
                    modifier = Modifier.size(4.dp).clip(CircleShape)
                        .background(textColor.copy(.6f)),
                )
            }
        }
    }
}

// ── Calendar Day Detail Sheet ─────────────────────────────────────
@Composable
private fun CalendarDaySheet(
    day:      CalendarDayInfo,
    onDismiss: () -> Unit,
) {
    StudyPlanDialog(
        visible   = true,
        title     = TimeUtils.formatDisplay(day.date),
        onDismiss = onDismiss,
        footer    = { OutlineButton("Close", onClick = onDismiss) },
    ) {
        val colors = MaterialTheme.studyColors
        val total  = day.entries.sumOf { it.plannedSeconds }

        if (day.entries.isEmpty()) {
            Text("No sessions scheduled.", fontFamily = BodyFontFamily,
                fontSize = 13.sp, color = colors.text3)
        } else {
            day.entries.forEach { entry ->
                val lec  = day.lectures.find { it.id == entry.lectureId }
                val sub  = day.subjects.find { it.id == entry.subjectId }
                val done = entry.status == ScheduleEntryStatus.DONE ||
                           entry.status == ScheduleEntryStatus.PARTIAL_DONE

                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 7.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)) {
                        SubjectColorDot(sub?.color ?: "#888", size = 8.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text           = lec?.name ?: "—",
                            fontFamily     = BodyFontFamily,
                            fontSize       = 13.sp,
                            color          = if (done) colors.text3 else colors.text,
                            textDecoration = if (done) TextDecoration.LineThrough else null,
                            maxLines       = 1,
                            overflow       = TextOverflow.Ellipsis,
                        )
                    }
                    Text(TimeUtils.toDisplay(entry.plannedSeconds),
                        fontFamily = MonoFontFamily, fontSize = 12.sp,
                        color = colors.text3)
                }
                HorizontalDivider(color = colors.border, thickness = 1.dp)
            }
            Spacer(Modifier.height(8.dp))
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("Total", fontFamily = BodyFontFamily, fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp, color = colors.text)
                Text(TimeUtils.toDisplay(total), fontFamily = MonoFontFamily,
                    fontWeight = FontWeight.Bold, fontSize = 13.sp, color = colors.text)
            }
        }
    }
}

// ── Calendar nav button ───────────────────────────────────────────
@Composable
private fun CalNavBtn(
    icon:    androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
) {
    val colors = MaterialTheme.studyColors
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(32.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(colors.surface2)
            .border(1.dp, colors.border, RoundedCornerShape(6.dp))
            .clickable(indication = null,
                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                onClick = onClick),
    ) {
        Icon(icon, null, tint = colors.text, modifier = Modifier.size(16.dp))
    }
}


