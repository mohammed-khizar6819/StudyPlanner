package com.studyplan.app.data.db.dao

import androidx.room.*
import com.studyplan.app.data.db.entity.SessionLogEntity

@Dao
interface SessionLogDao {
    @Query("SELECT * FROM session_logs ORDER BY date DESC, id DESC")
    suspend fun getAll(): List<SessionLogEntity>

    @Query("SELECT COUNT(*) FROM session_logs")
    suspend fun count(): Int

    @Insert
    suspend fun insert(log: SessionLogEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(logs: List<SessionLogEntity>)

    /** Prune oldest entries to keep under maxCount (1000) */
    @Query("DELETE FROM session_logs WHERE id IN (SELECT id FROM session_logs ORDER BY id ASC LIMIT :excess)")
    suspend fun pruneOldest(excess: Int)

    @Query("DELETE FROM session_logs")
    suspend fun deleteAll()
}
