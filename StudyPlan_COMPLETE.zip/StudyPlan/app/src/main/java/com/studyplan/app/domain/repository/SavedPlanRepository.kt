package com.studyplan.app.domain.repository
import com.studyplan.app.domain.model.SavedPlan
import kotlinx.coroutines.flow.Flow

interface SavedPlanRepository {
    fun observeAll(): Flow<List<SavedPlan>>
    suspend fun getAll(): List<SavedPlan>
    suspend fun getById(id: String): SavedPlan?
    suspend fun insert(plan: SavedPlan)
    suspend fun delete(id: String)
    suspend fun deleteAll()
}
