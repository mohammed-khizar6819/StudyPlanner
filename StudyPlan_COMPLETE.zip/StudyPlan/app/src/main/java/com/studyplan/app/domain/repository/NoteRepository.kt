package com.studyplan.app.domain.repository
import com.studyplan.app.domain.model.Note
import com.studyplan.app.domain.model.NoteType
import kotlinx.coroutines.flow.Flow

interface NoteRepository {
    fun observeAll(): Flow<List<Note>>
    suspend fun getAll(): List<Note>
    fun observeForLecture(lectureId: String): Flow<List<Note>>
    suspend fun getForLecture(lectureId: String): List<Note>
    suspend fun getByType(type: NoteType): List<Note>
    suspend fun getKeyPointsForLecture(lectureId: String): List<Note>
    suspend fun insert(note: Note)
    suspend fun insertAll(notes: List<Note>)
    suspend fun setResolved(id: String, resolved: Boolean)
    suspend fun delete(id: String)
    suspend fun deleteForLecture(lectureId: String)
    suspend fun deleteAll()
}
