package com.studyplan.app.domain.engine

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import com.studyplan.app.data.db.entity.LectureEntity
import com.studyplan.app.data.db.entity.MetaEntity
import com.studyplan.app.data.db.entity.NoteEntity
import com.studyplan.app.data.db.entity.SavedPlanEntity
import com.studyplan.app.data.db.entity.ScheduleEntryEntity
import com.studyplan.app.data.db.entity.SessionLogEntity
import com.studyplan.app.data.db.entity.SettingsEntity
import com.studyplan.app.data.db.entity.SubjectEntity
import com.studyplan.app.data.db.DatabaseInitializer
import com.studyplan.app.data.json.BackupMapper
import com.studyplan.app.data.json.StudyPlanBackup
import com.studyplan.app.domain.model.*
import com.studyplan.app.domain.repository.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Port of HTML Plans object (multi-plan manager).
 * Snapshots the full app state to a SavedPlan row in Room.
 * Named plans can be saved, listed, loaded, and deleted.
 */
@Singleton
class MultiPlanManager @Inject constructor(
    private val subjectRepo:    SubjectRepository,
    private val lectureRepo:    LectureRepository,
    private val scheduleRepo:   ScheduleRepository,
    private val noteRepo:       NoteRepository,
    private val sessionRepo:    SessionLogRepository,
    private val settingsRepo:   SettingsRepository,
    private val metaRepo:       MetaRepository,
    private val savedPlanRepo:  SavedPlanRepository,
    private val schedulerEngine: SchedulerEngine,
    private val statsEngine:     StatsEngine,
    private val dbInitializer:   DatabaseInitializer,
) {
    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()
    private val adapter = moshi.adapter(StudyPlanBackup::class.java)

    // ── List saved plans ──────────────────────────────────────────
    suspend fun list(): List<SavedPlan> = savedPlanRepo.getAll()

    fun observeAll() = savedPlanRepo.observeAll()

    // ── Save current app state as a named snapshot ────────────────
    suspend fun save(name: String): String = withContext(Dispatchers.IO) {
        val today      = TimeUtils.today()
        val settings   = settingsRepo.get()
        val meta       = metaRepo.get()
        val subjects   = subjectRepo.getAll()
        val lectures   = lectureRepo.getAll()
        val entries    = scheduleRepo.getInRange("2000-01-01", "2099-12-31")
        val notes      = noteRepo.getAll()
        val logs       = sessionRepo.getAll()

        // Convert entities to backup via BackupMapper
        // We need SettingsEntity + MetaEntity — go via domain → entity path
        val settingsEnt = settings?.let { s ->
            SettingsEntity.fromDomain(s)
        }
        val metaEnt = meta?.let { m ->
            MetaEntity.fromDomain(m)
        }
        val subjectEnts  = subjects.map { SubjectEntity.fromDomain(it) }
        val lectureEnts  = lectures.map { LectureEntity.fromDomain(it) }
        val entryEnts    = entries.map { ScheduleEntryEntity.fromDomain(it) }
        val noteEnts     = notes.map { NoteEntity.fromDomain(it) }
        val logEnts      = logs.map { SessionLogEntity.fromDomain(it) }

        val backup      = BackupMapper.toBackup(settingsEnt, metaEnt, subjectEnts,
            lectureEnts, entryEnts, noteEnts, logEnts)
        val json        = adapter.toJson(backup)
        val planId      = "plan_${System.currentTimeMillis()}"

        savedPlanRepo.insert(SavedPlan(
            id           = planId,
            name         = name,
            savedAt      = today,
            subjectCount = subjects.size,
            lectureCount = lectures.size,
            snapshotJson = json,
        ))
        planId
    }

    // ── Load a snapshot into the live database ────────────────────
    suspend fun load(planId: String) = withContext(Dispatchers.IO) {
        val plan = savedPlanRepo.getById(planId) ?: return@withContext
        val backup = adapter.fromJson(plan.snapshotJson) ?: return@withContext
        val restored = BackupMapper.fromBackup(backup)

        // Wipe current data and replace with snapshot
        clearAll()

        settingsRepo.upsert(restored.settings.toDomain())
        metaRepo.upsert(restored.meta.toDomain())
        subjectRepo.insertAll(restored.subjects.map { it.toDomain() })
        lectureRepo.insertAll(restored.lectures.map { it.toDomain() })
        scheduleRepo.insertAll(restored.entries.map { it.toDomain() })
        noteRepo.insertAll(restored.notes.map { it.toDomain() })
        sessionRepo.insertAll(restored.sessionLogs.map { it.toDomain() })

        statsEngine.invalidate()
    }

    // ── Create a blank new plan (auto-saves current first) ────────
    suspend fun newBlank(name: String) = withContext(Dispatchers.IO) {
        // Auto-save current before switching
        save("Auto-save before new plan")

        val today = TimeUtils.today()
        clearAll()

        settingsRepo.upsert(AppSettings(
            startDate = today, dailyStudyHours = 6.0, bufferDayOfWeek = 0,
            weeklyGoalHours = 0.0, interleaveSubjects = false,
            intensityRampEnabled = false, intensityStartHours = 4.0,
            intensityEndHours = 8.0, examLockDays = 7,
            alarmEnabled = false, alarmHour = 8, alarmMinute = 0,
            notifEnabled = false, notifHour = 9, vacationDates = emptyList(),
        ))
        metaRepo.upsert(AppMeta(
            initialized = true, version = DatabaseInitializer.CURRENT_VERSION,
            lastBuiltDate = today, onboarded = true, achievedMilestones = emptyList(),
        ))
        statsEngine.invalidate()
    }

    // ── Delete a saved plan ───────────────────────────────────────
    suspend fun delete(planId: String) = savedPlanRepo.delete(planId)

    // ── Wipe all live data (used before restore) ──────────────────
    private suspend fun clearAll() {
        scheduleRepo.deleteAll()
        noteRepo.deleteAll()
        sessionRepo.deleteAll()
        lectureRepo.deleteAll()
        subjectRepo.deleteAll()
        settingsRepo.deleteAll()
        metaRepo.deleteAll()
    }
}
