package com.studyplan.app.worker

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.studyplan.app.MainActivity
import com.studyplan.app.R
import com.studyplan.app.StudyPlanApplication
import com.studyplan.app.domain.engine.SchedulerEngine
import com.studyplan.app.domain.model.ScheduleEntryStatus
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

/**
 * Fires a daily study reminder notification at the user-set hour.
 * Counts today's pending sessions and includes the count in the message.
 */
@HiltWorker
class DailyReminderWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params:  WorkerParameters,
    private val schedulerEngine: SchedulerEngine,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val todayPlan = schedulerEngine.getTodayPlan()
            val pending   = todayPlan.count { it.entry.status == ScheduleEntryStatus.SCHEDULED }

            val message = if (pending > 0)
                "You have $pending lecture${if (pending != 1) "s" else ""} scheduled today. Let's go!"
            else
                "No lectures today — check your plan or enjoy the rest!"

            val tapIntent = Intent(applicationContext, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            val tapPending = PendingIntent.getActivity(
                applicationContext, 0, tapIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            val notification = NotificationCompat.Builder(
                applicationContext, StudyPlanApplication.CHANNEL_DAILY_REMINDER)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("📚 Daily Study Reminder")
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(tapPending)
                .setAutoCancel(true)
                .build()

            (applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .notify(REMINDER_NOTIFICATION_ID, notification)

            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        const val REMINDER_NOTIFICATION_ID = 1002
        const val WORK_NAME                = "daily_study_reminder"
    }
}

/**
 * Schedules DailyReminderWorker at the user's preferred notification hour.
 * Uses REPLACE so changing the hour reschedules correctly.
 */
class NotifWorkerScheduler(private val context: Context) {

    fun schedule(hour: Int) {
        // Calculate initial delay to first firing at the target hour
        val now      = java.util.Calendar.getInstance()
        val target   = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, hour)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            if (timeInMillis <= now.timeInMillis) add(java.util.Calendar.DAY_OF_YEAR, 1)
        }
        val delayMs  = target.timeInMillis - now.timeInMillis

        val request  = PeriodicWorkRequestBuilder<DailyReminderWorker>(1, TimeUnit.DAYS)
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .setConstraints(Constraints.Builder()
                .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                .build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            DailyReminderWorker.WORK_NAME,
            ExistingPeriodicWorkPolicy.REPLACE,
            request,
        )
    }

    fun cancel() {
        WorkManager.getInstance(context).cancelUniqueWork(DailyReminderWorker.WORK_NAME)
    }
}
