package com.studyplan.app.domain.engine

import com.studyplan.app.domain.model.*
import com.studyplan.app.domain.repository.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.ceil
import kotlin.math.min
import kotlin.math.max
import kotlin.math.roundToLong

/**
 * Full port of the HTML Scheduler object.
 *
 * Every algorithm, every flag, every edge case from the HTML is reproduced here.
 * Read the inline comments alongside the original JS for cross-reference.
 */
@Singleton
class SchedulerEngine @Inject constructor(
    private val subjectRepo:  SubjectRepository,
    private val lectureRepo:  LectureRepository,
    private val scheduleRepo: ScheduleRepository,
    private val settingsRepo: SettingsRepository,
    private val metaRepo:     MetaRepository,
    private val sessionRepo:  SessionLogRepository,
) {
    companion object {
        const val TOLERANCE       = 0.80        // matches HTML Scheduler.TOLERANCE
        const val MAX_SESSION_LOGS = 1000
    }

    // ═══════════════════════════════════════════════════════════════
    //  buildSchedule
    //
    //  forceRebuildToday = false (default):
    //    Preserve today's entries as-is (used after completing a session —
    //    we don't want to wipe done/partial_done marks).
    //
    //  forceRebuildToday = true:
    //    Wipe today's scheduled entries and rebuild them, then re-apply
    //    any done/partial_done marks from lecture.todayStudied.
    //    Used when user changes daily hours, buffer day, etc.
    // ═══════════════════════════════════════════════════════════════
    suspend fun buildSchedule(forceRebuildToday: Boolean = false) =
        withContext(Dispatchers.Default) {
            val settings  = settingsRepo.get() ?: return@withContext
            val subjects  = subjectRepo.getAll()
            val lectures  = lectureRepo.getAll()
            val today     = TimeUtils.today()

            if (subjects.isEmpty()) return@withContext

            // ── 1. Snapshot today's entries before any wipe ───────
            val todayEntries       = scheduleRepo.getForDate(today)
            val todayScheduledIds  = todayEntries.map { it.lectureId }.toSet()

            // ── 2. Delete future schedule (today or from-today if force) ──
            if (forceRebuildToday) {
                scheduleRepo.deleteFromDate(today)
            } else {
                // Delete only future (tomorrow onwards)
                val tomorrow = TimeUtils.addDays(today, 1)
                scheduleRepo.deleteFromDate(tomorrow)
            }

            // ── 3. Determine earliest deadline ────────────────────
            val nearestDeadline = subjects
                .filter { it.deadline.isNotEmpty() }
                .minByOrNull { it.deadline }
                ?.deadline

            // ── 4. Build queues per subject ───────────────────────
            val queues = buildQueues(subjects, lectures)

            // ── 5. Walk forward from start date, filling slots ────
            val startDate = settings.startDate.ifEmpty { today }
            val maxDays   = 365 * 2   // build at most 2 years forward

            val entriesToInsert = mutableListOf<ScheduleEntry>()
            val scheduleFrom = maxOf(startDate, today)   // never schedule in the past

            for (dayOffset in 0 until maxDays) {
                val date = TimeUtils.addDays(scheduleFrom, dayOffset.toLong())


                // Skip buffer/rest day
                if (settings.bufferDayOfWeek != -1 &&
                    TimeUtils.dayOfWeek(date) == settings.bufferDayOfWeek) continue

                // Skip vacation days
                if (settings.vacationDates.contains(date)) continue

                // Check if all queues are empty → nothing left to schedule
                if (queues.values.all { it.isEmpty() }) break

                // Skip today if not force-rebuilding (preserve existing)
                if (date == today && !forceRebuildToday) continue

                // ── Capacity per subject for this day ─────────────
                val capacity = calcCapacity(subjects, settings, date, nearestDeadline)

                // ── Build day entries ──────────────────────────────
                val dayEntries = if (settings.interleaveSubjects) {
                    buildDayInterleaved(subjects, queues, capacity, settings, date)
                } else {
                    buildDayBlock(subjects, queues, capacity, settings, date)
                }

                entriesToInsert.addAll(dayEntries)

                // Stop if all queues drained
                if (queues.values.all { it.isEmpty() }) break
            }

            // ── 6. Batch insert new entries ───────────────────────
            scheduleRepo.insertAll(entriesToInsert)

            // ── 7. Pass 2 — restore today's done/partial marks ────
            // After a force-rebuild we re-apply todayStudied from lecture state
            // so work logged today is never lost.
            if (forceRebuildToday) {
                val rebuiltToday = scheduleRepo.getForDate(today).toMutableList()
                val mutableLectures = lectures.associateBy { it.id }

                rebuiltToday.forEach { entry ->
                    val lec = mutableLectures[entry.lectureId] ?: return@forEach
                    when {
                        lec.status == LectureStatus.COMPLETE -> {
                            scheduleRepo.updateCompletion(entry.id,
                                entry.plannedSeconds, ScheduleEntryStatus.DONE)
                        }
                        lec.todayDate == today && lec.todayStudied > 0 -> {
                            val studied = lec.todayStudied
                            val newStatus = if (studied >= entry.plannedSeconds)
                                ScheduleEntryStatus.DONE else ScheduleEntryStatus.PARTIAL_DONE
                            scheduleRepo.updateCompletion(entry.id, studied, newStatus)
                        }
                    }
                }
            }

            // ── 8. Update lastBuiltDate ───────────────────────────
            metaRepo.updateLastBuiltDate(today)
        }

    // ═══════════════════════════════════════════════════════════════
    //  Build queues per subject
    //  Mirrors HTML Scheduler._buildQueues()
    // ═══════════════════════════════════════════════════════════════
    private fun buildQueues(
        subjects: List<Subject>,
        lectures: List<Lecture>,
    ): MutableMap<String, ArrayDeque<QueueItem>> {
        val bySubject = lectures.groupBy { it.subjectId }
        val queues    = mutableMapOf<String, ArrayDeque<QueueItem>>()

        subjects.forEach { sub ->
            val subLectures = (bySubject[sub.id] ?: emptyList())
                .sortedBy { it.sequence }

            val queue = ArrayDeque<QueueItem>()

            // Pending and partial lectures
            subLectures
                .filter { it.status != LectureStatus.COMPLETE && it.remaining > 0 }
                .forEach { lec ->
                    queue.addLast(QueueItem(
                        id             = lec.id,
                        remaining      = lec.remaining,
                        isContinuation = lec.status == LectureStatus.PARTIAL,
                        isRevision     = false,
                    ))
                }

            // Revision rounds — only when all lectures complete & revision enabled
            if (sub.revisionEnabled && queue.isEmpty()) {
                val completed = subLectures.filter { it.status == LectureStatus.COMPLETE }
                if (completed.isNotEmpty()) {
                    val today = TimeUtils.today()
                    // Spaced repetition: weight = daysSinceComplete × difficultyMult
                    val weighted = completed
                        .map { lec ->
                            val days = TimeUtils.diffDays(
                                lec.completedOn ?: today, today).toDouble()
                            val weight = days * lec.difficulty.weight
                            Pair(lec, weight)
                        }
                        .sortedByDescending { it.second }

                    val revRound = sub.revisionRound % 3
                    val speedFactor = when (revRound) { 0 -> 1.0; 1 -> 0.5; else -> 0.25 }

                    weighted.forEach { (lec, _) ->
                        queue.addLast(QueueItem(
                            id             = lec.id,
                            remaining      = ceil(lec.duration * speedFactor).toLong(),
                            isContinuation = false,
                            isRevision     = true,
                            revisionRound  = revRound + 1,
                        ))
                    }
                }
            }

            queues[sub.id] = queue
        }
        return queues
    }

    // ═══════════════════════════════════════════════════════════════
    //  Capacity calculation — mirrors HTML _calcCapacity()
    //  Returns seconds available per subject for a given day.
    // ═══════════════════════════════════════════════════════════════
    private fun calcCapacity(
        subjects:       List<Subject>,
        settings:       AppSettings,
        dateStr:        String,
        nearestDeadline: String?,
    ): Map<String, Long> {
        if (subjects.isEmpty()) return emptyMap()

        var rampMult = 1.0
        if (settings.intensityRampEnabled && nearestDeadline != null) {
            val startDate = settings.startDate.ifEmpty { TimeUtils.today() }
            if (nearestDeadline > startDate) {
                val totalDays   = TimeUtils.diffDays(startDate, nearestDeadline).toDouble()
                val elapsed     = max(0.0, TimeUtils.diffDays(startDate, dateStr).toDouble())
                val t           = min(1.0, elapsed / totalDays)
                val baseHours   = settings.intensityStartHours
                val peakHours   = settings.intensityEndHours
                val rampHours   = baseHours + (peakHours - baseHours) * t
                val normalBase  = subjects.sumOf { it.dailyHours }
                rampMult = if (normalBase > 0) rampHours * subjects.size / normalBase else 1.0
            }
        }

        // Check exam lock — don't schedule subject N days before its deadline
        return subjects.associate { sub ->
            val locked = sub.deadline.isNotEmpty() &&
                TimeUtils.diffDays(dateStr, sub.deadline) < settings.examLockDays
            val capSeconds = if (locked) 0L
                else TimeUtils.hoursToSeconds(
                    sub.dailyHours * min(rampMult, 3.0))
            sub.id to capSeconds
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  Block scheduling: each subject fills its full allocation
    //  before moving to the next subject.
    // ═══════════════════════════════════════════════════════════════
    private fun buildDayBlock(
        subjects:  List<Subject>,
        queues:    MutableMap<String, ArrayDeque<QueueItem>>,
        capacity:  Map<String, Long>,
        settings:  AppSettings,
        dateStr:   String,
    ): List<ScheduleEntry> {
        val entries = mutableListOf<ScheduleEntry>()
        subjects.sortedBy { it.priority }.forEach { sub ->
            val queue = queues[sub.id] ?: return@forEach
            var remaining = capacity[sub.id] ?: 0L
            while (remaining > 0 && queue.isNotEmpty()) {
                val item = queue.first()
                val slice = min(item.remaining, remaining)
                if (slice <= 0) break
                entries.add(ScheduleEntry(
                    id               = 0,
                    date             = dateStr,
                    lectureId        = item.id,
                    subjectId        = sub.id,
                    plannedSeconds   = slice,
                    completedSeconds = 0,
                    status           = ScheduleEntryStatus.SCHEDULED,
                ))
                item.remaining -= slice
                remaining      -= slice
                if (item.remaining <= 0) queue.removeFirst()
            }
        }
        return entries
    }

    // ═══════════════════════════════════════════════════════════════
    //  Interleave scheduling: subjects alternate within a day.
    //  Each round: every subject gets a slice = capacity/roundCount.
    // ═══════════════════════════════════════════════════════════════
    private fun buildDayInterleaved(
        subjects:  List<Subject>,
        queues:    MutableMap<String, ArrayDeque<QueueItem>>,
        capacity:  Map<String, Long>,
        settings:  AppSettings,
        dateStr:   String,
    ): List<ScheduleEntry> {
        val entries   = mutableListOf<ScheduleEntry>()
        val remaining = capacity.toMutableMap()
        val ROUNDS    = 4   // divide each subject's day into 4 interleaved slots

        repeat(ROUNDS) {
            subjects.sortedBy { it.priority }.forEach { sub ->
                val queue = queues[sub.id] ?: return@forEach
                if (queue.isEmpty()) return@forEach
                val totalCap  = capacity[sub.id] ?: 0L
                val sliceCap  = totalCap / ROUNDS
                if (sliceCap <= 0) return@forEach
                var rem = min(remaining[sub.id] ?: 0L, sliceCap)
                while (rem > 0 && queue.isNotEmpty()) {
                    val item  = queue.first()
                    val slice = min(item.remaining, rem)
                    if (slice <= 0) break
                    entries.add(ScheduleEntry(
                        id               = 0,
                        date             = dateStr,
                        lectureId        = item.id,
                        subjectId        = sub.id,
                        plannedSeconds   = slice,
                        completedSeconds = 0,
                        status           = ScheduleEntryStatus.SCHEDULED,
                    ))
                    item.remaining        -= slice
                    rem                   -= slice
                    remaining[sub.id]      = (remaining[sub.id] ?: 0L) - slice
                    if (item.remaining <= 0) queue.removeFirst()
                }
            }
        }
        return entries
    }

    // ═══════════════════════════════════════════════════════════════
    //  getTodayPlan — mirrors HTML Scheduler.getTodayPlan()
    //  Returns entries for today, synced with lecture status,
    //  sorted: pending first, done/partial last, then by sequence.
    // ═══════════════════════════════════════════════════════════════
    suspend fun getTodayPlan(): List<TodayEntry> = withContext(Dispatchers.Default) {
        val today    = TimeUtils.today()
        val entries  = scheduleRepo.getForDate(today)
        val lectures = lectureRepo.getAll().associateBy { it.id }
        val subjects = subjectRepo.getAll().associateBy { it.id }

        entries.mapNotNull { entry ->
            val lec  = lectures[entry.lectureId]  ?: return@mapNotNull null
            val subj = subjects[entry.subjectId]  ?: return@mapNotNull null

            // Sync entry status with lecture status (edge case fix from HTML)
            val syncedStatus = if (entry.status == ScheduleEntryStatus.SCHEDULED &&
                lec.status == LectureStatus.COMPLETE) ScheduleEntryStatus.DONE
            else entry.status

            TodayEntry(entry = entry.copy(status = syncedStatus), lecture = lec, subject = subj)
        }.sortedWith(
            compareBy(
                { if (it.entry.status == ScheduleEntryStatus.DONE ||
                      it.entry.status == ScheduleEntryStatus.PARTIAL_DONE) 1 else 0 },
                { it.lecture.sequence },
            )
        )
    }

    // ═══════════════════════════════════════════════════════════════
    //  completeSession — marks today's planned portion as done.
    //  Mirrors HTML Scheduler.completeSession().
    // ═══════════════════════════════════════════════════════════════
    suspend fun completeSession(lectureId: String) = withContext(Dispatchers.Default) {
        val today = TimeUtils.today()
        val entry = scheduleRepo.getForDate(today).find { it.lectureId == lectureId }
        val lec   = lectureRepo.getById(lectureId) ?: return@withContext

        if (entry?.status == ScheduleEntryStatus.DONE) return@withContext

        val planned = entry?.plannedSeconds ?: lec.remaining
        val done    = min(planned, lec.remaining)

        val newRemaining = max(0L, lec.remaining - done)
        val newStatus    = if (newRemaining == 0L) LectureStatus.COMPLETE else LectureStatus.PARTIAL
        val completedOn  = if (newStatus == LectureStatus.COMPLETE) today else lec.completedOn

        // Accumulate today's studied (not replace — matches HTML comment)
        val newTodayStudied = if (lec.todayDate == today) lec.todayStudied + done else done

        lectureRepo.updateProgress(lec.copy(
            remaining    = newRemaining,
            status       = newStatus,
            completedOn  = completedOn,
            todayStudied = newTodayStudied,
            todayDate    = today,
        ))

        if (entry != null) {
            val completedSecs = (entry.completedSeconds) + done
            val entryStatus   = if (newStatus == LectureStatus.COMPLETE)
                ScheduleEntryStatus.DONE else ScheduleEntryStatus.PARTIAL_DONE
            scheduleRepo.updateCompletion(entry.id, completedSecs, entryStatus)
        }

        // Log session for TOD heatmap
        logSession(today, done, lectureId, lec.subjectId)

        buildSchedule(forceRebuildToday = false)
    }

    // ═══════════════════════════════════════════════════════════════
    //  partialComplete — replace-semantics partial logging.
    //  Mirrors HTML Scheduler.partialComplete().
    //
    //  "replace" not "add": if user logged 1h and now logs 2h,
    //  total becomes 2h (not 3h). We restore previous todayStudied
    //  first, then apply the new amount.
    // ═══════════════════════════════════════════════════════════════
    suspend fun partialComplete(lectureId: String, completedSeconds: Long): Boolean =
        withContext(Dispatchers.Default) {
            val today = TimeUtils.today()
            val lec   = lectureRepo.getById(lectureId) ?: return@withContext false
            val entry = scheduleRepo.getForDate(today).find { it.lectureId == lectureId }

            if (lec.status == LectureStatus.COMPLETE ||
                entry?.status == ScheduleEntryStatus.DONE) return@withContext false

            // Restore previous partial for today (replace, not add)
            val prevDone    = if (lec.todayDate == today) lec.todayStudied else 0L
            val restoredRem = min(lec.duration, lec.remaining + prevDone)

            // Apply new amount
            val done        = min(completedSeconds, restoredRem)
            val newRemaining = max(0L, restoredRem - done)
            val newStatus   = if (newRemaining == 0L) LectureStatus.COMPLETE else LectureStatus.PARTIAL
            val completedOn = if (newStatus == LectureStatus.COMPLETE) today else null

            lectureRepo.updateProgress(lec.copy(
                remaining    = newRemaining,
                status       = newStatus,
                completedOn  = completedOn,
                todayStudied = done,          // replace semantics
                todayDate    = today,
            ))

            if (entry != null) {
                val entryStatus = if (newStatus == LectureStatus.COMPLETE)
                    ScheduleEntryStatus.DONE else ScheduleEntryStatus.PARTIAL_DONE
                scheduleRepo.updateCompletion(entry.id, done, entryStatus)
            }

            buildSchedule(forceRebuildToday = false)
            return@withContext true
        }

    // ── Session log helper ────────────────────────────────────────
    private suspend fun logSession(date: String, seconds: Long, lectureId: String, subjectId: String) {
        val hour = java.time.LocalTime.now().hour
        sessionRepo.insert(SessionLog(0, date, hour, seconds, lectureId, subjectId))
        sessionRepo.pruneToLimit(MAX_SESSION_LOGS)
    }

    // ── Internal queue item ───────────────────────────────────────
    data class QueueItem(
        val id:             String,
        var remaining:      Long,
        val isContinuation: Boolean,
        val isRevision:     Boolean,
        val revisionRound:  Int = 0,
    )
}

/** Combines a ScheduleEntry with its resolved Lecture and Subject */
data class TodayEntry(
    val entry:   ScheduleEntry,
    val lecture: com.studyplan.app.domain.model.Lecture,
    val subject: com.studyplan.app.domain.model.Subject,
)
