@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.scaffold

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studyplan.app.domain.engine.StatsEngine
import com.studyplan.app.domain.engine.UndoManager
import com.studyplan.app.domain.engine.TimeUtils
import com.studyplan.app.domain.model.ScheduleEntryStatus
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ScaffoldViewModel @Inject constructor(
    private val statsEngine: StatsEngine,
    private val undoManager: UndoManager,
) : ViewModel() {

    val undoPending = undoManager.pending.stateIn(
        viewModelScope, SharingStarted.Eagerly, null)

    // Today's plan progress for sidebar widget
    private val _todayDone  = MutableStateFlow(0)
    private val _todayTotal = MutableStateFlow(0)
    val todayDone:  StateFlow<Int> = _todayDone.asStateFlow()
    val todayTotal: StateFlow<Int> = _todayTotal.asStateFlow()

    init { loadTodayProgress() }

    private fun loadTodayProgress() {
        viewModelScope.launch {
            val stats = statsEngine.getStats()
            _todayDone.value  = stats.todayDone
            _todayTotal.value = stats.todayTotal
        }
    }

    fun executeUndo() {
        viewModelScope.launch { undoManager.execute() }
    }
}
