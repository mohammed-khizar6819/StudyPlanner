@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.components

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyplan.app.domain.engine.TimeUtils
import com.studyplan.app.ui.theme.BodyFontFamily
import com.studyplan.app.ui.theme.MonoFontFamily
import com.studyplan.app.ui.theme.StudyPlanRadius
import com.studyplan.app.ui.theme.studyColors
import java.util.Calendar

@Composable
fun DatePickerField(
    value:       String,
    onSelect:    (String) -> Unit,
    modifier:    Modifier = Modifier,
    label:       String?  = null,
    placeholder: String   = "Pick a date",
) {
    val context = LocalContext.current
    val colors  = MaterialTheme.studyColors
    val cal     = Calendar.getInstance()
    if (value.isNotEmpty()) {
        runCatching {
            val p = value.split("-").map { it.toInt() }
            cal.set(p[0], p[1] - 1, p[2])
        }
    }
    if (label != null) FieldLabel(label)
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(StudyPlanRadius.md))
            .background(colors.surface)
            .border(1.dp, colors.border, RoundedCornerShape(StudyPlanRadius.md))
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() },
                onClick = {
                    DatePickerDialog(context, { _, y, m, d ->
                        onSelect("%04d-%02d-%02d".format(y, m + 1, d))
                    }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                })
            .padding(horizontal = 12.dp, vertical = 9.dp),
    ) {
        Icon(Icons.Outlined.CalendarMonth, null, tint = colors.text3, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            text       = if (value.isEmpty()) placeholder else TimeUtils.formatDisplay(value),
            fontFamily = if (value.isEmpty()) Figtree else JetBrainsMono,
            fontSize   = 13.sp,
            color      = if (value.isEmpty()) colors.text3 else colors.text,
        )
    }
}

@Composable
fun TimePickerField(
    hour:     Int,
    minute:   Int,
    onSelect: (hour: Int, minute: Int) -> Unit,
    modifier: Modifier = Modifier,
    label:    String?  = null,
) {
    val context = LocalContext.current
    val colors  = MaterialTheme.studyColors
    if (label != null) FieldLabel(label)
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(StudyPlanRadius.md))
            .background(colors.surface)
            .border(1.dp, colors.border, RoundedCornerShape(StudyPlanRadius.md))
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() },
                onClick = { TimePickerDialog(context, { _, h, m -> onSelect(h, m) }, hour, minute, false).show() })
            .padding(horizontal = 12.dp, vertical = 9.dp),
    ) {
        Icon(Icons.Outlined.Schedule, null, tint = colors.text3, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp))
        val displayHour = if (hour == 0 || hour == 12) 12 else hour % 12
        val amPm        = if (hour < 12) "AM" else "PM"
        Text("%02d:%02d %s".format(displayHour, minute, amPm),
            fontFamily = MonoFontFamily, fontSize = 13.sp, color = colors.text)
    }
}

@Composable
fun DurationField(
    value:         String,
    onValueChange: (String) -> Unit,
    modifier:      Modifier = Modifier,
    label:         String   = "Duration (hh:mm:ss)",
) {
    FieldLabel(label)
    StudyTextField(
        value         = value,
        onValueChange = onValueChange,
        placeholder   = "01:30:00",
        modifier      = modifier,
        keyboardType  = KeyboardType.Ascii,
    )
}
