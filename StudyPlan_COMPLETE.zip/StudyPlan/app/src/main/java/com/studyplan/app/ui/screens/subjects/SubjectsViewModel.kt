@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.subjects

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studyplan.app.domain.engine.*
import com.studyplan.app.domain.model.*
import com.studyplan.app.domain.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SubjectWithStats(
    val subject:        Subject,
    val totalLectures:  Int,
    val doneLectures:   Int,
    val remainingSecs:  Long,
    val pct:            Int,
    val deadline:       String,
    val examDate:       String,
)

data class SubjectsUiState(
    val isLoading: Boolean                  = true,
    val items:     List<SubjectWithStats>   = emptyList(),
)

@HiltViewModel
class SubjectsViewModel @Inject constructor(
    private val subjectRepo:     SubjectRepository,
    private val lectureRepo:     LectureRepository,
    private val scheduleRepo:    ScheduleRepository,
    private val noteRepo:        NoteRepository,
    private val schedulerEngine: SchedulerEngine,
    private val statsEngine:     StatsEngine,
) : ViewModel() {

    private val _state = MutableStateFlow(SubjectsUiState())
    val state: StateFlow<SubjectsUiState> = _state.asStateFlow()

    private val _toast = MutableSharedFlow<String>()
    val toast: SharedFlow<String> = _toast.asSharedFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            val subjects  = subjectRepo.getAll()
            val lectures  = lectureRepo.getAll().groupBy { it.subjectId }

            val items = subjects.map { sub ->
                val lecs     = lectures[sub.id] ?: emptyList()
                val done     = lecs.count { it.status == LectureStatus.COMPLETE }
                val total    = lecs.size
                val remaining = lecs.sumOf { it.remaining }
                val pct      = if (total > 0) (done * 100 / total) else 0
                SubjectWithStats(sub, total, done, remaining, pct, sub.deadline, sub.examDate)
            }
            _state.update { it.copy(isLoading = false, items = items) }
        }
    }

    fun addSubject(
        name: String, fullName: String, color: String,
        dailyHours: Double, priority: Int,
        deadline: String, examDate: String,
        settings: AppSettings?,
    ) {
        viewModelScope.launch {
            val id = "sub_${System.currentTimeMillis()}"
            val today = TimeUtils.today()
            subjectRepo.insert(Subject(
                id = id, name = name.uppercase().take(10), fullName = fullName,
                deadline = deadline, examDate = examDate,
                dailyHours = dailyHours, priority = priority, color = color,
                createdAt = today, revisionEnabled = false, revisionRound = 0,
            ))
            // If single subject — sync global daily hours
            val allSubs = subjectRepo.getAll()
            if (allSubs.size == 1 && settings != null) {
                // already set by caller if needed
            }
            schedulerEngine.buildSchedule(forceRebuildToday = true)
            statsEngine.invalidate()
            _toast.emit("Subject added!")
            load()
        }
    }

    fun updateSubject(subject: Subject) {
        viewModelScope.launch {
            subjectRepo.update(subject)
            // Auto-bump global hours if subject hours exceed current total
            val allSubs = subjectRepo.getAll()
            schedulerEngine.buildSchedule(forceRebuildToday = true)
            statsEngine.invalidate()
            _toast.emit("Updated!")
            load()
        }
    }

    fun deleteSubject(subjectId: String) {
        viewModelScope.launch {
            // Cascade: delete orphaned schedule entries, notes
            val lecs = lectureRepo.getBySubject(subjectId)
            val lecIds = lecs.map { it.id }
            noteRepo.getAll().filter { it.lectureId in lecIds }
                .forEach { noteRepo.delete(it.id) }
            scheduleRepo.deletePastIncompleteForLectures(lecIds, TimeUtils.today())
            // Room FK CASCADE handles notes + lectures automatically via ForeignKey.CASCADE
            subjectRepo.delete(subjectId)
            schedulerEngine.buildSchedule(forceRebuildToday = true)
            statsEngine.invalidate()
            _toast.emit("Subject deleted")
            load()
        }
    }

    fun toggleRevision(subject: Subject) {
        viewModelScope.launch {
            val updated = subject.copy(
                revisionEnabled = !subject.revisionEnabled,
                revisionRound   = if (!subject.revisionEnabled) 0 else subject.revisionRound,
            )
            subjectRepo.update(updated)
            schedulerEngine.buildSchedule(forceRebuildToday = false)
            _toast.emit(if (updated.revisionEnabled) "Revision mode ON for ${subject.name}"
                        else "Revision mode OFF")
            load()
        }
    }
}
