# ════════════════════════════════════════════════════════════════
#  StudyPlan — ProGuard / R8 Rules
#  Applied only in release builds (isMinifyEnabled = true)
# ════════════════════════════════════════════════════════════════

# ── Room ─────────────────────────────────────────────────────────
# Keep all Room entity classes and their fields
-keep class * extends androidx.room.RoomDatabase { *; }
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao interface * { *; }
-keepclassmembers class * extends androidx.room.RoomDatabase {
    abstract *;
}
# Keep Room TypeConverter methods
-keepclassmembers class ** {
    @androidx.room.TypeConverter *;
}

# ── Hilt ─────────────────────────────────────────────────────────
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }
-keep @dagger.hilt.android.HiltAndroidApp class * { *; }
-keep @dagger.hilt.android.AndroidEntryPoint class * { *; }
-keep @dagger.hilt.android.lifecycle.HiltViewModel class * { *; }

# ── Moshi ─────────────────────────────────────────────────────────
# Keep all classes annotated with @JsonClass (Moshi codegen)
-keep @com.squareup.moshi.JsonClass class * { *; }
# Keep Moshi adapters
-keep class com.squareup.moshi.** { *; }
-keepclassmembers class * {
    @com.squareup.moshi.FromJson *;
    @com.squareup.moshi.ToJson *;
}
# Ensure Kotlin metadata is kept for Moshi reflection fallback
-keep class kotlin.Metadata { *; }
-keepclassmembers class ** {
    @com.squareup.moshi.Json <fields>;
}

# ── Kotlin ────────────────────────────────────────────────────────
-keep class kotlin.** { *; }
-keep class kotlinx.coroutines.** { *; }
# Kotlin serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt

# ── Jetpack Compose ───────────────────────────────────────────────
-keep class androidx.compose.** { *; }
# Keep Composable function names for better crash reports
-keepattributes SourceFile, LineNumberTable

# ── Navigation Compose ────────────────────────────────────────────
-keep class androidx.navigation.** { *; }

# ── WorkManager ───────────────────────────────────────────────────
-keep class * extends androidx.work.Worker { *; }
-keep class * extends androidx.work.CoroutineWorker { *; }
-keep class * extends androidx.work.ListenableWorker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}

# ── DataStore ────────────────────────────────────────────────────
-keep class androidx.datastore.** { *; }

# ── StudyPlan domain models ───────────────────────────────────────
# Keep all domain model data classes to prevent R8 from removing
# fields used only in JSON serialization
-keep class com.studyplan.app.domain.model.** { *; }
-keep class com.studyplan.app.data.db.entity.** { *; }

# ── General Android ───────────────────────────────────────────────
-keepattributes Signature
-keepattributes Exceptions
-keepattributes EnclosingMethod

# Parcelable
-keep class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# Enum classes
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# ── Crash reporting (keep source file info) ───────────────────────
-keepattributes SourceFile, LineNumberTable
-renamesourcefileattribute SourceFile
