@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.flashcards

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studyplan.app.ui.components.*
import com.studyplan.app.ui.screens.notes.htmlToAnnotatedString
import com.studyplan.app.ui.theme.*

@Composable
fun FlashcardsScreen(vm: FlashcardsViewModel = hiltViewModel()) {
    val state  by vm.state.collectAsStateWithLifecycle()
    val colors  = MaterialTheme.studyColors

    Column(
        modifier            = Modifier
            .fillMaxSize()
            .background(colors.bg)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        PageHeader(
            title    = "Flashcards",
            subtitle = "${state.totalInDeck} card${if (state.totalInDeck != 1) "s" else ""} from Key Point notes",
        )

        // ── Subject filter ────────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
        ) {
            val subOptions = listOf(DropdownOption<String?>(null, "All subjects")) +
                state.subjects.map { DropdownOption(it.id, it.name) }
            StudyDropdown(
                options  = subOptions,
                selected = state.filterSubId,
                onSelect = { vm.setFilter(it) },
                modifier = Modifier.fillMaxWidth(0.6f),
            )
            Spacer(Modifier.width(8.dp))
            // Shuffle button
            OutlineButton(
                text    = if (state.isShuffled) "🔀 Shuffled" else "🔀 Shuffle",
                onClick = { vm.shuffle() },
            )
        }

        Spacer(Modifier.height(24.dp))

        when {
            state.isLoading -> CircularProgressIndicator(color = colors.text,
                strokeWidth = 2.dp, modifier = Modifier.size(28.dp))

            state.deck.isEmpty() -> EmptyState(
                title    = "No Flashcards",
                subtitle = "Add notes with type \"Key Point\" from the Lectures page to create flashcards.",
                icon     = Icons.Outlined.Style,
                modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp),
            )

            else -> {
                val card = state.deck[state.currentIndex]

                // ── Counter ───────────────────────────────────────
                Text(
                    "${state.currentIndex + 1} / ${state.deck.size}",
                    fontFamily = MonoFontFamily,
                    fontSize   = 12.sp,
                    color      = colors.text3,
                )
                Spacer(Modifier.height(16.dp))

                // ── Flip Card ─────────────────────────────────────
                FlipCard(
                    card      = card,
                    isFlipped = state.isFlipped,
                    onClick   = { vm.flipCard() },
                    modifier  = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .height(280.dp),
                )

                Spacer(Modifier.height(12.dp))
                Text(
                    "Tap card to flip • Swipe or use arrows to navigate",
                    fontFamily = BodyFontFamily,
                    fontSize   = 12.sp,
                    color      = colors.text3,
                    textAlign  = TextAlign.Center,
                )

                Spacer(Modifier.height(24.dp))

                // ── Navigation arrows ─────────────────────────────
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment     = Alignment.CenterVertically,
                ) {
                    NavArrowButton(
                        icon    = Icons.Outlined.ChevronLeft,
                        onClick = { vm.previous() },
                        enabled = state.deck.size > 1,
                    )
                    // Dots indicator (max 7 dots, then show number)
                    if (state.deck.size <= 7) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            repeat(state.deck.size) { i ->
                                Box(
                                    modifier = Modifier
                                        .size(if (i == state.currentIndex) 8.dp else 6.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (i == state.currentIndex) colors.primary
                                            else colors.border
                                        ),
                                )
                            }
                        }
                    } else {
                        Text("${state.currentIndex + 1}/${state.deck.size}",
                            fontFamily = MonoFontFamily, fontSize = 13.sp,
                            color = colors.text2)
                    }
                    NavArrowButton(
                        icon    = Icons.Outlined.ChevronRight,
                        onClick = { vm.next() },
                        enabled = state.deck.size > 1,
                    )
                }
                Spacer(Modifier.height(32.dp))
            }
        }
    }
}

// ── Flip Card with 3D Y-axis rotation ────────────────────────────
@Composable
private fun FlipCard(
    card:     FlashCard,
    isFlipped: Boolean,
    onClick:  () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.studyColors

    // Rotation animation — 0° = front visible, 180° = back visible
    val rotation by animateFloatAsState(
        targetValue   = if (isFlipped) 180f else 0f,
        animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing),
        label         = "cardFlip",
    )

    val subColor = runCatching {
        Color(android.graphics.Color.parseColor(card.subjectColor))
    }.getOrElse { colors.text3 }

    Box(
        contentAlignment = Alignment.Center,
        modifier         = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(
                indication        = null,
                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                onClick           = onClick,
            )
            .graphicsLayer {
                rotationY          = rotation
                cameraDistance     = 12f * density
            },
    ) {
        if (rotation <= 90f) {
            // Front face
            CardFace(
                label      = "Lecture",
                content    = card.front,
                subLabel   = card.subjectName,
                subColor   = subColor,
                isFront    = true,
                isHtml     = false,
                modifier   = Modifier.fillMaxSize(),
            )
        } else {
            // Back face — counter-rotated so text reads correctly
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { rotationY = 180f },
            ) {
                CardFace(
                    label    = "Key Point",
                    content  = card.back,
                    subLabel = null,
                    subColor = subColor,
                    isFront  = false,
                    isHtml   = true,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }
}

@Composable
private fun CardFace(
    label:    String,
    content:  String,
    subLabel: String?,
    subColor: Color,
    isFront:  Boolean,
    isHtml:   Boolean,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.studyColors
    val bg     = if (isFront) colors.surface else colors.surface2

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier            = modifier
            .background(bg, RoundedCornerShape(16.dp))
            .border(1.dp, colors.border, RoundedCornerShape(16.dp))
            .padding(24.dp),
    ) {
        // Card label
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(colors.primaryX)
                .padding(horizontal = 10.dp, vertical = 3.dp),
        ) {
            Text(label.uppercase(), fontFamily = BodyFontFamily, fontWeight = FontWeight.Bold,
                fontSize = 9.sp, color = colors.text3, letterSpacing = 1.sp)
        }

        Spacer(Modifier.height(16.dp))

        // Main content
        val annotated = remember(content) {
            if (isHtml) htmlToAnnotatedString(content) else
                androidx.compose.ui.text.AnnotatedString(content)
        }
        Text(
            text       = annotated,
            fontFamily = if (isFront) HeadingFontFamily else BodyFontFamily,
            fontWeight = if (isFront) FontWeight.Bold else FontWeight.Normal,
            fontSize   = if (isFront) 18.sp else 15.sp,
            color      = colors.text,
            textAlign  = TextAlign.Center,
            lineHeight = 24.sp,
            maxLines   = 8,
            overflow   = TextOverflow.Ellipsis,
        )

        if (subLabel != null) {
            Spacer(Modifier.height(12.dp))
            Text(
                text       = subLabel,
                fontFamily = BodyFontFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize   = 11.sp,
                color      = subColor,
            )
        }
    }
}

// ── Navigation arrow button ───────────────────────────────────────
@Composable
private fun NavArrowButton(
    icon:    androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    enabled: Boolean = true,
) {
    val colors = MaterialTheme.studyColors
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(if (enabled) colors.surface else colors.surface2)
            .border(1.dp, colors.border, CircleShape)
            .then(if (enabled) Modifier.clickable(
                indication        = null,
                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                onClick           = onClick,
            ) else Modifier),
    ) {
        Icon(
            imageVector        = icon,
            contentDescription = null,
            tint               = if (enabled) colors.text else colors.text3,
            modifier           = Modifier.size(20.dp),
        )
    }
}
