package com.studyplan.app.ui.screens.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studyplan.app.domain.engine.*
import com.studyplan.app.domain.model.*
import com.studyplan.app.domain.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DashboardUiState(
    val isLoading:       Boolean         = true,
    val stats:           AppStats        = AppStats.empty(),
    val subjects:        List<Subject>   = emptyList(),
    val nextExam:        NextExamInfo?   = null,
    val weeklyGoalHours: Double          = 0.0,
    val weeklyStudiedH:  Double          = 0.0,
    // Alert banner type — matches HTML's 4 alert states
    val alertState: DashboardAlert       = DashboardAlert.NONE,
)

data class NextExamInfo(
    val subjectName: String,
    val subjectColor: String,
    val daysLeft:    Long,
    val urgencyColor: UrgencyLevel,
    val urgencyLabel: String,
    val progressPct: Int,
    val studyDaysLeft: Long,
    val requiredDailyDisplay: String,
)

enum class UrgencyLevel { CRITICAL, HIGH, NORMAL, GOOD }
enum class DashboardAlert { NONE, BEFORE_START, OVERDUE, BEHIND, BACKLOG }

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val statsEngine:    StatsEngine,
    private val subjectRepo:    SubjectRepository,
    private val settingsRepo:   SettingsRepository,
    private val backlogHandler: BacklogHandler,
) : ViewModel() {

    private val _state = MutableStateFlow(DashboardUiState())
    val state: StateFlow<DashboardUiState> = _state.asStateFlow()

    // Toast messages from backlog handler
    private val _toast = MutableSharedFlow<String>()
    val toast: SharedFlow<String> = _toast.asSharedFlow()

    init { loadDashboard() }

    fun loadDashboard() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }

            val stats    = statsEngine.getStats()
            val subjects = subjectRepo.getAll()
            val settings = settingsRepo.get()
            val weekly   = statsEngine.getWeeklyStats()
            val today    = TimeUtils.today()

            // Next upcoming exam
            val nextExam = subjects
                .filter { it.examDate.isNotEmpty() && it.examDate >= today }
                .minByOrNull { it.examDate }
                ?.let { sub ->
                    val daysLeft    = TimeUtils.diffDays(today, sub.examDate)
                    val urgency     = when {
                        daysLeft <= 14 -> UrgencyLevel.CRITICAL
                        daysLeft <= 30 -> UrgencyLevel.HIGH
                        daysLeft <= 60 -> UrgencyLevel.NORMAL
                        else           -> UrgencyLevel.GOOD
                    }
                    val urgencyLabel = when (urgency) {
                        UrgencyLevel.CRITICAL -> "Critical"
                        UrgencyLevel.HIGH     -> "High urgency"
                        UrgencyLevel.NORMAL   -> "Stay consistent"
                        UrgencyLevel.GOOD     -> "Good pace"
                    }
                    val createdAt = sub.createdAt.ifEmpty { settings?.startDate ?: today }
                    val totalWindow = maxOf(1L, TimeUtils.diffDays(createdAt, sub.examDate))
                    val elapsed     = maxOf(0L, TimeUtils.diffDays(createdAt, today))
                    val progressPct = minOf(100, ((elapsed.toDouble() / totalWindow) * 100).toInt())

                    NextExamInfo(
                        subjectName         = sub.fullName.ifEmpty { sub.name },
                        subjectColor        = sub.color,
                        daysLeft            = daysLeft,
                        urgencyColor        = urgency,
                        urgencyLabel        = urgencyLabel,
                        progressPct         = progressPct,
                        studyDaysLeft       = stats.studyDaysLeft,
                        requiredDailyDisplay = if (stats.requiredDailySecs > 0)
                            TimeUtils.toDisplay(stats.requiredDailySecs) else "",
                    )
                }

            // Alert state — mirrors HTML's 4 banner conditions
            val alert = when {
                stats.isBeforeStart                           -> DashboardAlert.BEFORE_START
                stats.isOverdue                               -> DashboardAlert.OVERDUE
                !stats.onTrack && stats.studyDaysLeft > 0     -> DashboardAlert.BEHIND
                stats.backlogSecs > 0                         -> DashboardAlert.BACKLOG
                else                                          -> DashboardAlert.NONE
            }

            val goalHours   = settings?.weeklyGoalHours ?: 0.0
            val studiedHours = TimeUtils.secondsToHours(weekly.weekStudiedSecs)

            _state.update {
                it.copy(
                    isLoading       = false,
                    stats           = stats,
                    subjects        = subjects,
                    nextExam        = nextExam,
                    weeklyGoalHours = goalHours,
                    weeklyStudiedH  = studiedHours,
                    alertState      = alert,
                )
            }
        }
    }

    fun handleBacklog(strategy: BacklogHandler.Strategy, redistributeDays: Int = 7) {
        viewModelScope.launch {
            val msg = backlogHandler.apply(strategy, redistributeDays)
            statsEngine.invalidate()
            _toast.emit(msg)
            loadDashboard()
        }
    }
}
