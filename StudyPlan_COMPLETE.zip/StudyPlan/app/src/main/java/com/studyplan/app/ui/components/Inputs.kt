@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyplan.app.ui.theme.BodyFontFamily
import com.studyplan.app.ui.theme.StudyPlanRadius
import com.studyplan.app.ui.theme.studyColors

// ═══════════════════════════════════════════════════════════════════
//  FIELD LABEL — sits above every input
// ═══════════════════════════════════════════════════════════════════
@Composable
fun FieldLabel(text: String, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.studyColors
    Text(
        text       = text,
        fontFamily = BodyFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize   = 12.sp,
        color      = colors.text2,
        modifier   = modifier.padding(bottom = 4.dp),
    )
}

@Composable
fun FieldHint(text: String, modifier: Modifier = Modifier) {
    Text(text, fontFamily = BodyFontFamily, fontSize = 11.sp,
        color = MaterialTheme.studyColors.text3, modifier = modifier.padding(top = 3.dp))
}

// ═══════════════════════════════════════════════════════════════════
//  STUDY PLAN TEXT FIELD — port of .input-field CSS class
//  Used for name, number, chapter, duration inputs.
// ═══════════════════════════════════════════════════════════════════
@Composable
fun StudyTextField(
    value:         String,
    onValueChange: (String) -> Unit,
    modifier:      Modifier = Modifier,
    placeholder:   String   = "",
    singleLine:    Boolean  = true,
    maxLines:      Int      = 1,
    keyboardType:  KeyboardType    = KeyboardType.Text,
    imeAction:     ImeAction       = ImeAction.Done,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    enabled:       Boolean  = true,
    isError:       Boolean  = false,
    minLines:      Int      = 1,
) {
    val colors   = MaterialTheme.studyColors
    var focused  by remember { mutableStateOf(false) }

    val borderColor = when {
        isError  -> colors.red
        focused  -> colors.focusBorder
        else     -> colors.border
    }

    BasicTextField(
        value            = value,
        onValueChange    = onValueChange,
        enabled          = enabled,
        singleLine       = singleLine,
        maxLines         = maxLines,
        minLines         = minLines,
        keyboardOptions  = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
        keyboardActions  = keyboardActions,
        cursorBrush      = SolidColor(colors.primary),
        textStyle        = TextStyle(
            fontFamily = BodyFontFamily,
            fontWeight = FontWeight.Normal,
            fontSize   = 13.sp,
            color      = if (enabled) colors.text else colors.text3,
        ),
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(StudyPlanRadius.md))
            .background(colors.surface)
            .border(1.dp, borderColor, RoundedCornerShape(StudyPlanRadius.md))
            .onFocusChanged { focused = it.isFocused },
        decorationBox = { innerTextField ->
            Box(modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp)) {
                if (value.isEmpty()) {
                    Text(placeholder, fontFamily = BodyFontFamily, fontSize = 13.sp,
                        color = colors.text3)
                }
                innerTextField()
            }
        },
    )
}

// ═══════════════════════════════════════════════════════════════════
//  TEXTAREA — multi-line notes input
// ═══════════════════════════════════════════════════════════════════
@Composable
fun StudyTextArea(
    value:         String,
    onValueChange: (String) -> Unit,
    modifier:      Modifier = Modifier,
    placeholder:   String   = "",
    minLines:      Int      = 4,
) {
    StudyTextField(
        value         = value,
        onValueChange = onValueChange,
        modifier      = modifier,
        placeholder   = placeholder,
        singleLine    = false,
        maxLines      = 12,
        minLines      = minLines,
    )
}

// ═══════════════════════════════════════════════════════════════════
//  TOGGLE SWITCH — port of CSS .toggle-switch
// ═══════════════════════════════════════════════════════════════════
@Composable
fun StudyToggle(
    checked:   Boolean,
    onChecked: (Boolean) -> Unit,
    modifier:  Modifier = Modifier,
) {
    val colors = MaterialTheme.studyColors
    Switch(
        checked  = checked,
        onCheckedChange = onChecked,
        modifier = modifier.height(22.dp),
        colors   = SwitchDefaults.colors(
            checkedThumbColor   = colors.onPrimary,
            checkedTrackColor   = colors.primary,
            uncheckedThumbColor = colors.text3,
            uncheckedTrackColor = colors.surface2,
            uncheckedBorderColor = colors.borderStrong,
        ),
    )
}

// ═══════════════════════════════════════════════════════════════════
//  SETTINGS ROW — label + control side by side
// ═══════════════════════════════════════════════════════════════════
@Composable
fun SettingsRow(
    label:    String,
    hint:     String?  = null,
    modifier: Modifier = Modifier,
    control:  @Composable () -> Unit,
) {
    val colors = MaterialTheme.studyColors
    Column(modifier = modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier              = Modifier.fillMaxWidth(),
        ) {
            Text(label, fontFamily = BodyFontFamily, fontWeight = FontWeight.Medium,
                fontSize = 13.sp, color = colors.text, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(12.dp))
            control()
        }
        if (hint != null) {
            Text(hint, fontFamily = BodyFontFamily, fontSize = 11.sp,
                color = colors.text3, modifier = Modifier.padding(top = 3.dp))
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
//  TAG TOGGLE BUTTONS — hw / nm / th / im
//  Matches HTML .tag-toggle CSS
// ═══════════════════════════════════════════════════════════════════
@Composable
fun TagToggleButton(
    label:     String,
    selected:  Boolean,
    onClick:   () -> Unit,
    modifier:  Modifier = Modifier,
) {
    val colors = MaterialTheme.studyColors
    val bg     = if (selected) colors.primaryX else colors.surface2
    val border = if (selected) colors.focusBorder else colors.border
    val fg     = if (selected) colors.text else colors.text3

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .clip(RoundedCornerShape(StudyPlanRadius.sm))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(StudyPlanRadius.sm))
            .clickable(
                indication        = null,
                interactionSource = remember { MutableInteractionSource() },
                onClick           = onClick,
            )
            .padding(horizontal = 10.dp, vertical = 5.dp),
    ) {
        Text(label, fontFamily = BodyFontFamily, fontWeight = FontWeight.Medium,
            fontSize = 12.sp, color = fg)
    }
}

// ═══════════════════════════════════════════════════════════════════
//  COLOR PICKER — 8-swatch row matching HTML COLORS array
// ═══════════════════════════════════════════════════════════════════
@Composable
fun ColorPicker(
    selected: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors   = MaterialTheme.studyColors
    val swatches = listOf(
        "#374151","#6366f1","#0891b2","#059669",
        "#7c3aed","#db2777","#d97706","#16a34a",
    )
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier              = modifier.fillMaxWidth(),
    ) {
        swatches.forEach { hex ->
            val isSelected = hex.equals(selected, ignoreCase = true)
            val color = runCatching {
                Color(android.graphics.Color.parseColor(hex))
            }.getOrElse { colors.text3 }
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(color)
                    .then(
                        if (isSelected) Modifier.border(2.dp, colors.text, RoundedCornerShape(6.dp))
                        else Modifier.border(2.dp, Color.Transparent, RoundedCornerShape(6.dp))
                    )
                    .clickable(
                        indication        = null,
                        interactionSource = remember { MutableInteractionSource() },
                        onClick           = { onSelect(hex) },
                    ),
            )
        }
    }
}
