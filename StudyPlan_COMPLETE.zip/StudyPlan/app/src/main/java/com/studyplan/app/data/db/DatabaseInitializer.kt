package com.studyplan.app.data.db

import com.studyplan.app.domain.model.AppMeta
import com.studyplan.app.domain.model.AppSettings
import com.studyplan.app.domain.repository.MetaRepository
import com.studyplan.app.domain.repository.SettingsRepository
import java.time.LocalDate
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Mirrors the HTML Store.init() + first-launch migration logic.
 *
 * Called on app start from the app's ViewModel layer:
 *  1. If meta row does not exist → seed defaults (fresh install)
 *  2. If meta row exists → apply any field-level migrations
 *     (same as the HTML's "migrate old data" block in initApp())
 */
@Singleton
class DatabaseInitializer @Inject constructor(
    private val settingsRepo: SettingsRepository,
    private val metaRepo:     MetaRepository,
) {
    /**
     * Returns true if this was a fresh initialization (onboarding needed).
     * Returns false if data was already present.
     */
    suspend fun initIfNeeded(): Boolean {
        val existingMeta = metaRepo.get()
        if (existingMeta != null) {
            // Data exists — apply field migrations if version < current
            applyMigrations(existingMeta)
            return false
        }

        // ── Fresh install: seed defaults ─────────────────────────
        val today = LocalDate.now().toString()

        settingsRepo.upsert(
            AppSettings(
                startDate            = today,
                dailyStudyHours      = 6.0,
                bufferDayOfWeek      = 0,       // Sunday rest day
                weeklyGoalHours      = 0.0,
                interleaveSubjects   = false,
                intensityRampEnabled = false,
                intensityStartHours  = 4.0,
                intensityEndHours    = 8.0,
                examLockDays         = 7,
                alarmEnabled         = false,
                alarmHour            = 8,
                alarmMinute          = 0,
                notifEnabled         = false,
                notifHour            = 9,
                vacationDates        = emptyList(),
            )
        )

        metaRepo.upsert(
            AppMeta(
                initialized        = true,
                version            = CURRENT_VERSION,
                lastBuiltDate      = today,
                onboarded          = false,
                achievedMilestones = emptyList(),
            )
        )

        return true // needs onboarding
    }

    /**
     * Migrate old data fields — mirrors the HTML's migration block
     * that adds missing fields to loaded localStorage data.
     */
    private suspend fun applyMigrations(meta: AppMeta) {
        if (meta.version < CURRENT_VERSION) {
            metaRepo.upsert(meta.copy(version = CURRENT_VERSION))
        }
        // Settings migrations handled by Room schema versioning in later phases
    }

    companion object {
        const val CURRENT_VERSION = 5   // matches HTML meta.version = 5
    }
}
