package com.studyplan.app.domain.engine

import org.junit.Assert.*
import org.junit.Test

class ReportCardTest {

    @Test fun `formatAsText contains required sections`() {
        // Test the text formatting logic directly
        val weekStudied    = 18000L  // 5h
        val weekDone       = 12
        val streak         = 5
        val completionRate = 85
        val overallPct     = 42
        val from           = "2024-06-01"
        val to             = "2024-06-07"

        val text = buildString {
            appendLine("📊 Weekly Study Report (${TimeUtils.formatDisplay(from)} – ${TimeUtils.formatDisplay(to)})")
            appendLine("⏱ Total Studied: ${TimeUtils.toDisplay(weekStudied)}")
            appendLine("📚 Lectures Done: $weekDone")
            appendLine("🔥 Streak: $streak days")
            appendLine("✅ Completion: $completionRate%")
            append("📈 Overall: $overallPct%")
        }

        assertTrue(text.contains("Weekly Study Report"))
        assertTrue(text.contains("5 h"))
        assertTrue(text.contains("12"))
        assertTrue(text.contains("5 days"))
        assertTrue(text.contains("85%"))
        assertTrue(text.contains("42%"))
    }

    @Test fun `from date is 6 days before to date`() {
        val today = "2024-06-07"
        val from  = TimeUtils.addDays(today, -6)
        assertEquals("2024-06-01", from)
        assertEquals(6L, TimeUtils.diffDays(from, today))
    }
}
