package com.studyplan.app.data.json

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

/**
 * JSON serialization model — exactly mirrors the HTML studyPlanner_v3
 * localStorage structure for cross-compatibility between web and app.
 *
 * Field names use @Json to match the HTML camelCase keys exactly.
 */

@JsonClass(generateAdapter = true)
data class StudyPlanBackup(
    @Json(name = "settings")   val settings:    BackupSettings,
    @Json(name = "subjects")   val subjects:    List<BackupSubject>,
    @Json(name = "lectures")   val lectures:    List<BackupLecture>,
    @Json(name = "schedule")   val schedule:    Map<String, List<BackupScheduleEntry>>,  // date → entries
    @Json(name = "notes")      val notes:       Map<String, List<BackupNote>>,           // lectureId → notes
    @Json(name = "sessionLogs") val sessionLogs: List<BackupSessionLog>,
    @Json(name = "meta")       val meta:        BackupMeta,
)

@JsonClass(generateAdapter = true)
data class BackupSettings(
    @Json(name = "startDate")            val startDate:            String,
    @Json(name = "dailyStudyHours")      val dailyStudyHours:      Double,
    @Json(name = "bufferDayOfWeek")      val bufferDayOfWeek:      Int,
    @Json(name = "weeklyGoalHours")      val weeklyGoalHours:      Double   = 0.0,
    @Json(name = "interleaveSubjects")   val interleaveSubjects:   Boolean  = false,
    @Json(name = "intensityRampEnabled") val intensityRampEnabled: Boolean  = false,
    @Json(name = "intensityStartHours")  val intensityStartHours:  Double   = 4.0,
    @Json(name = "intensityEndHours")    val intensityEndHours:    Double   = 8.0,
    @Json(name = "examLockDays")         val examLockDays:         Int      = 7,
    @Json(name = "alarmEnabled")         val alarmEnabled:         Boolean  = false,
    @Json(name = "alarmHour")            val alarmHour:            Int      = 8,
    @Json(name = "alarmMinute")          val alarmMinute:          Int      = 0,
    @Json(name = "notifEnabled")         val notifEnabled:         Boolean  = false,
    @Json(name = "notifHour")            val notifHour:            Int      = 9,
    @Json(name = "vacationDates")        val vacationDates:        List<String> = emptyList(),
)

@JsonClass(generateAdapter = true)
data class BackupSubject(
    @Json(name = "id")              val id:              String,
    @Json(name = "name")            val name:            String,
    @Json(name = "fullName")        val fullName:        String  = "",
    @Json(name = "deadline")        val deadline:        String  = "",
    @Json(name = "examDate")        val examDate:        String  = "",
    @Json(name = "dailyHours")      val dailyHours:      Double  = 6.0,
    @Json(name = "priority")        val priority:        Int     = 1,
    @Json(name = "color")           val color:           String  = "#374151",
    @Json(name = "createdAt")       val createdAt:       String  = "",
    @Json(name = "revisionEnabled") val revisionEnabled: Boolean = false,
    @Json(name = "revisionRound")   val revisionRound:   Int     = 0,
)

@JsonClass(generateAdapter = true)
data class BackupLecture(
    @Json(name = "id")           val id:           String,
    @Json(name = "subjectId")    val subjectId:    String,
    @Json(name = "sequence")     val sequence:     Int,
    @Json(name = "lectureNum")   val lectureNum:   String  = "",
    @Json(name = "name")         val name:         String,
    @Json(name = "duration")     val duration:     Long,
    @Json(name = "remaining")    val remaining:    Long,
    @Json(name = "status")       val status:       String  = "pending",
    @Json(name = "completedOn")  val completedOn:  String? = null,
    @Json(name = "todayStudied") val todayStudied: Long    = 0L,
    @Json(name = "todayDate")    val todayDate:    String? = null,
    @Json(name = "chapter")      val chapter:      String  = "",
    @Json(name = "tags")         val tags:         List<String> = emptyList(),
    @Json(name = "difficulty")   val difficulty:   String? = null,
)

@JsonClass(generateAdapter = true)
data class BackupScheduleEntry(
    @Json(name = "lectureId")        val lectureId:        String,
    @Json(name = "subjectId")        val subjectId:        String,
    @Json(name = "plannedSeconds")   val plannedSeconds:   Long,
    @Json(name = "completedSeconds") val completedSeconds: Long   = 0L,
    @Json(name = "status")           val status:           String = "scheduled",
)

@JsonClass(generateAdapter = true)
data class BackupNote(
    @Json(name = "id")        val id:        String,
    @Json(name = "text")      val text:      String,
    @Json(name = "type")      val type:      String  = "note",
    @Json(name = "createdAt") val createdAt: String  = "",
    @Json(name = "resolved")  val resolved:  Boolean = false,
)

@JsonClass(generateAdapter = true)
data class BackupSessionLog(
    @Json(name = "date")      val date:      String,
    @Json(name = "hour")      val hour:      Int,
    @Json(name = "seconds")   val seconds:   Long,
    @Json(name = "lectureId") val lectureId: String,
    @Json(name = "subjectId") val subjectId: String,
)

@JsonClass(generateAdapter = true)
data class BackupMeta(
    @Json(name = "initialized")        val initialized:        Boolean = true,
    @Json(name = "version")            val version:            Int     = 5,
    @Json(name = "lastBuiltDate")      val lastBuiltDate:      String  = "",
    @Json(name = "onboarded")          val onboarded:          Boolean = false,
    @Json(name = "achievedMilestones") val achievedMilestones: List<String> = emptyList(),
)
