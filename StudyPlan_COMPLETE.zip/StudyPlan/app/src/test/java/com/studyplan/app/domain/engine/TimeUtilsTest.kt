package com.studyplan.app.domain.engine

import org.junit.Assert.*
import org.junit.Test

class TimeUtilsTest {

    @Test fun `toSeconds parses hh_mm_ss correctly`() {
        assertEquals(5400L, TimeUtils.toSeconds("01:30:00"))
        assertEquals(3661L, TimeUtils.toSeconds("01:01:01"))
        assertEquals(0L,    TimeUtils.toSeconds("00:00:00"))
    }

    @Test fun `toSeconds parses hh_mm correctly`() {
        assertEquals(3600L, TimeUtils.toSeconds("01:00"))
        assertEquals(5400L, TimeUtils.toSeconds("01:30"))
    }

    @Test fun `toSeconds returns 0 for invalid input`() {
        assertEquals(0L, TimeUtils.toSeconds(""))
        assertEquals(0L, TimeUtils.toSeconds("abc"))
        assertEquals(0L, TimeUtils.toSeconds("1"))
    }

    @Test fun `toHMS formats correctly`() {
        assertEquals("01:30:00", TimeUtils.toHMS(5400L))
        assertEquals("00:00:00", TimeUtils.toHMS(0L))
        assertEquals("10:00:00", TimeUtils.toHMS(36000L))
        assertEquals("01:01:01", TimeUtils.toHMS(3661L))
    }

    @Test fun `toHMS clamps negative to zero`() {
        assertEquals("00:00:00", TimeUtils.toHMS(-100L))
    }

    @Test fun `toDisplay formats hours and minutes`() {
        assertEquals("1 h 30 m", TimeUtils.toDisplay(5400L))
        assertEquals("2 h", TimeUtils.toDisplay(7200L))
        assertEquals("45 m", TimeUtils.toDisplay(2700L))
        assertEquals("0 m", TimeUtils.toDisplay(0L))
    }

    @Test fun `addDays adds correctly`() {
        assertEquals("2024-01-02", TimeUtils.addDays("2024-01-01", 1))
        assertEquals("2024-02-01", TimeUtils.addDays("2024-01-31", 1))
        assertEquals("2024-03-01", TimeUtils.addDays("2024-02-29", 1)) // 2024 is leap year
        assertEquals("2023-12-31", TimeUtils.addDays("2024-01-01", -1))
    }

    @Test fun `diffDays calculates correctly`() {
        assertEquals(1L,   TimeUtils.diffDays("2024-01-01", "2024-01-02"))
        assertEquals(-1L,  TimeUtils.diffDays("2024-01-02", "2024-01-01"))
        assertEquals(0L,   TimeUtils.diffDays("2024-06-15", "2024-06-15"))
        assertEquals(366L, TimeUtils.diffDays("2024-01-01", "2025-01-01")) // 2024 is leap year
        assertEquals(365L, TimeUtils.diffDays("2023-01-01", "2024-01-01"))
    }

    @Test fun `dayOfWeek matches JS getDay() convention`() {
        // 2024-01-07 is a Sunday
        assertEquals(0, TimeUtils.dayOfWeek("2024-01-07"))
        // 2024-01-01 is a Monday
        assertEquals(1, TimeUtils.dayOfWeek("2024-01-01"))
        // 2024-01-06 is a Saturday
        assertEquals(6, TimeUtils.dayOfWeek("2024-01-06"))
    }

    @Test fun `dayName returns correct short name`() {
        assertEquals("Sun", TimeUtils.dayName("2024-01-07"))
        assertEquals("Mon", TimeUtils.dayName("2024-01-01"))
        assertEquals("Sat", TimeUtils.dayName("2024-01-06"))
        assertEquals("Wed", TimeUtils.dayName("2024-01-03"))
    }

    @Test fun `formatDisplay formats date correctly`() {
        assertEquals("01 Jan 2024", TimeUtils.formatDisplay("2024-01-01"))
        assertEquals("15 Jun 2024", TimeUtils.formatDisplay("2024-06-15"))
        assertEquals("31 Dec 2024", TimeUtils.formatDisplay("2024-12-31"))
    }

    @Test fun `formatDisplay returns dash for empty`() {
        assertEquals("—", TimeUtils.formatDisplay(""))
    }

    @Test fun `hoursToSeconds converts correctly`() {
        assertEquals(21600L, TimeUtils.hoursToSeconds(6.0))
        assertEquals(5400L,  TimeUtils.hoursToSeconds(1.5))
        assertEquals(0L,     TimeUtils.hoursToSeconds(0.0))
    }

    @Test fun `toSeconds_toHMS roundtrip`() {
        val original = "02:45:30"
        assertEquals(original, TimeUtils.toHMS(TimeUtils.toSeconds(original)))
    }

    @Test fun `leap year handling - Feb 29`() {
        // 2024 is a leap year
        assertEquals("2024-02-29", TimeUtils.addDays("2024-02-28", 1))
        assertEquals("2024-03-01", TimeUtils.addDays("2024-02-29", 1))
    }

    @Test fun `year boundary crossing`() {
        assertEquals("2025-01-01", TimeUtils.addDays("2024-12-31", 1))
        assertEquals("2023-12-31", TimeUtils.addDays("2024-01-01", -1))
    }
}
