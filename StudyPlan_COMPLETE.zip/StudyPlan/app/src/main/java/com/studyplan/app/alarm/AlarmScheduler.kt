package com.studyplan.app.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Manages the daily study alarm using AlarmManager.setExactAndAllowWhileIdle().
 * Mirrors HTML StudyAlarm — fires at the user-set time each day,
 * and auto-reschedules for the next day after firing.
 */
@Singleton
class AlarmScheduler @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    companion object {
        const val REQUEST_CODE = 2001
        const val ACTION_ALARM = "com.studyplan.app.STUDY_ALARM"
    }

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    /** Schedule or reschedule the alarm for today (or tomorrow if past the time). */
    fun schedule(hour: Int, minute: Int) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            // If the time has already passed today, schedule for tomorrow
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }
        val pending = buildPendingIntent()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            !alarmManager.canScheduleExactAlarms()) {
            // Fallback to inexact if exact permission denied on API 31+
            alarmManager.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
        } else {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
        }
    }

    /** Cancel any scheduled alarm. */
    fun cancel() {
        alarmManager.cancel(buildPendingIntent())
    }

    /** Reschedule for the next day (called from AlarmReceiver after firing). */
    fun rescheduleNextDay(hour: Int, minute: Int) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            add(Calendar.DAY_OF_YEAR, 1)
        }
        val pending = buildPendingIntent()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            !alarmManager.canScheduleExactAlarms()) {
            alarmManager.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
        } else {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
        }
    }

    /** Human-readable "fires in Xh Ym" string — mirrors HTML StudyAlarm.timeUntil() */
    fun timeUntilDisplay(hour: Int, minute: Int): String {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val diffMs   = cal.timeInMillis - System.currentTimeMillis()
        val diffMins = (diffMs / 60_000).toInt()
        val h        = diffMins / 60
        val m        = diffMins % 60
        return when {
            h == 0   -> "Fires in ${m}m"
            m == 0   -> "Fires in ${h}h"
            else     -> "Fires in ${h}h ${m}m"
        }
    }

    private fun buildPendingIntent(): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_ALARM
        }
        return PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }
}
