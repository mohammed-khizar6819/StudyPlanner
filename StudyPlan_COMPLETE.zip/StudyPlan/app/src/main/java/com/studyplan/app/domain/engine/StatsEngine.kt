package com.studyplan.app.domain.engine

import com.studyplan.app.domain.model.*
import com.studyplan.app.domain.repository.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Port of HTML Scheduler.getStats() + Scheduler.getWeeklyStats().
 * Includes a cache keyed on (today + total remaining + today entry statuses)
 * so repeated calls within a frame are instant.
 */
@Singleton
class StatsEngine @Inject constructor(
    private val subjectRepo:  SubjectRepository,
    private val lectureRepo:  LectureRepository,
    private val scheduleRepo: ScheduleRepository,
    private val settingsRepo: SettingsRepository,
    private val sessionRepo:  SessionLogRepository,
) {
    // ── Cache (invalidated by buildSchedule in SchedulerEngine) ───
    private var statsCache:    AppStats? = null
    private var statsCacheKey: String   = ""

    fun invalidate() { statsCache = null; statsCacheKey = "" }

    // ═══════════════════════════════════════════════════════════════
    //  getStats — mirrors HTML Scheduler.getStats()
    // ═══════════════════════════════════════════════════════════════
    suspend fun getStats(): AppStats = withContext(Dispatchers.Default) {
        val today     = TimeUtils.today()
        val settings  = settingsRepo.get() ?: return@withContext AppStats.empty()
        val subjects  = subjectRepo.getAll()
        val lectures  = lectureRepo.getAll()
        val todayEnts = scheduleRepo.getForDate(today)

        // Cache key: today + remaining sum + today statuses
        val cacheKey = "$today|${lectures.sumOf { it.remaining }}|${todayEnts.map { it.status.value }.joinToString()}"
        statsCache?.let { if (statsCacheKey == cacheKey) return@withContext it }

        val totalSecs     = lectures.sumOf { it.duration }
        val completedSecs = lectures.filter { it.status == LectureStatus.COMPLETE }.sumOf { it.duration }
        val remainingSecs = lectures.sumOf { it.remaining }
        val pct           = if (totalSecs > 0) ((completedSecs.toDouble() / totalSecs) * 100).roundToInt() else 0

        // Backlog: past scheduled entries not done
        val pastEntries   = scheduleRepo.getBeforeDate(today)
        val backlogSecs   = pastEntries
            .filter { it.status == ScheduleEntryStatus.SCHEDULED }
            .sumOf { it.plannedSeconds }

        // Study days left (non-buffer, non-vacation, future)
        val studyDaysLeft = countStudyDaysLeft(today, settings, subjects)

        // Calendar days to nearest deadline
        val nearestDeadline = subjects
            .filter { it.deadline.isNotEmpty() && it.deadline >= today }
            .minByOrNull { it.deadline }?.deadline
        val calDaysLeft = nearestDeadline?.let { TimeUtils.diffDays(today, it) } ?: 0L

        val isOverdue  = calDaysLeft < 0 && remainingSecs > 0
        val isBeforeStart = settings.startDate > today

        val requiredDailySecs = if (studyDaysLeft > 0 && remainingSecs > 0)
            remainingSecs / studyDaysLeft else 0L
        val dailyCapSecs = TimeUtils.hoursToSeconds(settings.dailyStudyHours)
        val onTrack = requiredDailySecs <= dailyCapSecs || remainingSecs == 0L

        // Per-subject stats
        val bySubject = lectures.groupBy { it.subjectId }
        val subjectStats = subjects.map { sub ->
            val subLecs      = bySubject[sub.id] ?: emptyList()
            val subTotal     = subLecs.size
            val subDone      = subLecs.count { it.status == LectureStatus.COMPLETE }
            val subRemaining = subLecs.sumOf { it.remaining }
            val subPct       = if (subTotal > 0) ((subDone.toDouble() / subTotal) * 100).roundToInt() else 0
            SubjectStats(sub.id, sub.name, sub.color, subTotal, subDone, subRemaining, subPct)
        }

        // Today's plan counts
        val todayDone  = todayEnts.count { it.status == ScheduleEntryStatus.DONE || it.status == ScheduleEntryStatus.PARTIAL_DONE }
        val todayStudiedSecs = todayEnts.sumOf { it.completedSeconds }

        val result = AppStats(
            pct              = pct,
            totalSecs        = totalSecs,
            completedSecs    = completedSecs,
            remainingSecs    = remainingSecs,
            backlogSecs      = backlogSecs,
            studyDaysLeft    = studyDaysLeft,
            calDaysLeft      = calDaysLeft,
            requiredDailySecs = requiredDailySecs,
            onTrack          = onTrack,
            isOverdue        = isOverdue,
            isBeforeStart    = isBeforeStart,
            subjectStats     = subjectStats,
            todayDone        = todayDone,
            todayTotal       = todayEnts.size,
            todayStudiedSecs = todayStudiedSecs,
        )
        statsCache    = result
        statsCacheKey = cacheKey
        result
    }

    // ═══════════════════════════════════════════════════════════════
    //  getWeeklyStats — mirrors HTML Scheduler.getWeeklyStats()
    // ═══════════════════════════════════════════════════════════════
    suspend fun getWeeklyStats(): WeeklyStats = withContext(Dispatchers.Default) {
        val today    = TimeUtils.today()
        val settings = settingsRepo.get() ?: return@withContext WeeklyStats.empty()
        val subjects = subjectRepo.getAll()

        // Fetch all entries for last 7 days in a single query
        val weekStart   = TimeUtils.addDays(today, -6)
        val allWeekEntries = scheduleRepo.getInRange(weekStart, today)
            .groupBy { it.date }

        // Last 7 days (index 0 = 6 days ago, index 6 = today)
        val days = (6 downTo 0).map { i ->
            val date      = TimeUtils.addDays(today, -i.toLong())
            val isFuture  = date > today
            val isBuffer  = settings.bufferDayOfWeek != -1 &&
                            TimeUtils.dayOfWeek(date) == settings.bufferDayOfWeek
            val entries   = allWeekEntries[date] ?: emptyList()

            val plannedSecs  = entries.sumOf { it.plannedSeconds }
            val studiedSecs  = entries.sumOf { it.completedSeconds }
            val doneCount    = entries.count { it.status == ScheduleEntryStatus.DONE }
            val partialCount = entries.count { it.status == ScheduleEntryStatus.PARTIAL_DONE }
            val missedCount  = if (!isFuture && date != today)
                entries.count { it.status == ScheduleEntryStatus.SCHEDULED } else 0
            val pct = if (plannedSecs > 0)
                min(100, ((studiedSecs.toDouble() / plannedSecs) * 100).roundToInt()) else 0

            DayStats(
                date         = date,
                dayName      = TimeUtils.dayName(date),
                formatted    = TimeUtils.formatDisplay(date),
                plannedSecs  = plannedSecs,
                studiedSecs  = studiedSecs,
                doneCount    = doneCount,
                partialCount = partialCount,
                missedCount  = missedCount,
                totalCount   = entries.size,
                isBuffer     = isBuffer,
                isFuture     = isFuture,
                pct          = pct,
            )
        }

        // Streak: consecutive non-buffer days with activity, going backwards
        var streak = 0
        val studiedToday = scheduleRepo.getForDate(today)
            .any { it.status == ScheduleEntryStatus.DONE || it.status == ScheduleEntryStatus.PARTIAL_DONE }
        val startOffset = if (studiedToday) 0 else 1
        // Fetch 1-year range for streak (single DB call)
        val streakStart = TimeUtils.addDays(today, -365)
        val streakEntries = scheduleRepo.getInRange(streakStart, today)
            .groupBy { it.date }
        for (i in startOffset..365) {
            val d = TimeUtils.addDays(today, -i.toLong())
            if (settings.bufferDayOfWeek != -1 && TimeUtils.dayOfWeek(d) == settings.bufferDayOfWeek) continue
            val es = streakEntries[d] ?: emptyList()
            if (es.any { it.status == ScheduleEntryStatus.DONE || it.status == ScheduleEntryStatus.PARTIAL_DONE }) streak++
            else break
        }

        val weekStudiedSecs  = days.sumOf { it.studiedSecs }
        val weekPlannedSecs  = days.sumOf { it.plannedSecs }
        val weekDone         = days.sumOf { it.doneCount }
        val weekMissed       = days.sumOf { it.missedCount }
        val completionRate   = if (weekPlannedSecs > 0)
            ((weekStudiedSecs.toDouble() / weekPlannedSecs) * 100).roundToInt() else 0

        // Per-subject weekly breakdown
        val subjectWeekly = subjects.map { sub ->
            var weekStudied = 0L; var weekLecsDone = 0
            days.forEach { day ->
                val entries = (allWeekEntries[day.date] ?: emptyList())
                    .filter { it.subjectId == sub.id }
                weekStudied  += entries.sumOf { it.completedSeconds }
                weekLecsDone += entries.count { it.status == ScheduleEntryStatus.DONE }
            }
            SubjectWeekly(sub.id, sub.name, sub.color, weekStudied, weekLecsDone)
        }

        val bestDay = days.filter { !it.isBuffer && it.studiedSecs > 0 }
            .maxByOrNull { it.studiedSecs }

        // Session logs for TOD heatmap
        val allLogs = sessionRepo.getAll()

        WeeklyStats(
            days            = days,
            streak          = streak,
            weekStudiedSecs = weekStudiedSecs,
            weekPlannedSecs = weekPlannedSecs,
            weekDone        = weekDone,
            weekMissed      = weekMissed,
            completionRate  = completionRate,
            subjectWeekly   = subjectWeekly,
            bestDay         = bestDay,
            sessionLogs     = allLogs,
        )
    }

    // ── Study days counter ────────────────────────────────────────
    private suspend fun countStudyDaysLeft(
        today:    String,
        settings: AppSettings,
        subjects: List<Subject>,
    ): Long {
        var count = 0L
        val nearestDeadline = subjects
            .filter { it.deadline.isNotEmpty() && it.deadline >= today }
            .minByOrNull { it.deadline }?.deadline ?: TimeUtils.addDays(today, 365)

        var d = TimeUtils.addDays(today, 1)
        while (d <= nearestDeadline) {
            if (settings.bufferDayOfWeek == -1 || TimeUtils.dayOfWeek(d) != settings.bufferDayOfWeek) {
                if (!settings.vacationDates.contains(d)) count++
            }
            d = TimeUtils.addDays(d, 1)
        }
        return count
    }
}

// ── Result data classes ───────────────────────────────────────────

data class AppStats(
    val pct:               Int,
    val totalSecs:         Long,
    val completedSecs:     Long,
    val remainingSecs:     Long,
    val backlogSecs:       Long,
    val studyDaysLeft:     Long,
    val calDaysLeft:       Long,
    val requiredDailySecs: Long,
    val onTrack:           Boolean,
    val isOverdue:         Boolean,
    val isBeforeStart:     Boolean,
    val subjectStats:      List<SubjectStats>,
    val todayDone:         Int,
    val todayTotal:        Int,
    val todayStudiedSecs:  Long,
) {
    companion object {
        fun empty() = AppStats(0,0,0,0,0,0,0,0,true,false,false, emptyList(),0,0,0)
    }
}

data class SubjectStats(
    val id:           String,
    val name:         String,
    val color:        String,
    val totalCount:   Int,
    val completedCount: Int,
    val remainingSecs: Long,
    val pct:          Int,
)

data class WeeklyStats(
    val days:            List<DayStats>,
    val streak:          Int,
    val weekStudiedSecs: Long,
    val weekPlannedSecs: Long,
    val weekDone:        Int,
    val weekMissed:      Int,
    val completionRate:  Int,
    val subjectWeekly:   List<SubjectWeekly>,
    val bestDay:         DayStats?,
    val sessionLogs:     List<com.studyplan.app.domain.model.SessionLog>,
) {
    companion object {
        fun empty() = WeeklyStats(emptyList(),0,0,0,0,0,0, emptyList(),null, emptyList())
    }
}

data class DayStats(
    val date:        String,
    val dayName:     String,
    val formatted:   String,
    val plannedSecs: Long,
    val studiedSecs: Long,
    val doneCount:   Int,
    val partialCount: Int,
    val missedCount: Int,
    val totalCount:  Int,
    val isBuffer:    Boolean,
    val isFuture:    Boolean,
    val pct:         Int,
)

data class SubjectWeekly(
    val id:          String,
    val name:        String,
    val color:       String,
    val weekStudied: Long,
    val weekLecsDone: Int,
)
