package com.studyplan.app.data.db.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.studyplan.app.domain.model.Lecture
import com.studyplan.app.domain.model.LectureDifficulty
import com.studyplan.app.domain.model.LectureStatus
import com.studyplan.app.domain.model.LectureTag

@Entity(
    tableName = "lectures",
    foreignKeys = [ForeignKey(
        entity        = SubjectEntity::class,
        parentColumns = ["id"],
        childColumns  = ["subjectId"],
        onDelete      = ForeignKey.CASCADE,
    )],
    indices = [Index("subjectId")],
)
data class LectureEntity(
    @PrimaryKey val id:       String,
    val subjectId:    String,
    val sequence:     Int,
    val lectureNum:   String,
    val name:         String,
    val duration:     Long,
    val remaining:    Long,
    val status:       LectureStatus,
    val completedOn:  String?,
    val todayStudied: Long,
    val todayDate:    String?,
    val chapter:      String,
    val tags:         List<LectureTag>,       // stored via Converters
    val difficulty:   LectureDifficulty,
) {
    fun toDomain() = Lecture(id, subjectId, sequence, lectureNum, name,
        duration, remaining, status, completedOn, todayStudied, todayDate,
        chapter, tags, difficulty)
    companion object {
        fun fromDomain(l: Lecture) = LectureEntity(l.id, l.subjectId,
            l.sequence, l.lectureNum, l.name, l.duration, l.remaining,
            l.status, l.completedOn, l.todayStudied, l.todayDate,
            l.chapter, l.tags, l.difficulty)
    }
}
