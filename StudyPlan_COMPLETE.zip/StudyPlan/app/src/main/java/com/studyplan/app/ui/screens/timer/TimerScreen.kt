@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.timer

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studyplan.app.domain.engine.TimeUtils
import com.studyplan.app.domain.model.Subject
import com.studyplan.app.ui.components.*
import com.studyplan.app.ui.components.dialog.StudyPlanDialog
import com.studyplan.app.ui.theme.*

@Composable
fun TimerScreen(vm: TimerViewModel = hiltViewModel()) {
    val state  by vm.state.collectAsStateWithLifecycle()
    val colors  = MaterialTheme.studyColors
    val toast   = LocalToastHost.current

    LaunchedEffect(Unit) {
        vm.toast.collect { toast.show(it) }
    }

    // Pomodoro log prompt dialog
    var logPromptSecs by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        vm.promptLog.collect { secs -> logPromptSecs = secs }
    }

    Column(
        modifier            = Modifier
            .fillMaxSize()
            .background(colors.bg)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        PageHeader(title = "Timer", subtitle = "Pomodoro & Stopwatch")

        // ── Mode toggle ───────────────────────────────────────────
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(colors.surface2)
                .padding(3.dp),
        ) {
            TimerMode.entries.forEach { mode ->
                val selected = state.mode == mode
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (selected) colors.primary else Color.Transparent)
                        .clickable(
                            indication = null,
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            onClick = { vm.setMode(mode) },
                        )
                        .padding(horizontal = 20.dp, vertical = 7.dp),
                ) {
                    Text(
                        text       = if (mode == TimerMode.POMODORO) "Pomodoro" else "Stopwatch",
                        fontFamily = BodyFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize   = 13.sp,
                        color      = if (selected) colors.onPrimary else colors.text2,
                    )
                }
            }
        }

        Spacer(Modifier.height(32.dp))

        // ── Lecture selector ──────────────────────────────────────
        val subMap = state.subjects.associateBy { it.id }
        val lecOptions = state.lectures.map { lec ->
            DropdownOption(lec.id, "[${subMap[lec.subjectId]?.name ?: "?"}] ${lec.name}")
        }
        if (lecOptions.isNotEmpty()) {
            StudyDropdown(
                options  = lecOptions,
                selected = state.selectedLecId ?: lecOptions.first().value,
                onSelect = { vm.selectLecture(it) },
                modifier = Modifier.fillMaxWidth(0.85f),
            )
            Spacer(Modifier.height(24.dp))
        } else {
            Text("No pending lectures — add lectures to track time.",
                fontFamily = BodyFontFamily, fontSize = 12.sp, color = colors.text3,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(0.75f))
            Spacer(Modifier.height(24.dp))
        }

        // ── Timer Display ─────────────────────────────────────────
        when (state.mode) {
            TimerMode.POMODORO  -> PomodoroTimer(state = state, vm = vm)
            TimerMode.STOPWATCH -> StopwatchTimer(state = state, vm = vm)
        }

        Spacer(Modifier.height(24.dp))

        // ── Total focus this session ──────────────────────────────
        if (state.totalFocus > 0 || state.elapsed > 0) {
            val display = if (state.mode == TimerMode.STOPWATCH)
                TimeUtils.toDisplay(state.elapsed)
            else
                TimeUtils.toDisplay(state.totalFocus)
            Text(
                text       = "Session total: $display",
                fontFamily = BodyFontFamily,
                fontSize   = 12.sp,
                color      = colors.text3,
            )
        }

        Spacer(Modifier.height(40.dp))
    }

    // ── Pomodoro end-of-session log prompt ────────────────────────
    if (logPromptSecs > 0) {
        StudyPlanDialog(
            visible   = true,
            title     = "Session Complete! 🎉",
            onDismiss = { logPromptSecs = 0 },
            footer    = {
                OutlineButton("Skip", onClick = { logPromptSecs = 0 })
                Spacer(Modifier.width(8.dp))
                PrimaryButton("Log ${TimeUtils.toDisplay(logPromptSecs)}") {
                    vm.logPomodoroSession(logPromptSecs)
                    logPromptSecs = 0
                }
            },
        ) {
            Text(
                "Log ${TimeUtils.toDisplay(logPromptSecs)} to your selected lecture?",
                fontFamily = BodyFontFamily, fontSize = 13.sp,
                color = MaterialTheme.studyColors.text2, lineHeight = 20.sp,
            )
        }
    }
}

// ── Pomodoro Timer ────────────────────────────────────────────────
@Composable
private fun PomodoroTimer(state: TimerUiState, vm: TimerViewModel) {
    val colors = MaterialTheme.studyColors

    // Phase label + color
    val (phaseLabel, phaseColor) = when (state.phase) {
        TimerPhase.FOCUS      -> "Focus" to colors.primary
        TimerPhase.BREAK      -> "Short Break" to colors.green
        TimerPhase.LONG_BREAK -> "Long Break" to colors.blue
        else                  -> "Ready" to colors.text3
    }

    // Total seconds for the current phase (for progress arc)
    val totalSecs = when (state.phase) {
        TimerPhase.FOCUS      -> state.workMinutes * 60L
        TimerPhase.BREAK      -> state.shortBreakMins * 60L
        TimerPhase.LONG_BREAK -> state.longBreakMins * 60L
        else                  -> state.workMinutes * 60L
    }
    val progress = if (totalSecs > 0) 1f - (state.remaining.toFloat() / totalSecs) else 0f

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        // Phase label
        Text(phaseLabel, fontFamily = BodyFontFamily, fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp, color = phaseColor)
        Spacer(Modifier.height(16.dp))

        // Arc + countdown
        TimerArc(
            progress  = progress,
            arcColor  = phaseColor,
            label     = TimeUtils.toHMS(state.remaining).removePrefix("00:"),
            sublabel  = "${state.sessions} pomodoro${if (state.sessions != 1) "s" else ""} today",
        )

        Spacer(Modifier.height(24.dp))

        // Session dots (completed pomodoros)
        if (state.sessions > 0) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(state.sessions.coerceAtMost(8)) { i ->
                    val isLongBreakPoint = (i + 1) % 4 == 0
                    Box(
                        modifier = Modifier
                            .size(if (isLongBreakPoint) 10.dp else 8.dp)
                            .clip(CircleShape)
                            .background(if (isLongBreakPoint) colors.blue else colors.primary),
                    )
                }
            }
            Spacer(Modifier.height(20.dp))
        }

        // Controls
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            // Reset
            TimerControlBtn(Icons.Outlined.RestartAlt, "Reset", colors.text3) {
                vm.pomodoroReset()
            }
            // Start / Pause main button
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(colors.primary)
                    .clickable(indication = null,
                        interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                        onClick = { if (state.isRunning) vm.pomodoroPause() else vm.pomodoroStart() }),
            ) {
                Icon(
                    imageVector        = if (state.isRunning) Icons.Outlined.Pause else Icons.Outlined.PlayArrow,
                    contentDescription = if (state.isRunning) "Pause" else "Start",
                    tint               = colors.onPrimary,
                    modifier           = Modifier.size(28.dp),
                )
            }
            // Skip (advance to next phase placeholder)
            TimerControlBtn(Icons.Outlined.SkipNext, "Skip", colors.text3) {
                vm.pomodoroReset()
            }
        }
    }
}

// ── Stopwatch Timer ───────────────────────────────────────────────
@Composable
private fun StopwatchTimer(state: TimerUiState, vm: TimerViewModel) {
    val colors = MaterialTheme.studyColors

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        // Big time display
        Text(
            text       = TimeUtils.toHMS(state.elapsed),
            fontFamily = HeadingFontFamily,
            fontWeight = FontWeight.ExtraBold,
            fontSize   = 52.sp,
            color      = colors.text,
            letterSpacing = (-3.0).sp,
        )
        Spacer(Modifier.height(8.dp))
        Text("Elapsed", fontFamily = BodyFontFamily, fontSize = 12.sp, color = colors.text3)
        Spacer(Modifier.height(28.dp))

        // Controls
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            // Reset
            TimerControlBtn(Icons.Outlined.RestartAlt, "Reset", colors.text3) {
                vm.stopwatchReset()
            }
            // Start / Pause
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(colors.primary)
                    .clickable(indication = null,
                        interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                        onClick = { if (state.isRunning) vm.stopwatchPause() else vm.stopwatchStart() }),
            ) {
                Icon(
                    imageVector        = if (state.isRunning) Icons.Outlined.Pause else Icons.Outlined.PlayArrow,
                    contentDescription = if (state.isRunning) "Pause" else "Start",
                    tint               = colors.onPrimary,
                    modifier           = Modifier.size(28.dp),
                )
            }
            // Log time
            TimerControlBtn(Icons.Outlined.SaveAlt, "Log", colors.text) {
                vm.stopwatchLog()
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Log Time → logs elapsed time to selected lecture",
            fontFamily = BodyFontFamily, fontSize = 11.sp, color = colors.text3,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(0.7f))
    }
}

// ── Pomodoro Arc (Canvas donut progress ring) ─────────────────────
@Composable
private fun TimerArc(
    progress:  Float,
    arcColor:  Color,
    label:     String,
    sublabel:  String,
) {
    val colors = MaterialTheme.studyColors
    val animProgress by animateFloatAsState(
        targetValue   = progress,
        animationSpec = tween(500, easing = LinearEasing),
        label         = "timerArc",
    )

    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(200.dp)) {
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke    = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
            val inset     = 6.dp.toPx()
            val arcSize   = androidx.compose.ui.geometry.Size(
                size.width - inset * 2, size.height - inset * 2)
            val topLeft   = androidx.compose.ui.geometry.Offset(inset, inset)
            // Track
            drawArc(color = colors.border, startAngle = -90f, sweepAngle = 360f,
                useCenter = false, style = stroke,
                topLeft = topLeft, size = arcSize)
            // Progress
            if (animProgress > 0f) {
                drawArc(color = arcColor, startAngle = -90f,
                    sweepAngle = animProgress * 360f,
                    useCenter = false, style = stroke,
                    topLeft = topLeft, size = arcSize)
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontFamily = HeadingFontFamily, fontWeight = FontWeight.ExtraBold,
                fontSize = 38.sp, color = colors.text, letterSpacing = (-2.0).sp)
            if (sublabel.isNotEmpty()) {
                Text(sublabel, fontFamily = BodyFontFamily, fontSize = 11.sp,
                    color = colors.text3)
            }
        }
    }
}

// ── Timer control button (small circular) ────────────────────────
@Composable
private fun TimerControlBtn(
    icon:    androidx.compose.ui.graphics.vector.ImageVector,
    label:   String,
    tint:    Color,
    onClick: () -> Unit,
) {
    val colors = MaterialTheme.studyColors
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(colors.surface2)
                .border(1.dp, colors.border, CircleShape)
                .clickable(indication = null,
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                    onClick = onClick),
        ) {
            Icon(icon, label, tint = tint, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text(label, fontFamily = BodyFontFamily, fontSize = 10.sp, color = colors.text3)
    }
}
