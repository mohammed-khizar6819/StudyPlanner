@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.dashboard

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studyplan.app.domain.engine.AppStats
import com.studyplan.app.domain.engine.BacklogHandler
import com.studyplan.app.domain.engine.SubjectStats
import com.studyplan.app.domain.engine.TimeUtils
import com.studyplan.app.domain.model.Subject
import com.studyplan.app.ui.animation.animatedCounter
import com.studyplan.app.ui.animation.*
import com.studyplan.app.ui.components.*
import com.studyplan.app.ui.components.dialog.ConfirmDialog
import com.studyplan.app.ui.components.dialog.StudyPlanDialog
import com.studyplan.app.ui.theme.*

@Composable
fun DashboardScreen(
    vm: DashboardViewModel = hiltViewModel(),
    onNavigateToSubjects: () -> Unit = {},
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val colors = MaterialTheme.studyColors
    val toast  = LocalToastHost.current

    // Collect toast messages from VM
    LaunchedEffect(Unit) {
        vm.toast.collect { msg -> toast.show(msg) }
    }

    // Backlog dialog state
    var showBacklogDialog by remember { mutableStateOf(false) }

    if (state.isLoading) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = colors.text, strokeWidth = 2.dp,
                modifier = Modifier.size(28.dp))
        }
        return
    }

    // Empty state — no subjects
    if (state.subjects.isEmpty()) {
        EmptyState(
            title    = "No subjects yet",
            subtitle = "Add your first subject to start building your study plan.",
            icon     = Icons.Outlined.Add,
            cta      = "Add Subject →",
            onCta    = onNavigateToSubjects,
            modifier = Modifier.fillMaxSize(),
        )
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.bg)
            .verticalScroll(rememberScrollState()),
    ) {
        PageHeader(title = "Dashboard", subtitle = "Your study overview")

        Column(modifier = Modifier.padding(horizontal = 16.dp)) {

            // ── Alert Banner ──────────────────────────────────────
            DashboardAlertBanner(
                alertState   = state.alertState,
                stats        = state.stats,
                onFixBacklog = { showBacklogDialog = true },
            )

            if (state.alertState != DashboardAlert.NONE) Spacer(Modifier.height(12.dp))

            // ── Exam Countdown Card ───────────────────────────────
            state.nextExam?.let { exam ->
                ExamCountdownCard(exam = exam)
                Spacer(Modifier.height(16.dp))
            }

            // ── Metric Cards (animated counters) ─────────────────
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                val pctCount    = animatedCounter(state.stats.pct)
                val doneCount   = animatedCounter(
                    state.stats.subjectStats.sumOf { it.completedCount })
                val totalCount  = state.stats.subjectStats.sumOf { it.totalCount }

                MetricCard(
                    label    = "OVERALL",
                    value    = "$pctCount%",
                    modifier = Modifier.weight(1f),
                )
                MetricCard(
                    label    = "LECTURES",
                    value    = "$doneCount/$totalCount",
                    modifier = Modifier.weight(1f),
                )
                MetricCard(
                    label    = "STUDIED",
                    value    = TimeUtils.toDisplay(state.stats.completedSecs),
                    modifier = Modifier.weight(1f),
                )
            }
            Spacer(Modifier.height(16.dp))

            // ── Weekly Goal Ring (only if goal set) ───────────────
            if (state.weeklyGoalHours > 0) {
                WeeklyGoalCard(
                    goalHours    = state.weeklyGoalHours,
                    studiedHours = state.weeklyStudiedH,
                )
                Spacer(Modifier.height(16.dp))
            }

            // ── Subject Progress Cards ────────────────────────────
            SectionTitle("Subject Progress")
            Spacer(Modifier.height(8.dp))
            state.stats.subjectStats.forEach { subStats ->
                val subject = state.subjects.find { it.id == subStats.id }
                SubjectProgressCard(subStats = subStats, subject = subject)
                Spacer(Modifier.height(8.dp))
            }

            Spacer(Modifier.height(24.dp))
        }
    }

    // Backlog dialog
    BacklogDialog(
        visible       = showBacklogDialog,
        backlogDisplay = TimeUtils.toDisplay(state.stats.backlogSecs),
        currentHours  = state.stats.subjectStats.firstOrNull()?.let { 0.0 } ?: 6.0,
        onDismiss     = { showBacklogDialog = false },
        onApply       = { strategy, days ->
            vm.handleBacklog(strategy, days)
            showBacklogDialog = false
        },
    )
}

// ── Alert Banner ──────────────────────────────────────────────────
@Composable
private fun DashboardAlertBanner(
    alertState:   DashboardAlert,
    stats:        AppStats,
    onFixBacklog: () -> Unit,
) {
    val today  = TimeUtils.today()
    when (alertState) {
        DashboardAlert.BEFORE_START -> AlertBanner(
            type    = AlertType.INFO,
            message = "Plan starts soon — check your start date in Settings",
        )
        DashboardAlert.OVERDUE -> AlertBanner(
            type    = AlertType.ERROR,
            message = "Deadline overdue by ${-stats.calDaysLeft} day(s)",
            action  = { XsButton("Fix plan →", onClick = onFixBacklog, variant = ButtonVariant.OUTLINE) },
        )
        DashboardAlert.BEHIND -> AlertBanner(
            type    = AlertType.WARN,
            message = "Behind — need ${TimeUtils.toDisplay(stats.requiredDailySecs)}/day, ${stats.studyDaysLeft} study days left",
            action  = { XsButton("Fix →", onClick = onFixBacklog, variant = ButtonVariant.OUTLINE) },
        )
        DashboardAlert.BACKLOG -> AlertBanner(
            type    = AlertType.WARN,
            message = "${TimeUtils.toDisplay(stats.backlogSecs)} backlog from missed sessions",
            action  = { XsButton("Handle →", onClick = onFixBacklog, variant = ButtonVariant.OUTLINE) },
        )
        DashboardAlert.NONE -> Unit
    }
}

// ── Exam Countdown Card ───────────────────────────────────────────
@Composable
private fun ExamCountdownCard(exam: NextExamInfo) {
    val colors = MaterialTheme.studyColors
    val urgencyColor = when (exam.urgencyColor) {
        UrgencyLevel.CRITICAL -> colors.red
        UrgencyLevel.HIGH     -> colors.yellow
        UrgencyLevel.NORMAL   -> colors.green
        UrgencyLevel.GOOD     -> colors.green
    }

    SurfaceCard {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment     = Alignment.Top,
            modifier              = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(exam.subjectName, fontFamily = BodyFontFamily,
                    fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                    color = colors.text, letterSpacing = (-0.21).sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(2.dp))
                Text(exam.urgencyLabel, fontFamily = BodyFontFamily,
                    fontSize = 11.sp, color = urgencyColor)
            }
            Spacer(Modifier.width(16.dp))
            Row(verticalAlignment = Alignment.Baseline) {
                Text(
                    text       = "${exam.daysLeft}",
                    fontFamily = HeadingFontFamily,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize   = 40.sp,
                    color      = urgencyColor,
                    letterSpacing = (-2.8).sp,
                )
                Spacer(Modifier.width(4.dp))
                Text("days left", fontFamily = BodyFontFamily,
                    fontSize = 12.sp, color = colors.text3)
            }
        }
        Spacer(Modifier.height(14.dp))
        AnimatedProgressBar(
            progress  = exam.progressPct / 100f,
            height    = 3.dp,
            fillColor = urgencyColor,
        )
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
            StatItem("${exam.studyDaysLeft}", "STUDY DAYS LEFT")
            if (exam.requiredDailyDisplay.isNotEmpty())
                StatItem(exam.requiredDailyDisplay, "NEED/DAY")
        }
    }
}

@Composable
private fun StatItem(value: String, label: String) {
    val colors = MaterialTheme.studyColors
    Column {
        Text(value, fontFamily = HeadingFontFamily, fontWeight = FontWeight.Bold,
            fontSize = 17.sp, color = colors.text, letterSpacing = (-0.51).sp)
        Text(label, fontFamily = BodyFontFamily, fontWeight = FontWeight.Bold,
            fontSize = 9.sp, color = colors.text3, letterSpacing = 1.sp)
    }
}

// ── Weekly Goal Ring (Canvas arc) ────────────────────────────────
@Composable
private fun WeeklyGoalCard(goalHours: Double, studiedHours: Double) {
    val colors   = MaterialTheme.studyColors
    val progress = (studiedHours / goalHours).coerceIn(0.0, 1.0).toFloat()
    val animProg by animateFloatAsState(
        targetValue   = progress,
        animationSpec = tween(PROGRESS_MS, easing = EaseOut),
        label         = "goalRing",
    )
    val pct = (progress * 100).toInt()

    SurfaceCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Arc canvas
            androidx.compose.foundation.Canvas(modifier = Modifier.size(72.dp)) {
                val stroke    = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                val sweepAngle = 360f * animProg
                // Track
                drawArc(color = colors.border, startAngle = -90f, sweepAngle = 360f,
                    useCenter = false, style = stroke)
                // Fill
                if (animProg > 0f) drawArc(color = colors.primary, startAngle = -90f,
                    sweepAngle = sweepAngle, useCenter = false, style = stroke)
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text("$pct%", fontFamily = HeadingFontFamily, fontWeight = FontWeight.Bold,
                    fontSize = 22.sp, color = colors.text, letterSpacing = (-0.66).sp)
                Text("of weekly ${goalHours.toInt()}h goal", fontFamily = BodyFontFamily,
                    fontSize = 12.sp, color = colors.text3)
                Text(
                    "${TimeUtils.toDisplay((studiedHours * 3600).toLong())} studied",
                    fontFamily = BodyFontFamily, fontSize = 11.sp, color = colors.text2,
                )
            }
        }
    }
}

// ── Subject Progress Card ─────────────────────────────────────────
@Composable
private fun SubjectProgressCard(
    subStats: SubjectStats,
    subject:  Subject? = null,
) {
    val colors     = MaterialTheme.studyColors
    val subColor   = runCatching {
        Color(android.graphics.Color.parseColor(subStats.color))
    }.getOrElse { colors.text3 }

    SurfaceCard(padding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.Top) {
            SubjectColorBar(subStats.color)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column {
                        Text(
                            text       = subject?.fullName?.ifEmpty { subStats.name } ?: subStats.name,
                            fontFamily = BodyFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize   = 14.sp,
                            color      = colors.text,
                            letterSpacing = (-0.21).sp,
                        )
                        Text(subStats.name.uppercase(), fontFamily = BodyFontFamily,
                            fontWeight = FontWeight.Bold, fontSize = 9.sp,
                            color = colors.text3, letterSpacing = 1.sp)
                    }
                    Badge(
                        text = "${subStats.pct}%",
                        type = when {
                            subStats.pct >= 80 -> BadgeType.GREEN
                            subStats.pct >= 40 -> BadgeType.YELLOW
                            else               -> BadgeType.NEUTRAL
                        },
                    )
                }
                Spacer(Modifier.height(10.dp))
                // Stats grid
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    MiniStat("${subStats.completedCount}", "DONE")
                    MiniStat("${subStats.totalCount}", "TOTAL")
                    MiniStat(TimeUtils.toDisplay(subStats.remainingSecs), "LEFT")
                }
                Spacer(Modifier.height(10.dp))
                AnimatedProgressBar(
                    progress  = subStats.pct / 100f,
                    height    = 3.dp,
                    fillColor = subColor,
                )
            }
        }
    }
}

@Composable
private fun MiniStat(value: String, label: String) {
    val colors = MaterialTheme.studyColors
    Column {
        Text(value, fontFamily = BodyFontFamily, fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp, color = colors.text)
        Text(label, fontFamily = BodyFontFamily, fontWeight = FontWeight.Bold,
            fontSize = 9.sp, color = colors.text3, letterSpacing = 0.9.sp)
    }
}

// ── Backlog Handler Dialog ────────────────────────────────────────
@Composable
private fun BacklogDialog(
    visible:       Boolean,
    backlogDisplay: String,
    currentHours:  Double,
    onDismiss:     () -> Unit,
    onApply:       (BacklogHandler.Strategy, Int) -> Unit,
) {
    if (!visible) return
    val colors           = MaterialTheme.studyColors
    var selected         by remember { mutableStateOf(BacklogHandler.Strategy.ACKNOWLEDGE) }
    var redistributeDays by remember { mutableIntStateOf(7) }

    com.studyplan.app.ui.components.dialog.StudyPlanDialog(
        visible   = true,
        title     = "Handle Backlog",
        onDismiss = onDismiss,
        footer    = {
            OutlineButton("Cancel", onClick = onDismiss)
            Spacer(Modifier.width(8.dp))
            PrimaryButton("Apply", onClick = { onApply(selected, redistributeDays) })
        },
    ) {
        // Info row
        Box(
            modifier = Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(colors.surface2)
                .padding(horizontal = 12.dp, vertical = 10.dp),
        ) {
            Text("You have $backlogDisplay of backlog from missed sessions.",
                fontFamily = BodyFontFamily, fontSize = 13.sp, color = colors.text2,
                lineHeight = 20.sp)
        }
        Spacer(Modifier.height(14.dp))

        val options = listOf(
            BacklogHandler.Strategy.EXTEND_DEADLINES to "Extend all deadlines by 2 weeks",
            BacklogHandler.Strategy.INCREASE_HOURS   to "Increase daily hours by 1h",
            BacklogHandler.Strategy.ACKNOWLEDGE      to "Acknowledge & reschedule forward",
            BacklogHandler.Strategy.REDISTRIBUTE     to "Redistribute across next days",
        )
        options.forEach { (strategy, label) ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(
                        indication = null,
                        interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                        onClick = { selected = strategy }
                    )
                    .padding(vertical = 8.dp),
            ) {
                RadioButton(
                    selected = selected == strategy,
                    onClick  = { selected = strategy },
                    colors   = RadioButtonDefaults.colors(
                        selectedColor   = colors.primary,
                        unselectedColor = colors.text3,
                    ),
                )
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(label, fontFamily = BodyFontFamily, fontSize = 13.sp, color = colors.text)
                    if (strategy == BacklogHandler.Strategy.REDISTRIBUTE &&
                        selected == strategy) {
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Over", fontFamily = BodyFontFamily, fontSize = 12.sp, color = colors.text2)
                            Spacer(Modifier.width(8.dp))
                            StudyTextField(
                                value         = redistributeDays.toString(),
                                onValueChange = { redistributeDays = it.toIntOrNull() ?: 7 },
                                keyboardType  = androidx.compose.ui.text.input.KeyboardType.Number,
                                modifier      = Modifier.width(60.dp),
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("days", fontFamily = BodyFontFamily, fontSize = 12.sp, color = colors.text2)
                        }
                    }
                }
            }
        }
    }
}
