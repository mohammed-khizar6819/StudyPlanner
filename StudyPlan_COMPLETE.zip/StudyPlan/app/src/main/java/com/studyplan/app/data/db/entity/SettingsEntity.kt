package com.studyplan.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.studyplan.app.domain.model.AppSettings

/** Single-row table — always upserted by primary key = 1 */
@Entity(tableName = "settings")
data class SettingsEntity(
    @PrimaryKey val id:                Int = 1,
    val startDate:             String,
    val dailyStudyHours:       Double,
    val bufferDayOfWeek:       Int,
    val weeklyGoalHours:       Double,
    val interleaveSubjects:    Boolean,
    val intensityRampEnabled:  Boolean,
    val intensityStartHours:   Double,
    val intensityEndHours:     Double,
    val examLockDays:          Int,
    val alarmEnabled:          Boolean,
    val alarmHour:             Int,
    val alarmMinute:           Int,
    val notifEnabled:          Boolean,
    val notifHour:             Int,
    val vacationDates:         List<String>,
) {
    fun toDomain() = AppSettings(startDate, dailyStudyHours, bufferDayOfWeek,
        weeklyGoalHours, interleaveSubjects, intensityRampEnabled,
        intensityStartHours, intensityEndHours, examLockDays,
        alarmEnabled, alarmHour, alarmMinute, notifEnabled, notifHour, vacationDates)
    companion object {
        fun fromDomain(s: AppSettings) = SettingsEntity(1, s.startDate,
            s.dailyStudyHours, s.bufferDayOfWeek, s.weeklyGoalHours,
            s.interleaveSubjects, s.intensityRampEnabled, s.intensityStartHours,
            s.intensityEndHours, s.examLockDays, s.alarmEnabled, s.alarmHour,
            s.alarmMinute, s.notifEnabled, s.notifHour, s.vacationDates)
    }
}
