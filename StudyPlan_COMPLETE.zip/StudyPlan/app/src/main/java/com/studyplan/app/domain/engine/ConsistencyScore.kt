package com.studyplan.app.domain.engine

import com.studyplan.app.domain.repository.ScheduleRepository
import com.studyplan.app.domain.repository.SettingsRepository
import com.studyplan.app.domain.model.ScheduleEntryStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Computes the consistency score displayed in Analytics.
 * Formula: weighted combination of streak × completion rate over last 30 days.
 */
@Singleton
class ConsistencyScore @Inject constructor(
    private val scheduleRepo: ScheduleRepository,
    private val settingsRepo: SettingsRepository,
) {
    data class Result(val score: Int, val label: String, val colorToken: String)

    /**
     * Score 0–100. Mirrors the HTML AnalyticsExtras consistency widget.
     * colorToken: "green" | "yellow" | "red" — maps to StudyPlanColors token name.
     */
    suspend fun compute(): Result = withContext(Dispatchers.Default) {
        val today    = TimeUtils.today()
        val settings = settingsRepo.get()
        val bufferDay = settings?.bufferDayOfWeek ?: 0

        // Look back 30 days
        val lookbackDays = 30
        var studiedDays  = 0
        var plannedDays  = 0
        var totalStudied = 0L
        var totalPlanned = 0L

        for (i in 1..lookbackDays) {
            val date = TimeUtils.addDays(today, -i.toLong())
            if (bufferDay != -1 && TimeUtils.dayOfWeek(date) == bufferDay) continue
            val entries = scheduleRepo.getForDate(date)
            if (entries.isEmpty()) continue

            plannedDays++
            totalPlanned += entries.sumOf { it.plannedSeconds }
            val studied = entries.sumOf { it.completedSeconds }
            totalStudied += studied
            if (studied > 0) studiedDays++
        }

        // Completion rate component (0–100)
        val completionRate = if (totalPlanned > 0)
            min(100.0, (totalStudied.toDouble() / totalPlanned) * 100) else 0.0

        // Attendance component: days actually studied / planned days (0–100)
        val attendance = if (plannedDays > 0)
            min(100.0, (studiedDays.toDouble() / plannedDays) * 100) else 0.0

        // Streak component (caps at 30)
        var streak = 0
        for (i in 1..lookbackDays) {
            val date = TimeUtils.addDays(today, -i.toLong())
            if (bufferDay != -1 && TimeUtils.dayOfWeek(date) == bufferDay) continue
            val entries = scheduleRepo.getForDate(date)
            if (entries.any { it.status == ScheduleEntryStatus.DONE ||
                              it.status == ScheduleEntryStatus.PARTIAL_DONE }) streak++
            else break
        }
        val streakComponent = min(100.0, (streak.toDouble() / 14) * 100) // 14-day streak = 100

        // Weighted average: 40% completion rate + 35% attendance + 25% streak
        val score = ((completionRate * 0.40) + (attendance * 0.35) + (streakComponent * 0.25))
            .roundToInt().coerceIn(0, 100)

        val (label, colorToken) = when {
            score >= 80 -> "Excellent"  to "green"
            score >= 60 -> "Good"       to "green"
            score >= 40 -> "Fair"       to "yellow"
            score >= 20 -> "Needs Work" to "red"
            else        -> "Critical"   to "red"
        }

        Result(score, label, colorToken)
    }
}
