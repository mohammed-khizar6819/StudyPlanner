package com.studyplan.app.io

import android.content.Context
import android.net.Uri
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import com.studyplan.app.data.json.BackupMapper
import com.studyplan.app.data.json.StudyPlanBackup
import com.studyplan.app.domain.engine.SchedulerEngine
import com.studyplan.app.domain.engine.StatsEngine
import com.studyplan.app.domain.repository.*
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

sealed class ImportResult {
    data class Success(val message: String) : ImportResult()
    data class Error(val reason: String)    : ImportResult()
    object InvalidFile                       : ImportResult()
}

@Singleton
class DataImporter @Inject constructor(
    @ApplicationContext private val context: Context,
    private val subjectRepo:     SubjectRepository,
    private val lectureRepo:     LectureRepository,
    private val scheduleRepo:    ScheduleRepository,
    private val noteRepo:        NoteRepository,
    private val sessionRepo:     SessionLogRepository,
    private val settingsRepo:    SettingsRepository,
    private val metaRepo:        MetaRepository,
    private val schedulerEngine: SchedulerEngine,
    private val statsEngine:     StatsEngine,
) {
    private val moshi   = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    private val adapter = moshi.adapter(StudyPlanBackup::class.java)

    /** Reads and validates a JSON backup file from URI */
    suspend fun readBackupFromUri(uri: Uri): String? = withContext(Dispatchers.IO) {
        runCatching {
            context.contentResolver.openInputStream(uri)?.bufferedReader()?.readText()
        }.getOrNull()
    }

    /** Validates the JSON — must have lectures and subjects keys */
    fun validateJson(json: String): Boolean {
        return runCatching {
            val backup = adapter.fromJson(json)
            backup?.lectures != null && backup.subjects != null
        }.getOrDefault(false)
    }

    /** Replaces all current data with backup and rebuilds schedule */
    suspend fun importBackup(json: String): ImportResult = withContext(Dispatchers.IO) {
        val backup = runCatching { adapter.fromJson(json) }.getOrNull()
            ?: return@withContext ImportResult.Error("Could not parse backup file")

        if (backup.lectures == null || backup.subjects == null)
            return@withContext ImportResult.InvalidFile

        val restored = BackupMapper.fromBackup(backup)

        // Wipe current data
        scheduleRepo.deleteAll()
        noteRepo.deleteAll()
        sessionRepo.deleteAll()
        lectureRepo.deleteAll()
        subjectRepo.deleteAll()
        settingsRepo.deleteAll()
        metaRepo.deleteAll()

        // Restore from backup
        settingsRepo.upsert(restored.settings.toDomain())
        metaRepo.upsert(restored.meta.toDomain())
        subjectRepo.insertAll(restored.subjects.map { it.toDomain() })
        lectureRepo.insertAll(restored.lectures.map { it.toDomain() })
        scheduleRepo.insertAll(restored.entries.map { it.toDomain() })
        noteRepo.insertAll(restored.notes.map { it.toDomain() })
        sessionRepo.insertAll(restored.sessionLogs.map { it.toDomain() })

        // Invalidate stats cache and rebuild
        statsEngine.invalidate()
        schedulerEngine.buildSchedule(forceRebuildToday = false)

        ImportResult.Success("Backup imported! ${backup.subjects.size} subjects, ${backup.lectures.size} lectures restored.")
    }
}
