@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.settings

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studyplan.app.domain.engine.TimeUtils
import com.studyplan.app.domain.model.SavedPlan
import com.studyplan.app.domain.model.AppSettings
import com.studyplan.app.io.ImportResult
import com.studyplan.app.ui.components.*
import com.studyplan.app.ui.components.dialog.ConfirmDialog
import com.studyplan.app.ui.components.dialog.StudyPlanDialog
import com.studyplan.app.ui.theme.*

@Composable
fun SettingsScreen(vm: SettingsViewModel = hiltViewModel()) {
    val state   by vm.state.collectAsStateWithLifecycle()
    val colors   = MaterialTheme.studyColors
    val context  = LocalContext.current
    val activity = context as? Activity
    val toast    = LocalToastHost.current

    // Wire toast, share intent, print request
    LaunchedEffect(Unit) {
        vm.toast.collect { toast.show(it) }
    }
    LaunchedEffect(Unit) {
        vm.shareIntent.collect { intent ->
            context.startActivity(android.content.Intent.createChooser(intent, "Export Backup"))
        }
    }
    LaunchedEffect(Unit) {
        vm.printRequest.collect {
            activity?.let { vm.doPrint(it) }
        }
    }

    // JSON import file picker
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> uri?.let { vm.importJson(it) } }

    // Import result feedback
    LaunchedEffect(Unit) {
        vm.importResult.collect { result ->
            when (result) {
                is ImportResult.Success  -> toast.show(result.message)
                is ImportResult.Error    -> toast.show(result.reason, isError = true)
                is ImportResult.InvalidFile -> toast.show("Invalid backup file", isError = true)
            }
        }
    }

    // Dialog states
    var showResetDialog   by remember { mutableStateOf(false) }
    var showSavePlanDlg   by remember { mutableStateOf(false) }
    var showNewPlanDlg    by remember { mutableStateOf(false) }
    var showLoadPlanDlg   by remember { mutableStateOf<String?>(null) }
    var showDeletePlanDlg by remember { mutableStateOf<String?>(null) }
    var savePlanName      by remember { mutableStateOf("") }
    var newPlanName       by remember { mutableStateOf("") }

    if (state.isLoading || state.settings == null) {
        Box(Modifier.fillMaxSize(), Alignment.Center) {
            CircularProgressIndicator(color = colors.text, strokeWidth = 2.dp,
                modifier = Modifier.size(28.dp))
        }
        return
    }

    val settings = state.settings!!

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.bg)
            .verticalScroll(rememberScrollState()),
    ) {
        PageHeader(title = "Settings")

        Column(modifier = Modifier.padding(horizontal = 16.dp)) {

            // ══════════════════════════════════════════════════════
            //  1. STUDY SCHEDULE
            // ══════════════════════════════════════════════════════
            SettingsSection("Study Schedule") {
                SettingsRow(
                    label = "Study Start Date",
                    hint  = "Lectures are not scheduled before this date",
                ) {
                    DatePickerField(
                        value    = settings.startDate,
                        onSelect = { vm.setSetting("startDate", it) },
                        modifier = Modifier.width(160.dp),
                    )
                }
                SettingsRowDivider()
                SettingsRow(label = "Daily Study Hours") {
                    StudyTextField(
                        value         = settings.dailyStudyHours.toString(),
                        onValueChange = { v -> v.toDoubleOrNull()?.let { vm.setSetting("dailyStudyHours", it) } },
                        keyboardType  = androidx.compose.ui.text.input.KeyboardType.Decimal,
                        modifier      = Modifier.width(80.dp),
                    )
                }
                SettingsRowDivider()
                SettingsRow(label = "Weekly Rest Day") {
                    val bufferOptions = listOf(
                        DropdownOption(-1, "None"),
                        DropdownOption(0,  "Sunday"),
                        DropdownOption(1,  "Monday"),
                        DropdownOption(2,  "Tuesday"),
                        DropdownOption(3,  "Wednesday"),
                        DropdownOption(4,  "Thursday"),
                        DropdownOption(5,  "Friday"),
                        DropdownOption(6,  "Saturday"),
                    )
                    StudyDropdown(
                        options  = bufferOptions,
                        selected = settings.bufferDayOfWeek,
                        onSelect = { vm.setSetting("bufferDayOfWeek", it) },
                        modifier = Modifier.width(130.dp),
                    )
                }
                SettingsRowDivider()
                SettingsRow(label = "Exam Lock Days",
                    hint = "No new lectures scheduled this many days before exam") {
                    StudyTextField(
                        value         = settings.examLockDays.toString(),
                        onValueChange = { v -> v.toIntOrNull()?.let { vm.setSetting("examLockDays", it) } },
                        keyboardType  = androidx.compose.ui.text.input.KeyboardType.Number,
                        modifier      = Modifier.width(80.dp),
                    )
                }
            }

            // ══════════════════════════════════════════════════════
            //  2. APPEARANCE
            // ══════════════════════════════════════════════════════
            SettingsSection("Appearance") {
                SettingsRow(label = "Weekly Goal (hours)",
                    hint = "Set to 0 to disable. Shows progress ring on dashboard.") {
                    StudyTextField(
                        value         = settings.weeklyGoalHours.toInt().toString(),
                        onValueChange = { v -> v.toDoubleOrNull()?.let { vm.setSetting("weeklyGoalHours", it) } },
                        keyboardType  = androidx.compose.ui.text.input.KeyboardType.Number,
                        modifier      = Modifier.width(80.dp),
                    )
                }
            }

            // ══════════════════════════════════════════════════════
            //  3. SCHEDULING INTELLIGENCE
            // ══════════════════════════════════════════════════════
            SettingsSection("Scheduling Intelligence") {
                SettingsRow(label = "Interleave Subjects",
                    hint = "Alternates between subjects within each day") {
                    StudyToggle(
                        checked   = settings.interleaveSubjects,
                        onChecked = { vm.setSetting("interleaveSubjects", it) },
                    )
                }
            }

            // ══════════════════════════════════════════════════════
            //  4. INTENSITY RAMP
            // ══════════════════════════════════════════════════════
            SettingsSection("Intensity Ramp") {
                FieldHint("Gradually increase daily study hours as the exam approaches.")
                Spacer(Modifier.height(8.dp))
                SettingsRow(label = "Enable Ramp") {
                    StudyToggle(
                        checked   = settings.intensityRampEnabled,
                        onChecked = { vm.setSetting("intensityRampEnabled", it) },
                    )
                }
                if (settings.intensityRampEnabled) {
                    SettingsRowDivider()
                    SettingsRow(label = "Start Hours/day") {
                        StudyTextField(
                            value         = settings.intensityStartHours.toString(),
                            onValueChange = { v -> v.toDoubleOrNull()?.let { vm.setSetting("intensityStartHours", it) } },
                            keyboardType  = androidx.compose.ui.text.input.KeyboardType.Decimal,
                            modifier      = Modifier.width(80.dp),
                        )
                    }
                    SettingsRowDivider()
                    SettingsRow(label = "End Hours/day") {
                        StudyTextField(
                            value         = settings.intensityEndHours.toString(),
                            onValueChange = { v -> v.toDoubleOrNull()?.let { vm.setSetting("intensityEndHours", it) } },
                            keyboardType  = androidx.compose.ui.text.input.KeyboardType.Decimal,
                            modifier      = Modifier.width(80.dp),
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    // Mini ramp preview bars
                    RampPreview(start = settings.intensityStartHours, end = settings.intensityEndHours)
                }
            }

            // ══════════════════════════════════════════════════════
            //  5. STUDY ALARM
            // ══════════════════════════════════════════════════════
            SettingsSection("Study Alarm") {
                SettingsRow(label = "Enable Alarm") {
                    StudyToggle(
                        checked   = settings.alarmEnabled,
                        onChecked = { vm.toggleAlarm(it) },
                    )
                }
                SettingsRowDivider()
                SettingsRow(
                    label = "Alarm Time",
                    hint  = if (settings.alarmEnabled) state.alarmTimeUntil else null,
                ) {
                    TimePickerField(
                        hour     = settings.alarmHour,
                        minute   = settings.alarmMinute,
                        onSelect = { h, m -> vm.setAlarmTime(h, m) },
                        modifier = Modifier.width(130.dp),
                    )
                }
            }

            // ══════════════════════════════════════════════════════
            //  6. NOTIFICATIONS
            // ══════════════════════════════════════════════════════
            SettingsSection("Daily Reminder") {
                SettingsRow(label = "Enable Reminder") {
                    StudyToggle(
                        checked   = settings.notifEnabled,
                        onChecked = { vm.toggleNotif(it) },
                    )
                }
                SettingsRowDivider()
                SettingsRow(label = "Reminder Hour") {
                    val hourOptions = (0..23).map {
                        val lbl = if (it == 0) "12 AM" else if (it < 12) "$it AM"
                                  else if (it == 12) "12 PM" else "${it-12} PM"
                        DropdownOption(it, lbl)
                    }
                    StudyDropdown(
                        options  = hourOptions,
                        selected = settings.notifHour,
                        onSelect = { vm.setNotifHour(it) },
                        modifier = Modifier.width(120.dp),
                    )
                }
            }

            // ══════════════════════════════════════════════════════
            //  7. STUDY PLANS
            // ══════════════════════════════════════════════════════
            SettingsSection("Study Plans") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlineButton("💾 Save Current Plan",
                        onClick = { showSavePlanDlg = true })
                    OutlineButton("+ New Blank Plan",
                        onClick = { showNewPlanDlg = true })
                }
                if (state.savedPlans.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    state.savedPlans.forEach { plan ->
                        PlanCard(
                            plan      = plan,
                            onLoad    = { showLoadPlanDlg = plan.id },
                            onDelete  = { showDeletePlanDlg = plan.id },
                        )
                        Spacer(Modifier.height(6.dp))
                    }
                } else {
                    Spacer(Modifier.height(8.dp))
                    Text("No saved plans yet.", fontFamily = BodyFontFamily,
                        fontSize = 13.sp, color = colors.text3)
                }
            }

            // ══════════════════════════════════════════════════════
            //  8. DATA MANAGEMENT
            // ══════════════════════════════════════════════════════
            SettingsSection("Data Management") {
                // Export row
                SettingsRow(label = "Export Backup") {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SmButton("PDF Report", onClick = { vm.exportPdf() },
                            variant = ButtonVariant.OUTLINE)
                        SmButton("JSON",       onClick = { vm.exportJson() },
                            variant = ButtonVariant.OUTLINE)
                    }
                }
                SettingsRowDivider()
                SettingsRow(label = "Import Backup",
                    hint = "Replaces all current data with backup") {
                    SmButton("Import JSON",
                        onClick = { importLauncher.launch("application/json") },
                        variant = ButtonVariant.OUTLINE)
                }
                SettingsRowDivider()
                SettingsRow(label = "Reset Everything") {
                    SmButton("Reset", onClick = { showResetDialog = true },
                        variant = ButtonVariant.DANGER)
                }
            }

            Spacer(Modifier.height(40.dp))
        }
    }

    // ── Dialogs ───────────────────────────────────────────────────
    ConfirmDialog(
        visible     = showResetDialog,
        title       = "Reset Everything",
        message     = "Permanently deletes all data and progress. This cannot be undone.",
        confirmText = "Yes, Reset",
        destructive = true,
        onConfirm   = { vm.resetApp() },
        onDismiss   = { showResetDialog = false },
    )

    if (showSavePlanDlg) {
        StudyPlanDialog(
            visible   = true,
            title     = "Save Current Plan",
            onDismiss = { showSavePlanDlg = false; savePlanName = "" },
            footer    = {
                OutlineButton("Cancel", onClick = { showSavePlanDlg = false; savePlanName = "" })
                Spacer(Modifier.width(8.dp))
                PrimaryButton("Save") {
                    if (savePlanName.isBlank()) return@PrimaryButton
                    vm.saveCurrentPlan(savePlanName)
                    showSavePlanDlg = false; savePlanName = ""
                }
            },
        ) {
            FieldLabel("Plan Name")
            StudyTextField(value = savePlanName, onValueChange = { savePlanName = it },
                placeholder = "e.g. My CA Final Plan")
        }
    }

    if (showNewPlanDlg) {
        StudyPlanDialog(
            visible   = true,
            title     = "New Blank Plan",
            onDismiss = { showNewPlanDlg = false; newPlanName = "" },
            footer    = {
                OutlineButton("Cancel", onClick = { showNewPlanDlg = false; newPlanName = "" })
                Spacer(Modifier.width(8.dp))
                PrimaryButton("Create") {
                    if (newPlanName.isBlank()) return@PrimaryButton
                    vm.newBlankPlan(newPlanName)
                    showNewPlanDlg = false; newPlanName = ""
                }
            },
        ) {
            Text("This will save your current plan, then create a fresh blank one.",
                fontFamily = BodyFontFamily, fontSize = 13.sp,
                color = MaterialTheme.studyColors.text2, lineHeight = 20.sp)
            Spacer(Modifier.height(12.dp))
            FieldLabel("New Plan Name")
            StudyTextField(value = newPlanName, onValueChange = { newPlanName = it },
                placeholder = "e.g. Plan 2")
        }
    }

    showLoadPlanDlg?.let { planId ->
        ConfirmDialog(
            visible     = true,
            title       = "Load Plan",
            message     = "This will replace your current data with the saved plan.",
            confirmText = "Load",
            onConfirm   = { vm.loadPlan(planId) },
            onDismiss   = { showLoadPlanDlg = null },
        )
    }

    showDeletePlanDlg?.let { planId ->
        ConfirmDialog(
            visible     = true,
            title       = "Delete Plan",
            message     = "Delete this saved plan? Cannot be undone.",
            confirmText = "Delete",
            destructive = true,
            onConfirm   = { vm.deletePlan(planId) },
            onDismiss   = { showDeletePlanDlg = null },
        )
    }
}

// ── Settings section card ─────────────────────────────────────────
@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    val colors = MaterialTheme.studyColors
    SurfaceCard(modifier = Modifier.padding(bottom = 12.dp)) {
        Text(title, fontFamily = HeadingFontFamily, fontWeight = FontWeight.Bold,
            fontSize = 14.sp, color = colors.text, letterSpacing = (-0.28).sp)
        Spacer(Modifier.height(2.dp))
        HorizontalDivider(color = colors.border, thickness = 1.dp,
            modifier = Modifier.padding(vertical = 10.dp))
        content()
    }
}

@Composable
private fun SettingsRowDivider() {
    HorizontalDivider(
        color     = MaterialTheme.studyColors.border.copy(.5f),
        thickness = 0.5.dp,
        modifier  = Modifier.padding(vertical = 6.dp),
    )
}

// ── Intensity ramp preview (14 bars) ─────────────────────────────
@Composable
private fun RampPreview(start: Double, end: Double) {
    val colors = MaterialTheme.studyColors
    Row(
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment     = Alignment.Bottom,
        modifier              = Modifier.fillMaxWidth().height(40.dp),
    ) {
        repeat(14) { i ->
            val h = start + ((end - start) / 13.0) * i
            val fraction = (h / end).coerceIn(0.0, 1.0).toFloat()
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(fraction.coerceAtLeast(0.1f))
                    .clip(RoundedCornerShape(2.dp))
                    .background(colors.primary.copy(alpha = 0.4f + fraction * 0.6f)),
            )
        }
    }
}

// ── Saved plan card ───────────────────────────────────────────────
@Composable
private fun PlanCard(
    plan:     com.studyplan.app.domain.model.SavedPlan,
    onLoad:   () -> Unit,
    onDelete: () -> Unit,
) {
    val colors = MaterialTheme.studyColors
    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(colors.surface2)
            .border(1.dp, colors.border, RoundedCornerShape(8.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(plan.name, fontFamily = BodyFontFamily, fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp, color = colors.text,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${plan.subjectCount} subjects · ${plan.lectureCount} lectures · ${TimeUtils.formatDisplay(plan.savedAt)}",
                fontFamily = BodyFontFamily, fontSize = 11.sp, color = colors.text3)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            XsButton("Load",   onClick = onLoad,   variant = ButtonVariant.OUTLINE)
            XsButton("Delete", onClick = onDelete, variant = ButtonVariant.DANGER)
        }
    }
}
