@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyplan.app.ui.theme.HeadingFontFamily
import com.studyplan.app.ui.theme.MonoFontFamily
import com.studyplan.app.ui.theme.BodyFontFamily
import com.studyplan.app.ui.theme.studyColors

// ── Page Header ───────────────────────────────────────────────────
@Composable
fun PageHeader(
    title:    String,
    subtitle: String?     = null,
    actions:  @Composable (RowScope.() -> Unit)? = null,
    modifier: Modifier    = Modifier,
) {
    val colors = MaterialTheme.studyColors
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 20.dp),
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text       = title,
                fontFamily = HeadingFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize   = 22.sp,
                color      = colors.text,
                letterSpacing = (-0.66).sp,
            )
            if (subtitle != null) {
                Spacer(Modifier.height(2.dp))
                Text(
                    text       = subtitle,
                    fontFamily = BodyFontFamily,
                    fontWeight = FontWeight.Normal,
                    fontSize   = 13.sp,
                    color      = colors.text3,
                )
            }
        }
        if (actions != null) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment     = androidx.compose.ui.Alignment.CenterVertically,
                modifier              = Modifier.padding(start = 12.dp),
                content               = actions,
            )
        }
    }
}

// ── Section Title ─────────────────────────────────────────────────
@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.studyColors
    Text(
        text       = text,
        fontFamily = BodyFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize   = 13.sp,
        color      = colors.text2,
        modifier   = modifier.padding(bottom = 8.dp),
    )
}

// ── Label (ALL CAPS, 9–10sp, 700 weight) ─────────────────────────
@Composable
fun CapsLabel(text: String, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.studyColors
    Text(
        text          = text.uppercase(),
        fontFamily    = Figtree,
        fontWeight    = FontWeight.Bold,
        fontSize      = 9.sp,
        color         = colors.text3,
        letterSpacing = 1.0.sp,
        modifier      = modifier,
    )
}

// ── Metric value (big number on Dashboard) ────────────────────────
@Composable
fun MetricValue(text: String, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.studyColors
    Text(
        text       = text,
        fontFamily = HeadingFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize   = 28.sp,
        color      = colors.text,
        letterSpacing = (-1.12).sp,
        modifier   = modifier,
    )
}

// ── Mono text (durations, dates) ──────────────────────────────────
@Composable
fun MonoText(text: String, fontSize: Int = 12, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.studyColors
    Text(
        text       = text,
        fontFamily = MonoFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize   = fontSize.sp,
        color      = colors.text2,
        modifier   = modifier,
    )
}
