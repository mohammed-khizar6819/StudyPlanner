package com.studyplan.app.data.repository
import com.studyplan.app.data.db.dao.NoteDao
import com.studyplan.app.data.db.entity.NoteEntity
import com.studyplan.app.domain.model.Note
import com.studyplan.app.domain.model.NoteType
import com.studyplan.app.domain.repository.NoteRepository
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NoteRepositoryImpl @Inject constructor(
    private val dao: NoteDao,
) : NoteRepository {
    override fun observeAll()                             = dao.observeAll().map { it.map { e -> e.toDomain() } }
    override suspend fun getAll()                         = dao.getAll().map { it.toDomain() }
    override fun observeForLecture(lid: String)           = dao.observeForLecture(lid).map { it.map { e -> e.toDomain() } }
    override suspend fun getForLecture(lid: String)       = dao.getForLecture(lid).map { it.toDomain() }
    override suspend fun getByType(type: NoteType)        = dao.getByType(type).map { it.toDomain() }
    override suspend fun getKeyPointsForLecture(lid: String) = dao.getKeyPointsForLecture(lid).map { it.toDomain() }
    override suspend fun insert(n: Note)                  = dao.insert(NoteEntity.fromDomain(n))
    override suspend fun insertAll(list: List<Note>)      = dao.insertAll(list.map { NoteEntity.fromDomain(it) })
    override suspend fun setResolved(id: String, resolved: Boolean) = dao.setResolved(id, resolved)
    override suspend fun delete(id: String)               = dao.deleteById(id)
    override suspend fun deleteForLecture(lid: String)    = dao.deleteForLecture(lid)
    override suspend fun deleteAll()                      = dao.deleteAll()
}
