package com.studyplan.app.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.studyplan.app.domain.repository.SettingsRepository
import com.studyplan.app.worker.NotifWorkerScheduler
import com.studyplan.app.worker.MidnightRebuildScheduler
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class BootReceiver : BroadcastReceiver() {

    @Inject lateinit var alarmScheduler:    AlarmScheduler
    @Inject lateinit var settingsRepo:      com.studyplan.app.domain.repository.SettingsRepository
    @Inject lateinit var notifScheduler:    NotifWorkerScheduler
    @Inject lateinit var midnightScheduler: MidnightRebuildScheduler

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED) return

        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val settings = settingsRepo.get() ?: return@launch
                // Reschedule study alarm
                if (settings.alarmEnabled) {
                    alarmScheduler.schedule(settings.alarmHour, settings.alarmMinute)
                }
                // Reschedule daily notification
                if (settings.notifEnabled) {
                    notifScheduler.schedule(settings.notifHour)
                }
                // Reschedule midnight schedule rebuild
                midnightScheduler.schedule()
            } finally {
                pending.finish()
            }
        }
    }
}
