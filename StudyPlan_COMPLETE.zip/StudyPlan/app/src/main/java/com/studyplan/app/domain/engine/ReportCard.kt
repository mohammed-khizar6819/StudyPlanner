package com.studyplan.app.domain.engine

import com.studyplan.app.domain.repository.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Port of HTML ReportCard object.
 * Generates a weekly study report data class + plain-text shareable string.
 */
@Singleton
class ReportCard @Inject constructor(
    private val statsEngine: StatsEngine,
) {
    data class Report(
        val from:           String,   // start of 7-day window (YYYY-MM-DD)
        val to:             String,   // today (YYYY-MM-DD)
        val weekStudied:    Long,     // seconds studied this week
        val weekDone:       Int,      // lectures completed this week
        val streak:         Int,      // current streak in days
        val completionRate: Int,      // % of planned time completed this week
        val overallPct:     Int,      // overall progress across all lectures
    )

    suspend fun generate(): Report = withContext(Dispatchers.Default) {
        val today   = TimeUtils.today()
        val from    = TimeUtils.addDays(today, -6)
        val weekly  = statsEngine.getWeeklyStats()
        val overall = statsEngine.getStats()

        Report(
            from           = from,
            to             = today,
            weekStudied    = weekly.weekStudiedSecs,
            weekDone       = weekly.weekDone,
            streak         = weekly.streak,
            completionRate = weekly.completionRate,
            overallPct     = overall.pct,
        )
    }

    /**
     * Plain text version for Android share sheet / clipboard.
     * Mirrors HTML ReportCard.copyText().
     */
    suspend fun formatAsText(): String {
        val r = generate()
        return buildString {
            appendLine("📊 Weekly Study Report (${TimeUtils.formatDisplay(r.from)} – ${TimeUtils.formatDisplay(r.to)})")
            appendLine("⏱ Total Studied: ${TimeUtils.toDisplay(r.weekStudied)}")
            appendLine("📚 Lectures Done: ${r.weekDone}")
            appendLine("🔥 Streak: ${r.streak} days")
            appendLine("✅ Completion: ${r.completionRate}%")
            append("📈 Overall: ${r.overallPct}%")
        }
    }
}
