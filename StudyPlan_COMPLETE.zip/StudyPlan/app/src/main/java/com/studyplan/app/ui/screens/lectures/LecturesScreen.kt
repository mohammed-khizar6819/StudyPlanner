@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.lectures

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studyplan.app.domain.engine.TimeUtils
import com.studyplan.app.domain.model.*
import com.studyplan.app.ui.animation.*
import com.studyplan.app.ui.components.*
import com.studyplan.app.ui.components.dialog.*
import com.studyplan.app.ui.theme.*
import androidx.compose.animation.AnimatedVisibility

@Composable
fun LecturesScreen(vm: LecturesViewModel = hiltViewModel()) {
    val state  by vm.state.collectAsStateWithLifecycle()
    val colors  = MaterialTheme.studyColors
    val toast   = LocalToastHost.current

    LaunchedEffect(Unit) { vm.toast.collect { toast.show(it) } }

    var showAdd        by remember { mutableStateOf(false) }
    var editLecture    by remember { mutableStateOf<Lecture?>(null) }
    var deleteLecture  by remember { mutableStateOf<Lecture?>(null) }
    var showImport     by remember { mutableStateOf(false) }
    var actionLecture  by remember { mutableStateOf<Lecture?>(null) }

    Column(modifier = Modifier.fillMaxSize().background(colors.bg)) {

        // ── Page header + actions ─────────────────────────────────
        PageHeader(
            title    = "Lectures",
            subtitle = "${state.filtered.size} of ${state.lectures.size}",
            actions  = {
                XsButton("Import", onClick = { showImport = true }, variant = ButtonVariant.OUTLINE)
                Spacer(Modifier.width(6.dp))
                PrimaryButton("+ Add", onClick = { showAdd = true })
            },
        )

        // ── Filter + Search bar ───────────────────────────────────
        FilterBar(state = state, vm = vm)

        // ── Bulk selection bar ────────────────────────────────────
        AnimatedVisibility(visible = state.selected.isNotEmpty()) {
            BulkSelectionBar(
                selectedCount  = state.selected.size,
                onMarkDone     = { vm.markSelectedDone() },
                onDelete       = { vm.deleteSelected() },
                onClear        = { vm.clearSelection() },
            )
        }

        // ── Lecture list ──────────────────────────────────────────
        if (state.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = colors.text, strokeWidth = 2.dp,
                    modifier = Modifier.size(28.dp))
            }
        } else if (state.filtered.isEmpty()) {
            EmptyState(
                title    = if (state.lectures.isEmpty()) "No lectures yet" else "No results",
                subtitle = if (state.lectures.isEmpty())
                    "Add your first lecture or import from PDF / text."
                else "Try adjusting the filters or search query.",
                icon     = Icons.Outlined.School,
                cta      = if (state.lectures.isEmpty()) "Add Lecture" else null,
                onCta    = if (state.lectures.isEmpty()) {{ showAdd = true }} else null,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 80.dp),
                modifier       = Modifier.fillMaxSize(),
            ) {
                itemsIndexed(state.filtered) { idx, lec ->
                    val subject = state.subjects.find { it.id == lec.subjectId }
                    LectureRow(
                        lecture   = lec,
                        subject   = subject,
                        selected  = lec.id in state.selected,
                        onToggleSel = { vm.toggleSelect(lec.id) },
                        onAction  = { actionLecture = lec },
                        onEdit    = { editLecture = lec },
                    )
                    if (idx < state.filtered.lastIndex) {
                        HorizontalDivider(
                            color     = colors.border,
                            thickness = 1.dp,
                            modifier  = Modifier.padding(horizontal = 16.dp),
                        )
                    }
                }
            }
        }
    }

    // ── Dialogs ───────────────────────────────────────────────────
    if (showAdd) {
        AddLectureDialog(
            subjects  = state.subjects,
            onDismiss = { showAdd = false },
            onSave    = { sid, num, name, dur, ch, tags ->
                vm.addLecture(sid, num, name, dur, ch, tags)
                showAdd = false
            },
        )
    }

    editLecture?.let { lec ->
        EditLectureDialog(
            lecture   = lec,
            onDismiss = { editLecture = null },
            onSave    = { name, dur, rem, ch, tags, status, diff ->
                vm.editLecture(lec, name, dur, rem, ch, tags, status, diff)
                editLecture = null
            },
        )
    }

    deleteLecture?.let { lec ->
        ConfirmDialog(
            visible     = true,
            title       = "Delete Lecture",
            message     = "Delete \"${lec.name}\"? This also removes all associated notes.",
            confirmText = "Delete",
            destructive = true,
            onConfirm   = { vm.deleteLecture(lec.id) },
            onDismiss   = { deleteLecture = null },
        )
    }

    actionLecture?.let { lec ->
        LectureActionSheet(
            lecture    = lec,
            onDismiss  = { actionLecture = null },
            onEdit     = { actionLecture = null; editLecture = lec },
            onDelete   = { actionLecture = null; deleteLecture = lec },
            onQuickLog = { secs -> vm.quickLog(lec.id, secs); actionLecture = null },
            onSetDiff  = { diff -> vm.setDifficulty(lec.id, diff); actionLecture = null },
        )
    }

    if (showImport) {
        ImportLecturesDialog(
            subjects  = state.subjects,
            onParse   = { text -> vm.parseText(text) },
            onImport  = { subId, parsed ->
                vm.importLectures(subId, parsed)
                showImport = false
            },
            onDismiss = { showImport = false },
        )
    }
}

// ── Filter Bar ────────────────────────────────────────────────────
@Composable
private fun FilterBar(state: LecturesUiState, vm: LecturesViewModel) {
    val colors = MaterialTheme.studyColors
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        // Search
        StudyTextField(
            value         = state.filter.query,
            onValueChange = { vm.setFilter(state.filter.copy(query = it)) },
            placeholder   = "Search lectures…",
            modifier      = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        // Filter chips row
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.horizontalScroll(rememberScrollState()),
        ) {
            // Subject filter
            val subjectOptions = listOf(DropdownOption<String?>(null, "All subjects")) +
                state.subjects.map { DropdownOption(it.id, it.name) }
            StudyDropdown(
                options  = subjectOptions,
                selected = state.filter.subjectId,
                onSelect = { vm.setFilter(state.filter.copy(subjectId = it)) },
                modifier = Modifier.widthIn(min = 100.dp, max = 160.dp),
            )
            // Status filter
            val statusOptions = listOf(DropdownOption<LectureStatus?>(null, "All")) +
                LectureStatus.entries.map { DropdownOption(it, it.value.replaceFirstChar { c -> c.uppercase() }) }
            StudyDropdown(
                options  = statusOptions,
                selected = state.filter.status,
                onSelect = { vm.setFilter(state.filter.copy(status = it)) },
                modifier = Modifier.widthIn(min = 80.dp, max = 120.dp),
            )
            // Sort
            val sortOptions = LectureSort.entries.map { DropdownOption(it, it.name.lowercase().replaceFirstChar { c -> c.uppercase() }) }
            StudyDropdown(
                options  = sortOptions,
                selected = state.sort,
                onSelect = { vm.setSort(it) },
                modifier = Modifier.widthIn(min = 80.dp, max = 120.dp),
            )
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ── Bulk Selection Bar ────────────────────────────────────────────
@Composable
private fun BulkSelectionBar(
    selectedCount: Int,
    onMarkDone:    () -> Unit,
    onDelete:      () -> Unit,
    onClear:       () -> Unit,
) {
    val colors = MaterialTheme.studyColors
    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
            .background(colors.primaryX)
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Text("$selectedCount selected", fontFamily = BodyFontFamily,
            fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = colors.text)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            XsButton("Mark Done", onClick = onMarkDone, variant = ButtonVariant.PRIMARY)
            XsButton("Delete", onClick = onDelete, variant = ButtonVariant.DANGER)
            XsButton("Clear", onClick = onClear, variant = ButtonVariant.OUTLINE)
        }
    }
}

// ── Lecture Row ───────────────────────────────────────────────────
@Composable
private fun LectureRow(
    lecture:     Lecture,
    subject:     Subject?,
    selected:    Boolean,
    onToggleSel: () -> Unit,
    onAction:    () -> Unit,
    onEdit:      () -> Unit,
) {
    val colors  = MaterialTheme.studyColors
    val isDone  = lecture.status == LectureStatus.COMPLETE
    val bgColor = if (selected) colors.primaryX else Color.Transparent

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .background(bgColor)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .combinedClickable(
                onClick      = { if (selected) onToggleSel() else onAction() },
                onLongClick  = { onToggleSel() },
            ),
    ) {
        // Checkbox (bulk select)
        Checkbox(
            checked         = selected,
            onCheckedChange = { onToggleSel() },
            colors          = CheckboxDefaults.colors(
                checkedColor   = colors.primary,
                uncheckedColor = colors.border,
            ),
            modifier = Modifier.size(20.dp),
        )
        Spacer(Modifier.width(10.dp))

        // Subject color dot
        subject?.let { SubjectColorDot(it.color, size = 7.dp) }
        Spacer(Modifier.width(8.dp))

        // Number
        Text(
            text       = lecture.lectureNum,
            fontFamily = MonoFontFamily,
            fontSize   = 11.sp,
            color      = colors.text3,
            modifier   = Modifier.width(28.dp),
        )

        // Name + chapter
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text       = lecture.name,
                fontFamily = BodyFontFamily,
                fontWeight = FontWeight.Medium,
                fontSize   = 13.sp,
                color      = if (isDone) colors.text3 else colors.text,
                textDecoration = if (isDone) TextDecoration.LineThrough else null,
                maxLines   = 1,
                overflow   = TextOverflow.Ellipsis,
            )
            if (lecture.chapter.isNotEmpty()) {
                Text(lecture.chapter, fontFamily = BodyFontFamily, fontSize = 11.sp,
                    color = colors.text3, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            // Tags
            if (lecture.tags.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(top = 3.dp)) {
                    lecture.tags.take(3).forEach { tag ->
                        Badge(tag.value.uppercase(), BadgeType.NEUTRAL)
                    }
                }
            }
        }
        Spacer(Modifier.width(8.dp))

        // Duration / remaining
        Column(horizontalAlignment = Alignment.End) {
            Text(TimeUtils.toHMS(lecture.duration), fontFamily = MonoFontFamily,
                fontSize = 11.sp, color = colors.text3)
            val statusBadge = when (lecture.status) {
                LectureStatus.COMPLETE -> BadgeType.GREEN
                LectureStatus.PARTIAL  -> BadgeType.YELLOW
                LectureStatus.PENDING  -> BadgeType.NEUTRAL
            }
            Badge(lecture.status.value, statusBadge)
        }

        Spacer(Modifier.width(8.dp))
        // More actions button
        IconButton(onClick = onAction, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Outlined.MoreVert, "Actions", tint = colors.text3,
                modifier = Modifier.size(16.dp))
        }
    }
}

// ── Add Lecture Dialog ────────────────────────────────────────────
@Composable
private fun AddLectureDialog(
    subjects:  List<Subject>,
    onDismiss: () -> Unit,
    onSave:    (subjectId: String, num: String, name: String, dur: String,
                chapter: String, tags: List<LectureTag>) -> Unit,
) {
    if (subjects.isEmpty()) {
        ConfirmDialog(
            visible = true, title = "No Subjects",
            message = "Please add a subject first before adding lectures.",
            confirmText = "OK", onConfirm = onDismiss, onDismiss = onDismiss,
        )
        return
    }
    var subjectId by remember { mutableStateOf(subjects.first().id) }
    var num       by remember { mutableStateOf("") }
    var name      by remember { mutableStateOf("") }
    var dur       by remember { mutableStateOf("") }
    var chapter   by remember { mutableStateOf("") }
    var tags      by remember { mutableStateOf(emptySet<LectureTag>()) }
    val toast     = LocalToastHost.current

    StudyPlanDialog(
        visible   = true,
        title     = "Add Lecture",
        onDismiss = onDismiss,
        footer    = {
            OutlineButton("Cancel", onClick = onDismiss)
            Spacer(Modifier.width(8.dp))
            PrimaryButton("Add") {
                if (name.isBlank()) { toast.show("Name required", true); return@PrimaryButton }
                if (TimeUtils.toSeconds(dur) <= 0) { toast.show("Enter duration like 01:30:00", true); return@PrimaryButton }
                onSave(subjectId, num, name, dur, chapter, tags.toList())
            }
        },
    ) {
        StudyDropdown(
            options  = subjects.map { DropdownOption(it.id, "${it.name} — ${it.fullName}") },
            selected = subjectId,
            onSelect = { subjectId = it },
            label    = "Subject",
        )
        Spacer(Modifier.height(12.dp))
        FieldLabel("Lecture Number")
        StudyTextField(value = num, onValueChange = { num = it }, placeholder = "e.g. 61")
        Spacer(Modifier.height(12.dp))
        FieldLabel("Name")
        StudyTextField(value = name, onValueChange = { name = it },
            placeholder = "Lecture name")
        Spacer(Modifier.height(12.dp))
        DurationField(value = dur, onValueChange = { dur = it })
        Spacer(Modifier.height(12.dp))
        FieldLabel("Chapter / Topic (optional)")
        StudyTextField(value = chapter, onValueChange = { chapter = it },
            placeholder = "e.g. Financial Instruments")
        Spacer(Modifier.height(12.dp))
        FieldLabel("Tags")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            LectureTag.entries.forEach { tag ->
                TagToggleButton(
                    label    = tag.label,
                    selected = tag in tags,
                    onClick  = { tags = if (tag in tags) tags - tag else tags + tag },
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

// ── Edit Lecture Dialog ───────────────────────────────────────────
@Composable
private fun EditLectureDialog(
    lecture:   Lecture,
    onDismiss: () -> Unit,
    onSave:    (name: String, dur: String, rem: String, chapter: String,
                tags: List<LectureTag>, status: LectureStatus,
                difficulty: LectureDifficulty) -> Unit,
) {
    var name    by remember { mutableStateOf(lecture.name) }
    var dur     by remember { mutableStateOf(TimeUtils.toHMS(lecture.duration)) }
    var rem     by remember { mutableStateOf(TimeUtils.toHMS(lecture.remaining)) }
    var chapter by remember { mutableStateOf(lecture.chapter) }
    var tags    by remember { mutableStateOf(lecture.tags.toSet()) }
    var status  by remember { mutableStateOf(lecture.status) }
    var diff    by remember { mutableStateOf(lecture.difficulty) }
    val toast   = LocalToastHost.current

    StudyPlanDialog(
        visible   = true,
        title     = "Edit Lecture",
        onDismiss = onDismiss,
        footer    = {
            OutlineButton("Cancel", onClick = onDismiss)
            Spacer(Modifier.width(8.dp))
            PrimaryButton("Save") {
                if (name.isBlank()) { toast.show("Name required", true); return@PrimaryButton }
                if (TimeUtils.toSeconds(dur) <= 0) { toast.show("Invalid duration", true); return@PrimaryButton }
                onSave(name, dur, rem, chapter, tags.toList(), status, diff)
            }
        },
    ) {
        FieldLabel("Name")
        StudyTextField(value = name, onValueChange = { name = it })
        Spacer(Modifier.height(12.dp))
        DurationField(value = dur, onValueChange = { dur = it }, label = "Duration (hh:mm:ss)")
        Spacer(Modifier.height(12.dp))
        DurationField(value = rem, onValueChange = { rem = it }, label = "Remaining (hh:mm:ss)")
        FieldHint("Set remaining = duration to reset, or 0 to mark complete.")
        Spacer(Modifier.height(12.dp))
        FieldLabel("Chapter / Topic")
        StudyTextField(value = chapter, onValueChange = { chapter = it }, placeholder = "Optional")
        Spacer(Modifier.height(12.dp))
        FieldLabel("Tags")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            LectureTag.entries.forEach { tag ->
                TagToggleButton(tag.label, tag in tags, { tags = if (tag in tags) tags - tag else tags + tag },
                    modifier = Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(12.dp))
        StudyDropdown(
            options  = LectureStatus.entries.map { DropdownOption(it, it.value.replaceFirstChar { c -> c.uppercase() }) },
            selected = status, onSelect = { status = it }, label = "Status",
        )
        Spacer(Modifier.height(12.dp))
        StudyDropdown(
            options  = LectureDifficulty.entries.map { DropdownOption(it, it.value.replaceFirstChar { c -> c.uppercase() }) },
            selected = diff, onSelect = { diff = it }, label = "Difficulty",
        )
    }
}

// ── Lecture Action Bottom Sheet ───────────────────────────────────
@Composable
private fun LectureActionSheet(
    lecture:   Lecture,
    onDismiss: () -> Unit,
    onEdit:    () -> Unit,
    onDelete:  () -> Unit,
    onQuickLog: (Long) -> Unit,
    onSetDiff:  (LectureDifficulty) -> Unit,
) {
    StudyPlanDialog(
        visible   = true,
        title     = lecture.name,
        onDismiss = onDismiss,
        footer    = { OutlineButton("Close", onClick = onDismiss) },
    ) {
        val colors = MaterialTheme.studyColors
        val isDone = lecture.status == LectureStatus.COMPLETE

        // Quick log row
        if (!isDone) {
            SectionTitle("Quick Log")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(900L to "+15m", 1800L to "+30m", 3600L to "+1h").forEach { (secs, lbl) ->
                    OutlineButton(lbl, onClick = { onQuickLog(secs) }, modifier = Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(14.dp))
        }

        // Difficulty
        SectionTitle("Difficulty")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LectureDifficulty.entries.forEach { diff ->
                val selected = diff == lecture.difficulty
                TagToggleButton(
                    label    = diff.value.replaceFirstChar { it.uppercase() },
                    selected = selected,
                    onClick  = { onSetDiff(diff) },
                    modifier = Modifier.weight(1f),
                )
            }
        }
        Spacer(Modifier.height(14.dp))

        // Edit / Delete
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlineButton("Edit", onClick = onEdit, modifier = Modifier.weight(1f),
                icon = { Icon(Icons.Outlined.Edit, null, modifier = Modifier.size(13.dp),
                    tint = MaterialTheme.studyColors.text) })
            DangerButton("Delete", onClick = onDelete, modifier = Modifier.weight(1f))
        }
    }
}

// ── Import Lectures Dialog ────────────────────────────────────────
@Composable
private fun ImportLecturesDialog(
    subjects:  List<Subject>,
    onParse:   (String) -> List<ParsedLecture>,
    onImport:  (String, List<ParsedLecture>) -> Unit,
    onDismiss: () -> Unit,
) {
    if (subjects.isEmpty()) {
        ConfirmDialog(visible = true, title = "No Subjects",
            message = "Add a subject first.", confirmText = "OK",
            onConfirm = onDismiss, onDismiss = onDismiss)
        return
    }

    var subjectId     by remember { mutableStateOf(subjects.first().id) }
    var pasteText     by remember { mutableStateOf("") }
    var parsed        by remember { mutableStateOf<List<ParsedLecture>>(emptyList()) }
    var selectedSet   by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var parseError    by remember { mutableStateOf("") }
    val toast         = LocalToastHost.current

    fun doParse() {
        val result = onParse(pasteText)
        parsed = result
        selectedSet = result.indices.toSet()
        parseError = if (result.isEmpty()) "No lectures detected. Format: \"01 Name 01:30:00\"" else ""
    }

    StudyPlanDialog(
        visible   = true,
        title     = "Import Lectures",
        onDismiss = onDismiss,
        wide      = true,
        footer    = {
            OutlineButton("Cancel", onClick = onDismiss)
            Spacer(Modifier.width(8.dp))
            PrimaryButton(
                text    = if (parsed.isEmpty()) "Import" else "Import ${selectedSet.size} Selected",
                enabled = parsed.isNotEmpty() && selectedSet.isNotEmpty(),
                onClick = {
                    val toImport = parsed.filterIndexed { i, _ -> i in selectedSet }
                    if (toImport.isEmpty()) { toast.show("Select at least one lecture", true); return@PrimaryButton }
                    onImport(subjectId, toImport)
                },
            )
        },
    ) {
        StudyDropdown(
            options  = subjects.map { DropdownOption(it.id, "${it.name} — ${it.fullName}") },
            selected = subjectId,
            onSelect = { subjectId = it },
            label    = "Assign to Subject",
        )
        Spacer(Modifier.height(14.dp))
        FieldLabel("Paste lecture list (one per line)")
        FieldHint("Format: 01 Lecture Name 01:30:00")
        Spacer(Modifier.height(4.dp))
        StudyTextArea(
            value         = pasteText,
            onValueChange = { pasteText = it },
            placeholder   = "01 Introduction to Accounting 01:30:00\n02 Revenue Recognition 02:00:00\n…",
            minLines      = 5,
        )
        Spacer(Modifier.height(8.dp))
        OutlineButton("Parse →", onClick = ::doParse)

        if (parseError.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            AlertBanner(AlertType.ERROR, parseError)
        }

        if (parsed.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically,
                modifier              = Modifier.fillMaxWidth(),
            ) {
                Text("${parsed.size} lectures detected", fontFamily = BodyFontFamily,
                    fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                    color = MaterialTheme.studyColors.green)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    XsButton("All",   onClick = { selectedSet = parsed.indices.toSet() })
                    XsButton("None",  onClick = { selectedSet = emptySet() })
                }
            }
            Spacer(Modifier.height(8.dp))
            parsed.forEachIndexed { idx, lec ->
                val isSelected = idx in selectedSet
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSelected) MaterialTheme.studyColors.primaryX else Color.Transparent)
                        .clickable(indication = null,
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            onClick = { selectedSet = if (isSelected) selectedSet - idx else selectedSet + idx })
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                ) {
                    Checkbox(checked = isSelected, onCheckedChange = { checked ->
                        selectedSet = if (checked) selectedSet + idx else selectedSet - idx },
                        modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(lec.num.ifBlank { "${idx+1}" }, fontFamily = MonoFontFamily,
                        fontSize = 11.sp, color = MaterialTheme.studyColors.text3,
                        modifier = Modifier.width(28.dp))
                    Text(lec.name, fontFamily = BodyFontFamily, fontSize = 12.sp,
                        color = MaterialTheme.studyColors.text, modifier = Modifier.weight(1f),
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.width(8.dp))
                    Text(lec.durStr, fontFamily = MonoFontFamily, fontSize = 11.sp,
                        color = MaterialTheme.studyColors.text3)
                }
                HorizontalDivider(color = MaterialTheme.studyColors.border.copy(.5f), thickness = 0.5.dp)
            }
        }
    }
}
