package com.studyplan.app.domain.model

/** Mirrors HTML note types: "note" | "doubt" | "key" */
enum class NoteType(val value: String) {
    NOTE("note"),
    DOUBT("doubt"),
    KEY("key");
    companion object {
        fun from(value: String) = entries.firstOrNull { it.value == value } ?: NOTE
    }
}
