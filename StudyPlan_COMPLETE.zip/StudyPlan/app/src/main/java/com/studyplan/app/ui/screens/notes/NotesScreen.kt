@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.notes

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studyplan.app.domain.engine.TimeUtils
import com.studyplan.app.domain.model.Lecture
import com.studyplan.app.domain.model.NoteType
import com.studyplan.app.domain.model.Subject
import com.studyplan.app.ui.animation.*
import com.studyplan.app.ui.components.*
import com.studyplan.app.ui.components.dialog.*
import com.studyplan.app.ui.theme.*

@Composable
fun NotesScreen(vm: NotesViewModel = hiltViewModel()) {
    val state  by vm.state.collectAsStateWithLifecycle()
    val colors  = MaterialTheme.studyColors
    val toast   = LocalToastHost.current

    LaunchedEffect(Unit) { vm.toast.collect { toast.show(it) } }

    var showAddDialog  by remember { mutableStateOf(false) }
    var preselectedLec by remember { mutableStateOf<String?>(null) }
    var confirmDelete  by remember { mutableStateOf<NoteItem?>(null) }

    Column(modifier = Modifier.fillMaxSize().background(colors.bg)) {

        PageHeader(
            title    = "Notes & Doubts",
            subtitle = "${state.filtered.size} note${if (state.filtered.size != 1) "s" else ""}",
        )

        // ── Filter bar ────────────────────────────────────────────
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
        ) {
            // Subject filter
            val subjectOptions = listOf(DropdownOption<String?>(null, "All subjects")) +
                state.subjects.map { DropdownOption(it.id, it.name) }
            StudyDropdown(
                options  = subjectOptions,
                selected = state.filterSubId,
                onSelect = { vm.setFilterSubject(it) },
                modifier = Modifier.widthIn(min = 110.dp, max = 170.dp),
            )
            // Type filter
            val typeOptions = listOf(DropdownOption<NoteType?>(null, "All types")) +
                listOf(
                    DropdownOption(NoteType.NOTE,  "📝 Notes"),
                    DropdownOption(NoteType.DOUBT, "❓ Doubts"),
                    DropdownOption(NoteType.KEY,   "⭐ Key Points"),
                )
            StudyDropdown(
                options  = typeOptions,
                selected = state.filterType,
                onSelect = { vm.setFilterType(it) },
                modifier = Modifier.widthIn(min = 110.dp, max = 150.dp),
            )
        }
        Spacer(Modifier.height(8.dp))

        // ── Content ───────────────────────────────────────────────
        Box(modifier = Modifier.weight(1f)) {
            when {
                state.isLoading -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    CircularProgressIndicator(color = colors.text, strokeWidth = 2.dp,
                        modifier = Modifier.size(28.dp))
                }
                state.filtered.isEmpty() -> EmptyState(
                    title    = if (state.allItems.isEmpty()) "No notes yet"
                               else "No results",
                    subtitle = if (state.allItems.isEmpty())
                        "Add notes, doubts, or key points to your lectures."
                    else "Try changing the filters.",
                    icon     = Icons.Outlined.Description,
                    cta      = if (state.allItems.isEmpty()) "Add Note" else null,
                    onCta    = if (state.allItems.isEmpty()) {{ showAddDialog = true }} else null,
                    modifier = Modifier.fillMaxSize(),
                )
                else -> LazyColumn(
                    contentPadding = PaddingValues(
                        start = 16.dp, end = 16.dp, top = 4.dp, bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    itemsIndexed(state.filtered) { idx, item ->
                        AnimatedVisibility(
                            visible = true,
                            enter   = cardUpEnter(CARD_STAGGER_DELAYS.getOrElse(idx) { idx * 40 }),
                        ) {
                            NoteCard(
                                item           = item,
                                onToggleResolved = {
                                    vm.toggleResolved(item.note.id, item.note.lectureId,
                                        item.note.resolved)
                                },
                                onDelete       = { confirmDelete = item },
                            )
                        }
                    }
                }
            }
        }

        // ── FAB ───────────────────────────────────────────────────
        Box(modifier = Modifier.fillMaxWidth()) {
            FloatingActionButton(
                onClick        = { showAddDialog = true },
                containerColor = colors.primary,
                contentColor   = colors.onPrimary,
                modifier       = Modifier.align(Alignment.BottomEnd).padding(20.dp),
            ) {
                Icon(Icons.Outlined.Add, "Add Note")
            }
        }
    }

    // ── Add Note Dialog ───────────────────────────────────────────
    if (showAddDialog) {
        AddNoteDialog(
            lectures       = state.lectures,
            subjects       = state.subjects,
            preselectedLec = preselectedLec,
            onDismiss      = { showAddDialog = false; preselectedLec = null },
            onSave         = { lecId, text, type ->
                vm.addNote(lecId, text, type)
                showAddDialog = false
                preselectedLec = null
            },
        )
    }

    // ── Delete Confirm ────────────────────────────────────────────
    confirmDelete?.let { item ->
        ConfirmDialog(
            visible     = true,
            title       = "Delete Note",
            message     = "Delete this ${item.note.type.value}? This cannot be undone.",
            confirmText = "Delete",
            destructive = true,
            onConfirm   = { vm.deleteNote(item.note.id) },
            onDismiss   = { confirmDelete = null },
        )
    }
}

// ── Note Card ─────────────────────────────────────────────────────
@Composable
private fun NoteCard(
    item:             NoteItem,
    onToggleResolved: () -> Unit,
    onDelete:         () -> Unit,
) {
    val colors   = MaterialTheme.studyColors
    val note     = item.note
    val isResolved = note.type == NoteType.DOUBT && note.resolved

    // Type-specific styling
    val (typeBg, typeFg, typeLabel) = when (note.type) {
        NoteType.NOTE  -> Triple(colors.surface2,  colors.text2,  "📝 Note")
        NoteType.DOUBT -> Triple(colors.yellowX,   colors.yellow, "❓ Doubt")
        NoteType.KEY   -> Triple(colors.blueX,     colors.blue,   "⭐ Key Point")
    }

    val cardBg = if (isResolved) colors.cardDoneBg else colors.surface
    val borderColor = if (isResolved) colors.green.copy(.2f) else colors.border

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(cardBg)
            .border(1.dp, borderColor, RoundedCornerShape(10.dp))
            .padding(14.dp),
    ) {
        // Header row
        Row(
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier              = Modifier.fillMaxWidth(),
        ) {
            // Type badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(typeBg)
                    .padding(horizontal = 7.dp, vertical = 2.dp),
            ) {
                Text(typeLabel, fontFamily = BodyFontFamily, fontWeight = FontWeight.Bold,
                    fontSize = 10.sp, color = typeFg)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Resolved toggle (doubts only)
                if (note.type == NoteType.DOUBT) {
                    val resolvedBg by animateColorAsState(
                        if (isResolved) colors.green else colors.surface2, label = "resolved")
                    val resolvedFg = if (isResolved) Color.White else colors.text3
                    SmButton(
                        text    = if (isResolved) "✓ Resolved" else "Resolve",
                        variant = if (isResolved) ButtonVariant.PRIMARY else ButtonVariant.OUTLINE,
                        onClick = onToggleResolved,
                    )
                    Spacer(Modifier.width(6.dp))
                }
                // Delete
                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Outlined.Delete, "Delete note", tint = colors.text3,
                        modifier = Modifier.size(14.dp))
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // Lecture + subject row
        Row(verticalAlignment = Alignment.CenterVertically) {
            SubjectColorDot(item.subject.color, size = 7.dp)
            Spacer(Modifier.width(6.dp))
            Text(
                text       = "[${item.subject.name}] ${item.lecture.name}",
                fontFamily = BodyFontFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize   = 12.sp,
                color      = colors.text2,
                maxLines   = 1,
                overflow   = TextOverflow.Ellipsis,
            )
        }

        Spacer(Modifier.height(8.dp))

        // Note content — rendered from HTML
        val annotated = remember(note.text) { htmlToAnnotatedString(note.text) }
        Text(
            text       = annotated,
            fontFamily = BodyFontFamily,
            fontSize   = 13.sp,
            color      = if (isResolved) colors.text3 else colors.text,
            lineHeight = 20.sp,
            textDecoration = if (isResolved) TextDecoration.LineThrough else null,
        )

        Spacer(Modifier.height(6.dp))

        // Date
        Text(
            text       = TimeUtils.formatDisplay(note.createdAt),
            fontFamily = MonoFontFamily,
            fontSize   = 10.sp,
            color      = colors.text3,
        )
    }
}

// ── Add Note Dialog ───────────────────────────────────────────────
@Composable
private fun AddNoteDialog(
    lectures:       List<Lecture>,
    subjects:       List<Subject>,
    preselectedLec: String?,
    onDismiss:      () -> Unit,
    onSave:         (lectureId: String, text: String, type: NoteType) -> Unit,
) {
    if (lectures.isEmpty()) {
        ConfirmDialog(visible = true, title = "No Lectures",
            message = "Add lectures first before adding notes.",
            confirmText = "OK", onConfirm = onDismiss, onDismiss = onDismiss)
        return
    }

    val initialLecId = preselectedLec ?: lectures.first().id
    var lectureId by remember { mutableStateOf(initialLecId) }
    var text      by remember { mutableStateOf("") }
    var noteType  by remember { mutableStateOf(NoteType.NOTE) }
    val toast     = LocalToastHost.current

    // Build lecture options with subject label prefix
    val subMap = subjects.associateBy { it.id }
    val lecOptions = lectures.map { lec ->
        DropdownOption(lec.id, "[${subMap[lec.subjectId]?.name ?: "?"}] ${lec.name}")
    }

    StudyPlanDialog(
        visible   = true,
        title     = "Add Note",
        onDismiss = onDismiss,
        footer    = {
            OutlineButton("Cancel", onClick = onDismiss)
            Spacer(Modifier.width(8.dp))
            PrimaryButton("Save Note") {
                if (text.isBlank()) { toast.show("Note cannot be empty", true); return@PrimaryButton }
                onSave(lectureId, text, noteType)
            }
        },
    ) {
        // Lecture selector
        StudyDropdown(
            options  = lecOptions,
            selected = lectureId,
            onSelect = { lectureId = it },
            label    = "Lecture",
        )
        Spacer(Modifier.height(12.dp))

        // Note type
        FieldLabel("Type")
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier              = Modifier.fillMaxWidth(),
        ) {
            listOf(
                NoteType.NOTE  to "📝 Note",
                NoteType.DOUBT to "❓ Doubt",
                NoteType.KEY   to "⭐ Key Point",
            ).forEach { (type, label) ->
                TagToggleButton(
                    label    = label,
                    selected = noteType == type,
                    onClick  = { noteType = type },
                    modifier = Modifier.weight(1f),
                )
            }
        }
        Spacer(Modifier.height(12.dp))

        // Content
        FieldLabel("Content")
        StudyTextArea(
            value         = text,
            onValueChange = { text = it },
            placeholder   = "Write your note, doubt or key point here…",
            minLines      = 5,
        )
    }
}
