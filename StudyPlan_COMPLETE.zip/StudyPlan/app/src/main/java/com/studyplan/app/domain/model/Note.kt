package com.studyplan.app.domain.model

/**
 * A note, doubt, or key point attached to a lecture.
 * text may contain simple HTML tags (b, i, u, ul, ol, blockquote)
 * from the rich editor — rendered via AnnotatedString in Compose.
 */
data class Note(
    val id:         String,
    val lectureId:  String,
    val text:       String,   // may contain HTML markup from rich editor
    val type:       NoteType,
    val createdAt:  String,   // YYYY-MM-DD
    val resolved:   Boolean,  // for doubts
)
