@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.calendar

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studyplan.app.domain.engine.*
import com.studyplan.app.domain.model.*
import com.studyplan.app.domain.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.YearMonth
import javax.inject.Inject

data class CalendarDayInfo(
    val date:       String,
    val entries:    List<ScheduleEntry>,
    val lectures:   List<Lecture>,
    val subjects:   List<Subject>,
    val isToday:    Boolean,
    val isRestDay:  Boolean,
    val isVacation: Boolean,
    val studied:    Boolean,
    val missed:     Boolean,
    val totalH:     Long,
)

data class CalendarUiState(
    val isLoading:    Boolean             = true,
    val year:         Int                 = java.time.LocalDate.now().year,
    val month:        Int                 = java.time.LocalDate.now().monthValue,
    val days:         Map<String, CalendarDayInfo> = emptyMap(),
    val vacationDates: List<String>       = emptyList(),
    val settings:     AppSettings?        = null,
    val subjects:     List<Subject>       = emptyList(),
    val lectures:     List<Lecture>       = emptyList(),
    val selectedDay:  CalendarDayInfo?    = null,
)

@HiltViewModel
class CalendarViewModel @Inject constructor(
    private val scheduleRepo:    ScheduleRepository,
    private val settingsRepo:    SettingsRepository,
    private val lectureRepo:     LectureRepository,
    private val subjectRepo:     SubjectRepository,
    private val schedulerEngine: SchedulerEngine,
) : ViewModel() {

    private val _state = MutableStateFlow(CalendarUiState())
    val state: StateFlow<CalendarUiState> = _state.asStateFlow()

    private val _toast = MutableSharedFlow<String>()
    val toast: SharedFlow<String> = _toast.asSharedFlow()

    init { load() }

    fun load(
        year:  Int = _state.value.year,
        month: Int = _state.value.month,
    ) {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            val settings  = settingsRepo.get()
            val subjects  = subjectRepo.getAll()
            val lectures  = lectureRepo.getAll()
            val today     = TimeUtils.today()
            val vacations = settings?.vacationDates ?: emptyList()
            val bufDay    = settings?.bufferDayOfWeek ?: -1

            // Fetch all entries for this month
            val ym      = YearMonth.of(year, month)
            val firstDay = "%04d-%02d-01".format(year, month)
            val lastDay  = "%04d-%02d-%02d".format(year, month, ym.lengthOfMonth())
            val entries  = scheduleRepo.getInRange(firstDay, lastDay)
                .groupBy { it.date }
            val lecMap   = lectures.associateBy { it.id }
            val subMap   = subjects.associateBy { it.id }

            // Build day info map
            val days = mutableMapOf<String, CalendarDayInfo>()
            for (d in 1..ym.lengthOfMonth()) {
                val dateStr    = "%04d-%02d-%02d".format(year, month, d)
                val dayEntries = entries[dateStr] ?: emptyList()
                val isRest     = bufDay != -1 && TimeUtils.dayOfWeek(dateStr) == bufDay
                val isVac      = vacations.contains(dateStr)
                val studied    = dayEntries.any {
                    it.status == ScheduleEntryStatus.DONE ||
                    it.status == ScheduleEntryStatus.PARTIAL_DONE
                }
                val missed     = !isRest && !isVac && dateStr < today &&
                    dayEntries.any { it.status == ScheduleEntryStatus.SCHEDULED }
                val totalH     = dayEntries.sumOf { it.completedSeconds }
                val dayLecs    = dayEntries.mapNotNull { lecMap[it.lectureId] }
                val daySubs    = dayEntries.mapNotNull { subMap[it.subjectId] }.distinctBy { it.id }

                days[dateStr] = CalendarDayInfo(
                    date       = dateStr,
                    entries    = dayEntries,
                    lectures   = dayLecs,
                    subjects   = daySubs,
                    isToday    = dateStr == today,
                    isRestDay  = isRest,
                    isVacation = isVac,
                    studied    = studied,
                    missed     = missed,
                    totalH     = totalH,
                )
            }

            _state.update {
                it.copy(
                    isLoading    = false,
                    year         = year,
                    month        = month,
                    days         = days,
                    vacationDates = vacations,
                    settings     = settings,
                    subjects     = subjects,
                    lectures     = lectures,
                )
            }
        }
    }

    fun navigate(delta: Int) {
        val cur = _state.value
        var y   = cur.year
        var m   = cur.month + delta
        if (m > 12) { m = 1;  y++ }
        if (m < 1)  { m = 12; y-- }
        load(y, m)
    }

    fun goToToday() {
        val now = java.time.LocalDate.now()
        load(now.year, now.monthValue)
    }

    fun selectDay(day: CalendarDayInfo?) {
        _state.update { it.copy(selectedDay = day) }
    }

    fun addVacationDate(dateStr: String) {
        viewModelScope.launch {
            val settings = settingsRepo.get() ?: return@launch
            if (settings.vacationDates.contains(dateStr)) {
                _toast.emit("Already added"); return@launch
            }
            val updated = settings.copy(
                vacationDates = (settings.vacationDates + dateStr).sorted()
            )
            settingsRepo.upsert(updated)
            schedulerEngine.buildSchedule(dateStr == TimeUtils.today())
            _toast.emit("Vacation day added — lectures rescheduled")
            load()
        }
    }

    fun removeVacationDate(dateStr: String) {
        viewModelScope.launch {
            val settings = settingsRepo.get() ?: return@launch
            settingsRepo.upsert(settings.copy(
                vacationDates = settings.vacationDates.filter { it != dateStr }
            ))
            schedulerEngine.buildSchedule(dateStr == TimeUtils.today())
            _toast.emit("Vacation day removed")
            load()
        }
    }
}
