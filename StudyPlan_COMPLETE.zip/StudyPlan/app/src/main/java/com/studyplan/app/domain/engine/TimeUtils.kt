package com.studyplan.app.domain.engine

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

/**
 * Port of the HTML Time utility object.
 *
 * CRITICAL: All operations use LOCAL date (device timezone), never UTC.
 * The HTML comment explicitly notes this is critical for India UTC+5:30.
 * java.time.LocalDate is always local-zone by definition — no ZoneId needed.
 */
object TimeUtils {

    private val ISO_FMT = DateTimeFormatter.ISO_LOCAL_DATE  // YYYY-MM-DD

    // ── Parse / format ────────────────────────────────────────────

    fun parse(dateStr: String): LocalDate = LocalDate.parse(dateStr, ISO_FMT)

    fun format(date: LocalDate): String = date.format(ISO_FMT)

    /** "01 Jun 2024" — matches HTML Time.formatDate() */
    fun formatDisplay(dateStr: String): String {
        if (dateStr.isBlank()) return "—"
        return runCatching {
            val d = parse(dateStr)
            val month = d.month.getDisplayName(TextStyle.SHORT, Locale.ENGLISH)
            "%02d %s %d".format(d.dayOfMonth, month, d.year)
        }.getOrDefault("—")
    }

    /** Today's date in YYYY-MM-DD (local timezone) */
    fun today(): String = format(LocalDate.now())

    /** @return YYYY-MM-DD date string n days from the given date */
    fun addDays(dateStr: String, days: Long): String =
        format(parse(dateStr).plusDays(days))

    fun addDays(date: LocalDate, days: Long): String =
        format(date.plusDays(days))

    /**
     * Positive = b is after a, negative = b is before a.
     * Mirrors HTML: Math.round((new Date(b) - new Date(a)) / 86400000)
     */
    fun diffDays(a: String, b: String): Long =
        parse(a).until(parse(b), java.time.temporal.ChronoUnit.DAYS)

    /**
     * 0 = Sunday … 6 = Saturday  (matches JS getDay())
     */
    fun dayOfWeek(dateStr: String): Int {
        val dow = parse(dateStr).dayOfWeek  // java.time: MONDAY=1 … SUNDAY=7
        return dow.value % 7                // remap: Sun=0, Mon=1 … Sat=6
    }

    /** Short day name: "Mon", "Tue" … "Sun" */
    fun dayName(dateStr: String): String {
        val names = arrayOf("Sun","Mon","Tue","Wed","Thu","Fri","Sat")
        return names[dayOfWeek(dateStr)]
    }

    // ── Duration conversion ────────────────────────────────────────

    /**
     * "hh:mm:ss" or "hh:mm" → total seconds.
     * Matches HTML Time.toSeconds().
     */
    fun toSeconds(str: String): Long {
        val trimmed = str.trim()
        if (trimmed.isEmpty()) return 0L
        val parts = trimmed.split(":").mapNotNull { it.toLongOrNull() }
        return when (parts.size) {
            3    -> parts[0] * 3600 + parts[1] * 60 + parts[2]
            2    -> parts[0] * 3600 + parts[1] * 60
            else -> 0L
        }
    }

    /** Seconds → "hh:mm:ss" */
    fun toHMS(seconds: Long): String {
        val s = maxOf(0L, seconds)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return "%02d:%02d:%02d".format(h, m, sec)
    }

    /**
     * Seconds → human readable "Xh Ym" or "Xm".
     * Matches HTML Time.toDisplay() including thin-space separator.
     */
    fun toDisplay(seconds: Long): String {
        val s = maxOf(0L, seconds)
        val h = s / 3600
        val m = (s % 3600) / 60
        return when {
            h == 0L && m == 0L -> "0 m"
            h == 0L            -> "$m m"
            m == 0L            -> "$h h"
            else               -> "$h h $m m"
        }
    }

    /** Hours (Double) → seconds */
    fun hoursToSeconds(hours: Double): Long = (hours * 3600).toLong()

    /** Seconds → hours (Double) */
    fun secondsToHours(seconds: Long): Double = seconds / 3600.0
}
