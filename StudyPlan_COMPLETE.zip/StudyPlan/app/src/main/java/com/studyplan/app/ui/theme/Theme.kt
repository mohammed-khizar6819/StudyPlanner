package com.studyplan.app.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.ExperimentalTextApi

private val LightColorScheme = lightColorScheme(
    primary          = Raw_111111, onPrimary        = Raw_FFFFFF,
    primaryContainer = Raw_F5F5F5,
    secondary        = Raw_555555, onSecondary      = Raw_FFFFFF,
    background       = Raw_FAFAFA, onBackground     = Raw_111111,
    surface          = Raw_FFFFFF, onSurface        = Raw_111111,
    surfaceVariant   = Raw_F5F5F5,
    outline          = Raw_E8E8E8, outlineVariant   = Raw_D0D0D0,
    error            = Raw_Red_Light, onError        = Raw_FFFFFF,
)

private val DarkColorScheme = darkColorScheme(
    primary          = Raw_EEEEEE, onPrimary        = Raw_111111,
    primaryContainer = Raw_2A2A2A,
    secondary        = Raw_AAAAAA, onSecondary      = Raw_111111,
    background       = Raw_111111, onBackground     = Raw_EEEEEE,
    surface          = Raw_1A1A1A, onSurface        = Raw_EEEEEE,
    surfaceVariant   = Raw_222222,
    outline          = Raw_2E2E2E, outlineVariant   = Raw_3A3A3A,
    error            = Raw_Red_Dark, onError         = Raw_111111,
)

private const val THEME_ANIM_MS = 180

@Composable
private fun Color.animate() = animateColorAsState(
    targetValue   = this,
    animationSpec = tween(THEME_ANIM_MS),
    label         = "themeColor",
).value

@Composable
private fun animateStudyPlanColors(target: StudyPlanColors) = StudyPlanColors(
    bg             = target.bg.animate(),
    surface        = target.surface.animate(),
    surface2       = target.surface2.animate(),
    hover          = target.hover.animate(),
    border         = target.border.animate(),
    borderStrong   = target.borderStrong.animate(),
    text           = target.text.animate(),
    text2          = target.text2.animate(),
    text3          = target.text3.animate(),
    primary        = target.primary.animate(),
    primaryL       = target.primaryL.animate(),
    primaryX       = target.primaryX.animate(),
    onPrimary      = target.onPrimary.animate(),
    focusRing      = target.focusRing.animate(),
    focusBorder    = target.focusBorder.animate(),
    green          = target.green.animate(),
    greenX         = target.greenX.animate(),
    red            = target.red.animate(),
    redX           = target.redX.animate(),
    yellow         = target.yellow.animate(),
    yellowX        = target.yellowX.animate(),
    blue           = target.blue.animate(),
    blueX          = target.blueX.animate(),
    alertWarnBg    = target.alertWarnBg.animate(),
    alertWarnText  = target.alertWarnText.animate(),
    alertErrorBg   = target.alertErrorBg.animate(),
    cardDoneBg     = target.cardDoneBg.animate(),
    missedRowBg    = target.missedRowBg.animate(),
    missedRowBd    = target.missedRowBd.animate(),
    wrMissedBorder = target.wrMissedBorder.animate(),
    wrGreatBorder  = target.wrGreatBorder.animate(),
    checkBtnBg     = target.checkBtnBg.animate(),
    checkBtnBorder = target.checkBtnBorder.animate(),
    heat0  = target.heat0.animate(),
    heat1  = target.heat1.animate(),
    heat2  = target.heat2.animate(),
    heat3  = target.heat3.animate(),
    heat4  = target.heat4.animate(),
    isDark = target.isDark,
)

@OptIn(ExperimentalTextApi::class)
@Composable
fun StudyPlanTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colors      = animateStudyPlanColors(if (darkTheme) DarkStudyPlanColors else LightStudyPlanColors)
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    CompositionLocalProvider(LocalStudyPlanColors provides colors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography  = StudyPlanTypography,
            shapes      = StudyPlanShapes,
            content     = content,
        )
    }
}

val MaterialTheme.studyColors: StudyPlanColors
    @Composable get() = LocalStudyPlanColors.current
