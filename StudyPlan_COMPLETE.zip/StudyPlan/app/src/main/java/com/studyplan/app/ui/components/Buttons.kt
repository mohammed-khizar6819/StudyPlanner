@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyplan.app.ui.theme.BodyFontFamily
import com.studyplan.app.ui.theme.StudyPlanRadius
import com.studyplan.app.ui.theme.studyColors

// ═══════════════════════════════════════════════════════════════════
//  BUTTON COMPONENTS — port of .btn CSS classes
//  btn-primary, btn-outline, btn-danger, btn-xs, btn-sm, btn-cancel
// ═══════════════════════════════════════════════════════════════════

/** .btn.btn-primary — filled black/white button */
@Composable
fun PrimaryButton(
    text:     String,
    onClick:  () -> Unit,
    modifier: Modifier = Modifier,
    enabled:  Boolean  = true,
    icon:     (@Composable () -> Unit)? = null,
) {
    val colors = MaterialTheme.studyColors
    Button(
        onClick  = onClick,
        enabled  = enabled,
        modifier = modifier.height(36.dp),
        shape    = RoundedCornerShape(StudyPlanRadius.md),
        colors   = ButtonDefaults.buttonColors(
            containerColor         = colors.primary,
            contentColor           = colors.onPrimary,
            disabledContainerColor = colors.surface2,
            disabledContentColor   = colors.text3,
        ),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
    ) {
        if (icon != null) { icon(); Spacer(Modifier.width(6.dp)) }
        Text(text, fontFamily = BodyFontFamily, fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp, letterSpacing = 0.sp)
    }
}

/** .btn.btn-outline — bordered transparent button */
@Composable
fun OutlineButton(
    text:     String,
    onClick:  () -> Unit,
    modifier: Modifier = Modifier,
    enabled:  Boolean  = true,
    icon:     (@Composable () -> Unit)? = null,
) {
    val colors = MaterialTheme.studyColors
    OutlinedButton(
        onClick  = onClick,
        enabled  = enabled,
        modifier = modifier.height(36.dp),
        shape    = RoundedCornerShape(StudyPlanRadius.md),
        border   = BorderStroke(1.dp, colors.borderStrong),
        colors   = ButtonDefaults.outlinedButtonColors(
            contentColor           = colors.text,
            disabledContentColor   = colors.text3,
        ),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
    ) {
        if (icon != null) { icon(); Spacer(Modifier.width(6.dp)) }
        Text(text, fontFamily = BodyFontFamily, fontWeight = FontWeight.Medium,
            fontSize = 13.sp, letterSpacing = 0.sp)
    }
}

/** .btn.btn-danger — red destructive action */
@Composable
fun DangerButton(
    text:     String,
    onClick:  () -> Unit,
    modifier: Modifier = Modifier,
    enabled:  Boolean  = true,
) {
    val colors = MaterialTheme.studyColors
    Button(
        onClick  = onClick,
        enabled  = enabled,
        modifier = modifier.height(36.dp),
        shape    = RoundedCornerShape(StudyPlanRadius.md),
        colors   = ButtonDefaults.buttonColors(
            containerColor = colors.red,
            contentColor   = Color.White,
        ),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
    ) {
        Text(text, fontFamily = BodyFontFamily, fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp, letterSpacing = 0.sp)
    }
}

/** .btn.btn-xs — very small button (table actions, badges) */
@Composable
fun XsButton(
    text:     String,
    onClick:  () -> Unit,
    modifier: Modifier = Modifier,
    variant:  ButtonVariant = ButtonVariant.OUTLINE,
) {
    val colors = MaterialTheme.studyColors
    when (variant) {
        ButtonVariant.OUTLINE -> OutlinedButton(
            onClick  = onClick,
            modifier = modifier.height(26.dp),
            shape    = RoundedCornerShape(StudyPlanRadius.sm),
            border   = BorderStroke(1.dp, colors.borderStrong),
            colors   = ButtonDefaults.outlinedButtonColors(contentColor = colors.text),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
        ) {
            Text(text, fontFamily = BodyFontFamily, fontWeight = FontWeight.Medium,
                fontSize = 11.sp, letterSpacing = 0.sp)
        }
        ButtonVariant.DANGER -> Button(
            onClick  = onClick,
            modifier = modifier.height(26.dp),
            shape    = RoundedCornerShape(StudyPlanRadius.sm),
            colors   = ButtonDefaults.buttonColors(containerColor = colors.red, contentColor = Color.White),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
        ) {
            Text(text, fontFamily = BodyFontFamily, fontWeight = FontWeight.Medium,
                fontSize = 11.sp, letterSpacing = 0.sp)
        }
        ButtonVariant.PRIMARY -> Button(
            onClick  = onClick,
            modifier = modifier.height(26.dp),
            shape    = RoundedCornerShape(StudyPlanRadius.sm),
            colors   = ButtonDefaults.buttonColors(containerColor = colors.primary, contentColor = colors.onPrimary),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
        ) {
            Text(text, fontFamily = BodyFontFamily, fontWeight = FontWeight.Medium,
                fontSize = 11.sp, letterSpacing = 0.sp)
        }
    }
}

/** .btn.btn-sm — slightly smaller than default */
@Composable
fun SmButton(
    text:     String,
    onClick:  () -> Unit,
    modifier: Modifier = Modifier,
    variant:  ButtonVariant = ButtonVariant.OUTLINE,
) {
    val colors = MaterialTheme.studyColors
    when (variant) {
        ButtonVariant.OUTLINE -> OutlinedButton(
            onClick  = onClick,
            modifier = modifier.height(30.dp),
            shape    = RoundedCornerShape(StudyPlanRadius.sm),
            border   = BorderStroke(1.dp, colors.borderStrong),
            colors   = ButtonDefaults.outlinedButtonColors(contentColor = colors.text),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
        ) {
            Text(text, fontFamily = BodyFontFamily, fontWeight = FontWeight.Medium,
                fontSize = 12.sp, letterSpacing = 0.sp)
        }
        ButtonVariant.PRIMARY -> Button(
            onClick  = onClick,
            modifier = modifier.height(30.dp),
            shape    = RoundedCornerShape(StudyPlanRadius.sm),
            colors   = ButtonDefaults.buttonColors(containerColor = colors.primary, contentColor = colors.onPrimary),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
        ) {
            Text(text, fontFamily = BodyFontFamily, fontWeight = FontWeight.Medium,
                fontSize = 12.sp, letterSpacing = 0.sp)
        }
        ButtonVariant.DANGER -> Button(
            onClick  = onClick,
            modifier = modifier.height(30.dp),
            shape    = RoundedCornerShape(StudyPlanRadius.sm),
            colors   = ButtonDefaults.buttonColors(containerColor = colors.red, contentColor = Color.White),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
        ) {
            Text(text, fontFamily = BodyFontFamily, fontWeight = FontWeight.Medium,
                fontSize = 12.sp, letterSpacing = 0.sp)
        }
    }
}

enum class ButtonVariant { PRIMARY, OUTLINE, DANGER }
