@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.subjects

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studyplan.app.domain.engine.TimeUtils
import com.studyplan.app.domain.model.Subject
import com.studyplan.app.ui.animation.*
import com.studyplan.app.ui.components.*
import com.studyplan.app.ui.components.dialog.*
import com.studyplan.app.ui.theme.*
import androidx.compose.animation.AnimatedVisibility

@Composable
fun SubjectsScreen(vm: SubjectsViewModel = hiltViewModel()) {
    val state  by vm.state.collectAsStateWithLifecycle()
    val colors  = MaterialTheme.studyColors
    val toast   = LocalToastHost.current

    LaunchedEffect(Unit) { vm.toast.collect { toast.show(it) } }

    var showAddDialog    by remember { mutableStateOf(false) }
    var editSubject      by remember { mutableStateOf<SubjectWithStats?>(null) }
    var deleteSubject    by remember { mutableStateOf<SubjectWithStats?>(null) }

    Box(modifier = Modifier.fillMaxSize().background(colors.bg)) {
        if (state.isLoading) {
            CircularProgressIndicator(color = colors.text, strokeWidth = 2.dp,
                modifier = Modifier.align(Alignment.Center).size(28.dp))
        } else if (state.items.isEmpty()) {
            Column(modifier = Modifier.fillMaxSize()) {
                PageHeader(title = "Subjects", subtitle = "Manage your study subjects")
                EmptyState(
                    title    = "No subjects yet",
                    subtitle = "Add your first subject or exam to get started.",
                    icon     = Icons.Outlined.MenuBook,
                    cta      = "Add Subject",
                    onCta    = { showAddDialog = true },
                    modifier = Modifier.fillMaxSize(),
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 88.dp),
                modifier       = Modifier.fillMaxSize(),
            ) {
                item {
                    PageHeader(
                        title    = "Subjects",
                        subtitle = "${state.items.size} subject${if (state.items.size != 1) "s" else ""}",
                    )
                }
                itemsIndexed(state.items) { idx, item ->
                    AnimatedVisibility(
                        visible = true,
                        enter   = cardUpEnter(CARD_STAGGER_DELAYS.getOrElse(idx) { idx * 40 }),
                    ) {
                        SubjectCard(
                            item        = item,
                            onEdit      = { editSubject = item },
                            onDelete    = { deleteSubject = item },
                            onToggleRev = { vm.toggleRevision(item.subject) },
                        )
                    }
                    Spacer(Modifier.height(8.dp).padding(horizontal = 16.dp))
                }
            }
        }

        // FAB
        FloatingActionButton(
            onClick          = { showAddDialog = true },
            containerColor   = colors.primary,
            contentColor     = colors.onPrimary,
            modifier         = Modifier.align(Alignment.BottomEnd).padding(20.dp),
        ) {
            Icon(Icons.Outlined.Add, contentDescription = "Add Subject")
        }
    }

    // Add dialog
    if (showAddDialog) {
        SubjectDialog(
            title     = "Add Subject",
            onDismiss = { showAddDialog = false },
            onSave    = { name, full, color, hours, prio, dl, exam ->
                vm.addSubject(name, full, color, hours, prio, dl, exam, null)
                showAddDialog = false
            },
        )
    }

    // Edit dialog
    editSubject?.let { item ->
        SubjectDialog(
            title          = "Edit Subject",
            initialSubject = item.subject,
            onDismiss      = { editSubject = null },
            onSave         = { name, full, color, hours, prio, dl, exam ->
                vm.updateSubject(item.subject.copy(
                    name = name.uppercase().take(10), fullName = full,
                    color = color, dailyHours = hours, priority = prio,
                    deadline = dl, examDate = exam,
                ))
                editSubject = null
            },
        )
    }

    // Delete confirm
    deleteSubject?.let { item ->
        ConfirmDialog(
            visible      = true,
            title        = "Delete Subject",
            message      = "Delete \"${item.subject.fullName.ifEmpty { item.subject.name }}\"? This will permanently remove all ${item.totalLectures} lectures, notes, and schedule entries for this subject.",
            confirmText  = "Delete",
            destructive  = true,
            onConfirm    = { vm.deleteSubject(item.subject.id) },
            onDismiss    = { deleteSubject = null },
        )
    }
}

// ── Subject Card ──────────────────────────────────────────────────
@Composable
private fun SubjectCard(
    item:        SubjectWithStats,
    onEdit:      () -> Unit,
    onDelete:    () -> Unit,
    onToggleRev: () -> Unit,
) {
    val colors = MaterialTheme.studyColors
    val sub    = item.subject

    SurfaceCard(
        modifier = Modifier.padding(horizontal = 16.dp),
        padding  = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
    ) {
        // Header row
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment     = Alignment.Top,
            modifier              = Modifier.fillMaxWidth(),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier          = Modifier.weight(1f).padding(end = 8.dp),
            ) {
                SubjectColorBar(sub.color)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        text       = sub.fullName.ifEmpty { sub.name },
                        fontFamily = BodyFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize   = 15.sp,
                        color      = colors.text,
                        letterSpacing = (-0.3).sp,
                        maxLines   = 1,
                        overflow   = TextOverflow.Ellipsis,
                    )
                    Text(
                        text          = sub.name.uppercase(),
                        fontFamily    = BodyFontFamily,
                        fontWeight    = FontWeight.Bold,
                        fontSize      = 10.sp,
                        color         = colors.text3,
                        letterSpacing = 0.8.sp,
                    )
                }
            }
            // Action buttons
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                // Revision toggle
                val revBg  = if (sub.revisionEnabled) colors.greenX else colors.surface2
                val revBd  = if (sub.revisionEnabled) colors.green.copy(.18f) else colors.border
                val revFg  = if (sub.revisionEnabled) colors.green else colors.text3
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(30.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(revBg)
                        .border(1.dp, revBd, RoundedCornerShape(6.dp))
                        .clickable(indication = null,
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            onClick = onToggleRev),
                ) {
                    Icon(Icons.Outlined.Refresh, "Toggle revision", tint = revFg,
                        modifier = Modifier.size(14.dp))
                }
                // Edit
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(30.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(colors.surface2)
                        .border(1.dp, colors.border, RoundedCornerShape(6.dp))
                        .clickable(indication = null,
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            onClick = onEdit),
                ) {
                    Icon(Icons.Outlined.Edit, "Edit", tint = colors.text3,
                        modifier = Modifier.size(14.dp))
                }
                // Delete
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(30.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(colors.surface2)
                        .border(1.dp, colors.border, RoundedCornerShape(6.dp))
                        .clickable(indication = null,
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            onClick = onDelete),
                ) {
                    Icon(Icons.Outlined.Delete, "Delete", tint = colors.text3,
                        modifier = Modifier.size(14.dp))
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        // Stats grid
        Row(
            horizontalArrangement = Arrangement.spacedBy(0.dp),
            modifier              = Modifier.fillMaxWidth(),
        ) {
            listOf(
                "${item.doneLectures}/${item.totalLectures}" to "Lectures",
                TimeUtils.toDisplay(item.remainingSecs) to "Remaining",
                "${item.pct}%" to "Complete",
                if (sub.deadline.isNotEmpty()) TimeUtils.formatDisplay(sub.deadline) else "—" to "Deadline",
            ).forEachIndexed { i, (value, label) ->
                Column(modifier = Modifier.weight(1f)) {
                    Text(value, fontFamily = BodyFontFamily, fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp, color = colors.text, maxLines = 1,
                        overflow = TextOverflow.Ellipsis)
                    Text(label.uppercase(), fontFamily = BodyFontFamily,
                        fontWeight = FontWeight.Bold, fontSize = 9.sp,
                        color = colors.text3, letterSpacing = 0.8.sp)
                }
                if (i < 3) Spacer(Modifier.width(8.dp))
            }
        }

        Spacer(Modifier.height(12.dp))
        AnimatedProgressBar(progress = item.pct / 100f)

        if (sub.examDate.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.CalendarMonth, null, tint = colors.text3,
                    modifier = Modifier.size(11.dp))
                Spacer(Modifier.width(4.dp))
                Text("Exam: ${TimeUtils.formatDisplay(sub.examDate)}",
                    fontFamily = BodyFontFamily, fontSize = 11.sp, color = colors.text3)
                if (sub.revisionEnabled) {
                    Spacer(Modifier.width(10.dp))
                    Badge("Revision ON", BadgeType.GREEN)
                }
            }
        }
    }
}

// ── Subject Add / Edit Dialog ─────────────────────────────────────
@Composable
private fun SubjectDialog(
    title:          String,
    initialSubject: Subject? = null,
    onDismiss:      () -> Unit,
    onSave:         (name: String, fullName: String, color: String,
                     dailyHours: Double, priority: Int,
                     deadline: String, examDate: String) -> Unit,
) {
    var name       by remember { mutableStateOf(initialSubject?.name ?: "") }
    var fullName   by remember { mutableStateOf(initialSubject?.fullName ?: "") }
    var color      by remember { mutableStateOf(initialSubject?.color ?: "#374151") }
    var dailyHours by remember { mutableStateOf(initialSubject?.dailyHours?.toString() ?: "6.0") }
    var priority   by remember { mutableIntStateOf(initialSubject?.priority ?: 1) }
    var deadline   by remember { mutableStateOf(initialSubject?.deadline ?: "") }
    var examDate   by remember { mutableStateOf(initialSubject?.examDate ?: "") }
    val toast      = LocalToastHost.current

    StudyPlanDialog(
        visible   = true,
        title     = title,
        onDismiss = onDismiss,
        footer    = {
            OutlineButton("Cancel", onClick = onDismiss)
            Spacer(Modifier.width(8.dp))
            PrimaryButton("Save") {
                if (fullName.isBlank()) { toast.show("Subject name required", true); return@PrimaryButton }
                val hrs = dailyHours.toDoubleOrNull() ?: 6.0
                onSave(name.ifBlank { fullName.take(6) }, fullName, color,
                    hrs.coerceIn(0.5, 24.0), priority, deadline, examDate)
            }
        },
    ) {
        FieldLabel("Subject / Exam Full Name")
        StudyTextField(value = fullName, onValueChange = { fullName = it },
            placeholder = "e.g. Financial Reporting")
        Spacer(Modifier.height(12.dp))

        FieldLabel("Short Code (shown in schedule)")
        StudyTextField(value = name, onValueChange = { name = it.uppercase().take(10) },
            placeholder = "e.g. FR")
        Spacer(Modifier.height(12.dp))

        FieldLabel("Daily Study Hours")
        StudyTextField(value = dailyHours, onValueChange = { dailyHours = it },
            placeholder = "6.0",
            keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal)
        Spacer(Modifier.height(12.dp))

        FieldLabel("Color")
        ColorPicker(selected = color, onSelect = { color = it })
        Spacer(Modifier.height(12.dp))

        DatePickerField(value = deadline, onSelect = { deadline = it }, label = "Study Deadline")
        Spacer(Modifier.height(12.dp))
        DatePickerField(value = examDate, onSelect = { examDate = it }, label = "Exam Date (optional)")
        Spacer(Modifier.height(12.dp))

        FieldLabel("Priority (lower = scheduled first)")
        StudyDropdown(
            options   = (1..5).map { DropdownOption(it, "Priority $it") },
            selected  = priority,
            onSelect  = { priority = it },
        )
    }
}
