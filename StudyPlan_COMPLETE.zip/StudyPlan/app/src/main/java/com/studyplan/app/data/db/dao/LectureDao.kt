package com.studyplan.app.data.db.dao

import androidx.room.*
import com.studyplan.app.data.db.entity.LectureEntity
import com.studyplan.app.domain.model.LectureStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface LectureDao {
    @Query("SELECT * FROM lectures ORDER BY subjectId, sequence ASC")
    fun observeAll(): Flow<List<LectureEntity>>

    @Query("SELECT * FROM lectures ORDER BY subjectId, sequence ASC")
    suspend fun getAll(): List<LectureEntity>

    @Query("SELECT * FROM lectures WHERE subjectId = :subjectId ORDER BY sequence ASC")
    suspend fun getBySubject(subjectId: String): List<LectureEntity>

    @Query("SELECT * FROM lectures WHERE subjectId = :subjectId ORDER BY sequence ASC")
    fun observeBySubject(subjectId: String): Flow<List<LectureEntity>>

    @Query("SELECT * FROM lectures WHERE id = :id")
    suspend fun getById(id: String): LectureEntity?

    @Query("SELECT * FROM lectures WHERE status != :status ORDER BY sequence ASC")
    suspend fun getByStatusNot(status: LectureStatus): List<LectureEntity>

    @Query("SELECT * FROM lectures WHERE status = :status ORDER BY subjectId, sequence ASC")
    suspend fun getByStatus(status: LectureStatus): List<LectureEntity>

    @Query("SELECT MAX(sequence) FROM lectures WHERE subjectId = :subjectId")
    suspend fun maxSequenceForSubject(subjectId: String): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(lecture: LectureEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(lectures: List<LectureEntity>)

    @Update
    suspend fun update(lecture: LectureEntity)

    @Query("UPDATE lectures SET remaining = :remaining, status = :status, completedOn = :completedOn, todayStudied = :todayStudied, todayDate = :todayDate WHERE id = :id")
    suspend fun updateProgress(id: String, remaining: Long, status: LectureStatus, completedOn: String?, todayStudied: Long, todayDate: String?)

    @Delete
    suspend fun delete(lecture: LectureEntity)

    @Query("DELETE FROM lectures WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM lectures WHERE subjectId = :subjectId")
    suspend fun deleteBySubject(subjectId: String)

    @Query("DELETE FROM lectures")
    suspend fun deleteAll()
}
