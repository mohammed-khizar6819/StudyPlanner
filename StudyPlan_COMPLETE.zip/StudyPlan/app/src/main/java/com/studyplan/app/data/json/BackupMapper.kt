package com.studyplan.app.data.json

import com.studyplan.app.data.db.entity.*
import com.studyplan.app.domain.model.*

/**
 * Converts between the Room entity world and the JSON backup world.
 * Used by both JSON import/export and the multi-plan snapshot system.
 */
object BackupMapper {

    // ── Room → Backup (for export / plan save) ────────────────────
    fun toBackup(
        settings:    SettingsEntity?,
        meta:        MetaEntity?,
        subjects:    List<SubjectEntity>,
        lectures:    List<LectureEntity>,
        entries:     List<ScheduleEntryEntity>,
        notes:       List<NoteEntity>,
        sessionLogs: List<SessionLogEntity>,
    ): StudyPlanBackup {
        val scheduleMap: Map<String, List<BackupScheduleEntry>> = entries
            .groupBy { it.date }
            .mapValues { (_, dayEntries) ->
                dayEntries.map { e ->
                    BackupScheduleEntry(e.lectureId, e.subjectId,
                        e.plannedSeconds, e.completedSeconds, e.status.value)
                }
            }

        val notesMap: Map<String, List<BackupNote>> = notes
            .groupBy { it.lectureId }
            .mapValues { (_, noteList) ->
                noteList.map { n ->
                    BackupNote(n.id, n.text, n.type.value, n.createdAt, n.resolved)
                }
            }

        return StudyPlanBackup(
            settings = settings?.let {
                BackupSettings(it.startDate, it.dailyStudyHours, it.bufferDayOfWeek,
                    it.weeklyGoalHours, it.interleaveSubjects, it.intensityRampEnabled,
                    it.intensityStartHours, it.intensityEndHours, it.examLockDays,
                    it.alarmEnabled, it.alarmHour, it.alarmMinute,
                    it.notifEnabled, it.notifHour, it.vacationDates)
            } ?: BackupSettings("", 6.0, 0),

            subjects = subjects.map { s ->
                BackupSubject(s.id, s.name, s.fullName, s.deadline, s.examDate,
                    s.dailyHours, s.priority, s.color, s.createdAt,
                    s.revisionEnabled, s.revisionRound)
            },

            lectures = lectures.map { l ->
                BackupLecture(l.id, l.subjectId, l.sequence, l.lectureNum, l.name,
                    l.duration, l.remaining, l.status.value, l.completedOn,
                    l.todayStudied, l.todayDate, l.chapter,
                    l.tags.map { it.value }, l.difficulty.value)
            },

            schedule    = scheduleMap,
            notes       = notesMap,

            sessionLogs = sessionLogs.map { sl ->
                BackupSessionLog(sl.date, sl.hour, sl.seconds, sl.lectureId, sl.subjectId)
            },

            meta = meta?.let {
                BackupMeta(it.initialized, it.version, it.lastBuiltDate,
                    it.onboarded, it.achievedMilestones)
            } ?: BackupMeta(),
        )
    }

    // ── Backup → Room entities (for import / plan load) ───────────
    data class RestoredEntities(
        val settings:    SettingsEntity,
        val meta:        MetaEntity,
        val subjects:    List<SubjectEntity>,
        val lectures:    List<LectureEntity>,
        val entries:     List<ScheduleEntryEntity>,
        val notes:       List<NoteEntity>,
        val sessionLogs: List<SessionLogEntity>,
    )

    fun fromBackup(backup: StudyPlanBackup): RestoredEntities {
        val s = backup.settings
        val settings = SettingsEntity(1, s.startDate, s.dailyStudyHours,
            s.bufferDayOfWeek, s.weeklyGoalHours, s.interleaveSubjects,
            s.intensityRampEnabled, s.intensityStartHours, s.intensityEndHours,
            s.examLockDays, s.alarmEnabled, s.alarmHour, s.alarmMinute,
            s.notifEnabled, s.notifHour, s.vacationDates)

        val m = backup.meta
        val meta = MetaEntity(1, m.initialized, m.version, m.lastBuiltDate,
            m.onboarded, m.achievedMilestones)

        val subjects = backup.subjects.map { bs ->
            SubjectEntity(bs.id, bs.name, bs.fullName, bs.deadline, bs.examDate,
                bs.dailyHours, bs.priority, bs.color, bs.createdAt,
                bs.revisionEnabled, bs.revisionRound)
        }

        val lectures = backup.lectures.map { bl ->
            LectureEntity(bl.id, bl.subjectId, bl.sequence, bl.lectureNum, bl.name,
                bl.duration, bl.remaining, LectureStatus.from(bl.status),
                bl.completedOn, bl.todayStudied, bl.todayDate, bl.chapter,
                LectureTag.fromList(bl.tags), LectureDifficulty.from(bl.difficulty))
        }

        val entries = backup.schedule.flatMap { (date, dayEntries) ->
            dayEntries.map { be ->
                ScheduleEntryEntity(0, date, be.lectureId, be.subjectId,
                    be.plannedSeconds, be.completedSeconds,
                    ScheduleEntryStatus.from(be.status))
            }
        }

        val notes = backup.notes.flatMap { (lectureId, noteList) ->
            noteList.map { bn ->
                NoteEntity(bn.id, lectureId, bn.text,
                    NoteType.from(bn.type), bn.createdAt, bn.resolved)
            }
        }

        val sessionLogs = backup.sessionLogs.map { sl ->
            SessionLogEntity(0, sl.date, sl.hour, sl.seconds, sl.lectureId, sl.subjectId)
        }

        return RestoredEntities(settings, meta, subjects, lectures, entries, notes, sessionLogs)
    }
}
