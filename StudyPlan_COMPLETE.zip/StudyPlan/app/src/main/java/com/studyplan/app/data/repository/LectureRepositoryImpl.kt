package com.studyplan.app.data.repository
import com.studyplan.app.data.db.dao.LectureDao
import com.studyplan.app.data.db.entity.LectureEntity
import com.studyplan.app.domain.model.Lecture
import com.studyplan.app.domain.model.LectureStatus
import com.studyplan.app.domain.repository.LectureRepository
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LectureRepositoryImpl @Inject constructor(
    private val dao: LectureDao,
) : LectureRepository {
    override fun observeAll()                         = dao.observeAll().map { it.map { e -> e.toDomain() } }
    override suspend fun getAll()                     = dao.getAll().map { it.toDomain() }
    override suspend fun getBySubject(sid: String)    = dao.getBySubject(sid).map { it.toDomain() }
    override fun observeBySubject(sid: String)        = dao.observeBySubject(sid).map { it.map { e -> e.toDomain() } }
    override suspend fun getById(id: String)          = dao.getById(id)?.toDomain()
    override suspend fun getByStatus(s: LectureStatus) = dao.getByStatus(s).map { it.toDomain() }
    override suspend fun getPendingAndPartial()        = dao.getByStatusNot(LectureStatus.COMPLETE).map { it.toDomain() }
    override suspend fun maxSequenceForSubject(sid: String) = dao.maxSequenceForSubject(sid) ?: 0
    override suspend fun insert(l: Lecture)           = dao.insert(LectureEntity.fromDomain(l))
    override suspend fun insertAll(list: List<Lecture>) = dao.insertAll(list.map { LectureEntity.fromDomain(it) })
    override suspend fun update(l: Lecture)           = dao.update(LectureEntity.fromDomain(l))
    override suspend fun updateProgress(l: Lecture)   = dao.updateProgress(
        l.id, l.remaining, l.status, l.completedOn, l.todayStudied, l.todayDate)
    override suspend fun delete(id: String)           = dao.deleteById(id)
    override suspend fun deleteBySubject(sid: String) = dao.deleteBySubject(sid)
    override suspend fun deleteAll()                  = dao.deleteAll()
}
