package com.studyplan.app.domain.model

/**
 * One study session event — used for the time-of-day heatmap in Analytics.
 * Capped at 1000 entries (oldest pruned).
 */
data class SessionLog(
    val id:        Long,    // auto-generated
    val date:      String,  // YYYY-MM-DD
    val hour:      Int,     // 0–23
    val seconds:   Long,
    val lectureId: String,
    val subjectId: String,
)
