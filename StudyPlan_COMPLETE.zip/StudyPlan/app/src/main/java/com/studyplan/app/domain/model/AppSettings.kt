package com.studyplan.app.domain.model

/**
 * Global study planner settings — mirrors the HTML settings object exactly.
 * Single-row table in Room.
 */
data class AppSettings(
    val startDate:             String,         // YYYY-MM-DD study start
    val dailyStudyHours:       Double,         // global daily hours
    val bufferDayOfWeek:       Int,            // 0=Sun 1=Mon … 6=Sat, -1=none
    val weeklyGoalHours:       Double,         // 0 = disabled
    val interleaveSubjects:    Boolean,
    val intensityRampEnabled:  Boolean,
    val intensityStartHours:   Double,
    val intensityEndHours:     Double,
    val examLockDays:          Int,
    val alarmEnabled:          Boolean,
    val alarmHour:             Int,
    val alarmMinute:           Int,
    val notifEnabled:          Boolean,
    val notifHour:             Int,
    val vacationDates:         List<String>,   // list of YYYY-MM-DD strings
)
