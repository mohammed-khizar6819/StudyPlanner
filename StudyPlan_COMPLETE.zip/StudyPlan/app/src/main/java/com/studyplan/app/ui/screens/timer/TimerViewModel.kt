@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.timer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studyplan.app.domain.engine.*
import com.studyplan.app.domain.model.*
import com.studyplan.app.domain.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

// ── Timer modes & phases (mirrors HTML TimerEngine) ───────────────
enum class TimerMode  { POMODORO, STOPWATCH }
enum class TimerPhase { IDLE, FOCUS, BREAK, LONG_BREAK, RUNNING }

data class TimerUiState(
    val mode:            TimerMode         = TimerMode.POMODORO,
    val phase:           TimerPhase        = TimerPhase.IDLE,
    // Pomodoro countdown (seconds remaining)
    val remaining:       Long              = 25 * 60,
    // Stopwatch elapsed (seconds)
    val elapsed:         Long              = 0,
    // Total focus seconds this session (for the "total focus" display)
    val totalFocus:      Long              = 0,
    // Completed pomodoros today
    val sessions:        Int               = 0,
    // Selected lecture for logging
    val selectedLecId:   String?           = null,
    // Available lectures (pending/partial only)
    val lectures:        List<Lecture>     = emptyList(),
    val subjects:        List<Subject>     = emptyList(),
    // Configurable durations (minutes)
    val workMinutes:     Int               = 25,
    val shortBreakMins:  Int               = 5,
    val longBreakMins:   Int               = 15,
    val isRunning:       Boolean           = false,
)

@HiltViewModel
class TimerViewModel @Inject constructor(
    private val schedulerEngine: SchedulerEngine,
    private val lectureRepo:     LectureRepository,
    private val subjectRepo:     SubjectRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(TimerUiState())
    val state: StateFlow<TimerUiState> = _state.asStateFlow()

    // Sidebar timer dot — true when timer is running in any mode
    val isTimerRunning: StateFlow<Boolean> = state.map { it.isRunning }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    private val _toast = MutableSharedFlow<String>()
    val toast: SharedFlow<String> = _toast.asSharedFlow()

    // Log-time prompt after pomodoro ends
    private val _promptLog = MutableSharedFlow<Long>()  // seconds to log
    val promptLog: SharedFlow<Long> = _promptLog.asSharedFlow()

    private var tickJob: Job? = null

    init { loadLectures() }

    private fun loadLectures() {
        viewModelScope.launch {
            val all      = lectureRepo.getAll()
            val subjects = subjectRepo.getAll()
            val pending  = all.filter {
                it.status == LectureStatus.PENDING || it.status == LectureStatus.PARTIAL
            }
            val firstId  = pending.firstOrNull()?.id
            _state.update { it.copy(
                lectures     = pending,
                subjects     = subjects,
                selectedLecId = it.selectedLecId ?: firstId,
            )}
        }
    }

    // ── Mode switch ───────────────────────────────────────────────
    fun setMode(mode: TimerMode) {
        stopTick()
        _state.update { s ->
            s.copy(
                mode      = mode,
                phase     = TimerPhase.IDLE,
                remaining = s.workMinutes * 60L,
                elapsed   = 0,
                isRunning = false,
            )
        }
    }

    // ── Lecture selector ──────────────────────────────────────────
    fun selectLecture(lecId: String) = _state.update { it.copy(selectedLecId = lecId) }

    // ═══════════════════════════════════════════════════════════════
    //  POMODORO CONTROLS
    // ═══════════════════════════════════════════════════════════════
    fun pomodoroStart() {
        val s = _state.value
        if (s.phase == TimerPhase.IDLE) {
            _state.update { it.copy(phase = TimerPhase.FOCUS, isRunning = true) }
        } else {
            _state.update { it.copy(isRunning = true) }
        }
        startTick()
    }

    fun pomodoroPause() {
        stopTick()
        _state.update { it.copy(isRunning = false) }
    }

    fun pomodoroReset() {
        stopTick()
        _state.update { s ->
            s.copy(
                phase     = TimerPhase.IDLE,
                remaining = s.workMinutes * 60L,
                isRunning = false,
            )
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  STOPWATCH CONTROLS
    // ═══════════════════════════════════════════════════════════════
    fun stopwatchStart() {
        _state.update { it.copy(phase = TimerPhase.RUNNING, isRunning = true) }
        startTick()
    }

    fun stopwatchPause() {
        stopTick()
        _state.update { it.copy(isRunning = false) }
    }

    fun stopwatchReset() {
        stopTick()
        _state.update { it.copy(phase = TimerPhase.IDLE, elapsed = 0, isRunning = false) }
    }

    /** Log stopwatch elapsed time to selected lecture */
    fun stopwatchLog() {
        viewModelScope.launch {
            val s     = _state.value
            val secs  = s.elapsed
            val lecId = s.selectedLecId
            if (lecId == null || secs <= 0) {
                _toast.emit("Select a lecture and start the timer first")
                return@launch
            }
            val lec  = lectureRepo.getById(lecId)
            if (lec == null || lec.status == LectureStatus.COMPLETE) {
                _toast.emit("Lecture already complete")
                return@launch
            }
            val today  = TimeUtils.today()
            val prev   = if (lec.todayDate == today) lec.todayStudied else 0L
            val ok     = schedulerEngine.partialComplete(lecId, prev + secs)
            if (ok) {
                _toast.emit("${TimeUtils.toDisplay(secs)} logged!")
                stopTick()
                _state.update { it.copy(elapsed = 0, phase = TimerPhase.IDLE, isRunning = false) }
                loadLectures()
            } else {
                _toast.emit("Already complete")
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  TICK COROUTINE — runs every second
    // ═══════════════════════════════════════════════════════════════
    private fun startTick() {
        tickJob?.cancel()
        tickJob = viewModelScope.launch {
            while (true) {
                delay(1_000)
                val s = _state.value
                if (!s.isRunning) break

                when (s.mode) {
                    TimerMode.POMODORO  -> tickPomodoro(s)
                    TimerMode.STOPWATCH -> _state.update { it.copy(elapsed = it.elapsed + 1) }
                }
            }
        }
    }

    private fun stopTick() { tickJob?.cancel(); tickJob = null }

    private suspend fun tickPomodoro(s: TimerUiState) {
        val newRemaining = s.remaining - 1
        if (newRemaining > 0) {
            _state.update { it.copy(remaining = newRemaining) }
            return
        }
        // Timer reached 0 — transition phase
        stopTick()
        when (s.phase) {
            TimerPhase.FOCUS -> {
                val newSessions  = s.sessions + 1
                val focusSecs    = s.workMinutes * 60L
                val newTotalFocus = s.totalFocus + focusSecs

                // Prompt to log time
                if (s.selectedLecId != null) {
                    _promptLog.emit(focusSecs)
                }
                _toast.emit("Focus session complete! 🎉")

                // Decide break type
                val isLongBreak = newSessions % 4 == 0
                val breakSecs   = if (isLongBreak) s.longBreakMins * 60L else s.shortBreakMins * 60L
                val nextPhase   = if (isLongBreak) TimerPhase.LONG_BREAK else TimerPhase.BREAK

                _state.update {
                    it.copy(
                        phase      = nextPhase,
                        remaining  = breakSecs,
                        sessions   = newSessions,
                        totalFocus = newTotalFocus,
                        isRunning  = false,
                    )
                }
            }
            TimerPhase.BREAK, TimerPhase.LONG_BREAK -> {
                _toast.emit("Break over — ready for the next session!")
                _state.update {
                    it.copy(
                        phase     = TimerPhase.IDLE,
                        remaining = it.workMinutes * 60L,
                        isRunning = false,
                    )
                }
            }
            else -> Unit
        }
    }

    /** Called when user confirms logging from the pomodoro end-of-session prompt */
    fun logPomodoroSession(seconds: Long) {
        viewModelScope.launch {
            val lecId = _state.value.selectedLecId ?: return@launch
            val lec   = lectureRepo.getById(lecId) ?: return@launch
            val today  = TimeUtils.today()
            val prev   = if (lec.todayDate == today) lec.todayStudied else 0L
            val ok     = schedulerEngine.partialComplete(lecId, prev + seconds)
            if (ok) {
                _toast.emit("${TimeUtils.toDisplay(seconds)} logged!")
                loadLectures()
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopTick()
    }
}
