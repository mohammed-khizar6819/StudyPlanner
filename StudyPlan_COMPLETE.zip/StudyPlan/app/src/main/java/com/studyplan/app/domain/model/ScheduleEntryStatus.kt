package com.studyplan.app.domain.model

/** Mirrors schedule entry status: "scheduled" | "done" | "partial_done" */
enum class ScheduleEntryStatus(val value: String) {
    SCHEDULED("scheduled"),
    DONE("done"),
    PARTIAL_DONE("partial_done");
    companion object {
        fun from(value: String) = entries.firstOrNull { it.value == value } ?: SCHEDULED
    }
}
