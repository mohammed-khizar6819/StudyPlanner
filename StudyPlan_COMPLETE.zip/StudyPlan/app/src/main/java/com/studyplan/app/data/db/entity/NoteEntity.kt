package com.studyplan.app.data.db.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.studyplan.app.domain.model.Note
import com.studyplan.app.domain.model.NoteType

@Entity(
    tableName = "notes",
    foreignKeys = [ForeignKey(
        entity        = LectureEntity::class,
        parentColumns = ["id"],
        childColumns  = ["lectureId"],
        onDelete      = ForeignKey.CASCADE,
    )],
    indices = [Index("lectureId")],
)
data class NoteEntity(
    @PrimaryKey val id:  String,
    val lectureId:  String,
    val text:       String,
    val type:       NoteType,
    val createdAt:  String,
    val resolved:   Boolean,
) {
    fun toDomain() = Note(id, lectureId, text, type, createdAt, resolved)
    companion object {
        fun fromDomain(n: Note) = NoteEntity(n.id, n.lectureId, n.text,
            n.type, n.createdAt, n.resolved)
    }
}
