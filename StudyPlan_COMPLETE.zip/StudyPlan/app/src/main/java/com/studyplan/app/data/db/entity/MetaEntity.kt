package com.studyplan.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.studyplan.app.domain.model.AppMeta

/** Single-row table — always upserted by primary key = 1 */
@Entity(tableName = "meta")
data class MetaEntity(
    @PrimaryKey val id:          Int = 1,
    val initialized:        Boolean,
    val version:            Int,
    val lastBuiltDate:      String,
    val onboarded:          Boolean,
    val achievedMilestones: List<String>,
) {
    fun toDomain() = AppMeta(initialized, version, lastBuiltDate, onboarded, achievedMilestones)
    companion object {
        fun fromDomain(m: AppMeta) = MetaEntity(1, m.initialized, m.version,
            m.lastBuiltDate, m.onboarded, m.achievedMilestones)
    }
}
