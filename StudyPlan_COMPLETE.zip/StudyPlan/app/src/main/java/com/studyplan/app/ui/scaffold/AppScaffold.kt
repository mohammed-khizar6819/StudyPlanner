@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.scaffold

import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material3.*
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.studyplan.app.ui.components.LocalToastHost
import com.studyplan.app.ui.components.ToastHost
import com.studyplan.app.ui.components.ToastHostState
import com.studyplan.app.ui.navigation.Screen
import com.studyplan.app.ui.navigation.StudyPlanNavGraph
import com.studyplan.app.ui.theme.BricolageGrotesque
import com.studyplan.app.ui.theme.studyColors
import kotlinx.coroutines.launch

private val SIDEBAR_WIDTH = 240.dp

@OptIn(ExperimentalMaterial3WindowSizeClassApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AppScaffold(
    isDarkTheme:   Boolean,
    onThemeToggle: () -> Unit,
    scaffoldVm:    ScaffoldViewModel = hiltViewModel(),
) {
    val activity    = LocalContext.current as ComponentActivity
    val windowSize  = calculateWindowSizeClass(activity)
    val isExpanded  = windowSize.widthSizeClass != WindowWidthSizeClass.Compact

    val navController  = rememberNavController()
    val backStack      by navController.currentBackStackEntryAsState()
    val currentRoute   = backStack?.destination?.route

    val undoPending    by scaffoldVm.undoPending.collectAsStateWithLifecycle()
    val todayDone      by scaffoldVm.todayDone.collectAsStateWithLifecycle()
    val todayTotal     by scaffoldVm.todayTotal.collectAsStateWithLifecycle()
    val toastHostState = remember { ToastHostState() }

    // Show undo toast when pending action arrives
    LaunchedEffect(undoPending) {
        undoPending?.let { toastHostState.showWithUndo("Undo: ${it.label}") }
    }

    fun navigateTo(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState    = true
        }
    }

    CompositionLocalProvider(LocalToastHost provides toastHostState) {
        Box(modifier = Modifier.fillMaxSize()) {

            if (isExpanded) {
                Row(
                    modifier = Modifier.fillMaxSize().background(MaterialTheme.studyColors.bg)
                        .windowInsetsPadding(WindowInsets.safeDrawing),
                ) {
                    Box(modifier = Modifier.width(SIDEBAR_WIDTH).fillMaxHeight()
                        .background(MaterialTheme.studyColors.bg)) {
                        SidebarContent(currentRoute = currentRoute,
                            onNavItemClick = ::navigateTo,
                            isDarkTheme    = isDarkTheme,
                            onThemeToggle  = onThemeToggle,
                            todayDone      = todayDone,
                            todayTotal     = todayTotal)
                    }
                    Box(modifier = Modifier.fillMaxHeight().width(1.dp)
                        .background(MaterialTheme.studyColors.border))
                    StudyPlanNavGraph(navController = navController, modifier = Modifier.fillMaxSize())
                }
            } else {
                val drawerState = rememberDrawerState(DrawerValue.Closed)
                val scope       = rememberCoroutineScope()
                ModalNavigationDrawer(
                    drawerState     = drawerState,
                    gesturesEnabled = true,
                    drawerContent   = {
                        ModalDrawerSheet(
                            drawerContainerColor = MaterialTheme.studyColors.bg,
                            drawerContentColor   = MaterialTheme.studyColors.text,
                            modifier             = Modifier.width(SIDEBAR_WIDTH),
                        ) {
                            SidebarContent(currentRoute = currentRoute,
                                onNavItemClick = { route ->
                                    scope.launch { drawerState.close() }
                                    navigateTo(route)
                                },
                                isDarkTheme    = isDarkTheme,
                                onThemeToggle  = onThemeToggle,
                                todayDone      = todayDone,
                                todayTotal     = todayTotal)
                        }
                    },
                ) {
                    Scaffold(
                        containerColor      = MaterialTheme.studyColors.bg,
                        contentWindowInsets = WindowInsets.safeDrawing,
                        topBar = {
                            StudyPlanTopBar(currentRoute = currentRoute,
                                onMenuClick = { scope.launch { drawerState.open() } })
                        },
                    ) { padding ->
                        StudyPlanNavGraph(navController = navController,
                            modifier = Modifier.fillMaxSize().padding(padding))
                    }
                }
            }

            // Global toast — wired to undo manager
            ToastHost(
                hostState = toastHostState,
                onUndo    = { scaffoldVm.executeUndo() },
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StudyPlanTopBar(currentRoute: String?, onMenuClick: () -> Unit) {
    val colors = MaterialTheme.studyColors
    TopAppBar(
        title = {
            Text("StudyPlan", fontFamily = BricolageGrotesque, fontWeight = FontWeight.Bold,
                fontSize = 15.sp, color = colors.text, letterSpacing = (-0.3).sp)
        },
        navigationIcon = {
            IconButton(onClick = onMenuClick) {
                Icon(Icons.Outlined.Menu, "Open menu", tint = colors.text)
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = colors.bg, scrolledContainerColor = colors.bg),
    )
}
