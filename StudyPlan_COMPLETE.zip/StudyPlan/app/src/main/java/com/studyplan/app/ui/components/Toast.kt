@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.studyplan.app.ui.animation.TOAST_SLIDE_MS
import com.studyplan.app.ui.theme.BodyFontFamily
import com.studyplan.app.ui.theme.studyColors
import kotlinx.coroutines.delay

// ═══════════════════════════════════════════════════════════════════
//  TOAST STATE — hoisted above the entire app via CompositionLocal
// ═══════════════════════════════════════════════════════════════════

data class ToastState(
    val message: String     = "",
    val isError: Boolean    = false,
    val showUndo: Boolean   = false,
    val undoLabel: String   = "Undo",
)

val LocalToastHost = compositionLocalOf { ToastHostState() }

class ToastHostState {
    var state by mutableStateOf(ToastState())
        private set
    private var toastJob: kotlinx.coroutines.Job? = null

    fun show(message: String, isError: Boolean = false) {
        state = ToastState(message, isError)
    }

    fun showWithUndo(message: String, undoLabel: String = "Undo") {
        state = ToastState(message, showUndo = true, undoLabel = undoLabel)
    }

    fun dismiss() { state = ToastState() }
}

// ═══════════════════════════════════════════════════════════════════
//  TOAST HOST — renders the toast overlay at the bottom of the screen
//  Place once at the root of AppScaffold.
// ═══════════════════════════════════════════════════════════════════

@Composable
fun ToastHost(
    hostState:  ToastHostState,
    onUndo:     () -> Unit = {},
) {
    val colors  = MaterialTheme.studyColors
    val state   = hostState.state
    val visible = state.message.isNotEmpty()

    // Auto-dismiss after 3s
    LaunchedEffect(state.message) {
        if (state.message.isNotEmpty()) {
            delay(3000)
            hostState.dismiss()
        }
    }

    Box(
        contentAlignment = Alignment.BottomCenter,
        modifier = Modifier
            .fillMaxSize()
            .zIndex(9999f)
            .padding(bottom = 32.dp),
    ) {
        AnimatedVisibility(
            visible = visible,
            enter   = fadeIn(tween(TOAST_SLIDE_MS)) +
                      slideInVertically(tween(TOAST_SLIDE_MS)) { it / 3 },
            exit    = fadeOut(tween(TOAST_SLIDE_MS)),
        ) {
            val bgColor = if (state.isError) colors.red else colors.text
            val fgColor = if (state.isError) Color.White else colors.bg

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(100.dp))
                    .background(bgColor)
                    .padding(horizontal = 20.dp, vertical = 10.dp),
            ) {
                Text(
                    text       = state.message,
                    fontFamily = BodyFontFamily,
                    fontWeight = FontWeight.Medium,
                    fontSize   = 13.sp,
                    color      = fgColor,
                )
                if (state.showUndo) {
                    Spacer(Modifier.width(12.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(100.dp))
                            .background(fgColor.copy(alpha = 0.18f))
                            .clickable(
                                indication        = null,
                                interactionSource = remember { MutableInteractionSource() },
                                onClick           = {
                                    onUndo()
                                    hostState.dismiss()
                                },
                            )
                            .padding(horizontal = 10.dp, vertical = 3.dp),
                    ) {
                        Text(
                            text       = state.undoLabel,
                            fontFamily = BodyFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize   = 12.sp,
                            color      = fgColor,
                        )
                    }
                }
            }
        }
    }
}
