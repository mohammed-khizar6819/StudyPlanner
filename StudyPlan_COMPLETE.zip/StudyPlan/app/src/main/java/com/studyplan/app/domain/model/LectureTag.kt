package com.studyplan.app.domain.model

/** Mirrors HTML lecture tags: hw | nm | th | im */
enum class LectureTag(val value: String, val label: String) {
    HIGH_WEIGHTAGE("hw", "⚡ High Weightage"),
    NUMERICALS("nm",     "🔢 Numericals"),
    THEORY("th",         "📖 Theory"),
    IMPORTANT("im",      "🎯 Important");
    companion object {
        fun from(value: String) = entries.firstOrNull { it.value == value }
        fun fromList(values: List<String>) = values.mapNotNull { from(it) }
    }
}
