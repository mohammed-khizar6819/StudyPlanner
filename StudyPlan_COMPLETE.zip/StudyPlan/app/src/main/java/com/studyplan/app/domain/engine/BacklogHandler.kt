package com.studyplan.app.domain.engine

import com.studyplan.app.domain.model.*
import com.studyplan.app.domain.repository.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.ceil
import kotlin.math.min

/**
 * Port of HTML Actions.handleBacklog().
 * Applies one of 4 strategies to clear backlog, then rebuilds schedule.
 */
@Singleton
class BacklogHandler @Inject constructor(
    private val subjectRepo:   SubjectRepository,
    private val lectureRepo:   LectureRepository,
    private val scheduleRepo:  ScheduleRepository,
    private val settingsRepo:  SettingsRepository,
    private val schedulerEngine: SchedulerEngine,
    private val statsEngine:     StatsEngine,
) {
    enum class Strategy {
        EXTEND_DEADLINES,   // extend all deadlines by 14 days
        INCREASE_HOURS,     // increase daily hours by 1h for all subjects
        ACKNOWLEDGE,        // wipe past incomplete entries, rebuild forward
        REDISTRIBUTE,       // add extra hours spread over N days
    }

    /**
     * Apply chosen strategy, wipe past incomplete entries, rebuild schedule.
     * @param redistributeDays used only for REDISTRIBUTE strategy
     * @return toast message describing what was done
     */
    suspend fun apply(
        strategy:          Strategy,
        redistributeDays:  Int = 7,
    ): String = withContext(Dispatchers.Default) {
        val today    = TimeUtils.today()
        val settings = settingsRepo.get() ?: return@withContext "Error: no settings"
        val subjects = subjectRepo.getAll()
        val stats    = statsEngine.getStats()

        val message: String = when (strategy) {

            Strategy.EXTEND_DEADLINES -> {
                subjects.forEach { sub ->
                    if (sub.deadline.isNotEmpty()) {
                        subjectRepo.update(sub.copy(
                            deadline = TimeUtils.addDays(sub.deadline, 14)))
                    }
                }
                "Deadlines extended 2 weeks — backlog cleared"
            }

            Strategy.INCREASE_HOURS -> {
                val newHours = min(24.0, settings.dailyStudyHours + 1.0)
                settingsRepo.upsert(settings.copy(dailyStudyHours = newHours))
                subjects.forEach { sub ->
                    subjectRepo.update(sub.copy(dailyHours = min(24.0, sub.dailyHours + 1.0)))
                }
                "Daily hours increased — backlog cleared"
            }

            Strategy.REDISTRIBUTE -> {
                val extra   = ceil(stats.backlogSecs / (redistributeDays * 3600.0)).toLong()
                val newHours = min(16.0, settings.dailyStudyHours + extra)
                settingsRepo.upsert(settings.copy(dailyStudyHours = newHours.toDouble()))
                subjects.forEach { sub ->
                    subjectRepo.update(sub.copy(dailyHours = min(16.0, sub.dailyHours + extra.toDouble())))
                }
                "Extra ${extra}h/day added for $redistributeDays days to catch up"
            }

            Strategy.ACKNOWLEDGE -> "Backlog acknowledged — rescheduled forward"
        }

        // Core fix (matches HTML comment):
        // Wipe past SCHEDULED entries for incomplete lectures so backlogSecs resets.
        // Completed lectures' entries are kept (heatmap history preserved).
        val incompleteLecIds = lectureRepo.getAll()
            .filter { it.status != LectureStatus.COMPLETE }
            .map { it.id }

        scheduleRepo.deletePastIncompleteForLectures(incompleteLecIds, today)

        // Rebuild
        statsEngine.invalidate()
        schedulerEngine.buildSchedule(forceRebuildToday = true)

        message
    }
}
