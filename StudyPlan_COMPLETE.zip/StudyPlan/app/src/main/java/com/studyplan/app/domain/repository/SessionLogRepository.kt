package com.studyplan.app.domain.repository
import com.studyplan.app.domain.model.SessionLog

interface SessionLogRepository {
    suspend fun getAll(): List<SessionLog>
    suspend fun insert(log: SessionLog)
    suspend fun insertAll(logs: List<SessionLog>)
    suspend fun pruneToLimit(maxCount: Int)
    suspend fun deleteAll()
}
