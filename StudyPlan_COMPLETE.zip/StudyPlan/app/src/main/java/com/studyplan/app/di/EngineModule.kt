package com.studyplan.app.di

import com.studyplan.app.domain.engine.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Hilt module providing all Phase 3 engine singletons.
 * Engines are @Singleton so their state (caches, undo queue) persists
 * across screen navigations within a process lifetime.
 *
 * Note: All engines use @Inject constructors so this module is minimal —
 * Hilt auto-creates them. The module only needs to exist to confirm
 * SingletonComponent scope for each.
 */
@Module
@InstallIn(SingletonComponent::class)
object EngineModule {
    // All engines use @Inject constructor + @Singleton — Hilt handles creation.
    // This module is a placeholder for any future manual @Provides bindings
    // (e.g. if an engine needs a non-injectable parameter like a Config object).
}
