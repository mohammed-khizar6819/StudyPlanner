@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.notes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studyplan.app.domain.engine.TimeUtils
import com.studyplan.app.domain.model.*
import com.studyplan.app.domain.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// ── Enriched note with resolved lecture + subject ─────────────────
data class NoteItem(
    val note:    Note,
    val lecture: Lecture,
    val subject: Subject,
)

data class NotesUiState(
    val isLoading:    Boolean          = true,
    val allItems:     List<NoteItem>   = emptyList(),
    val filtered:     List<NoteItem>   = emptyList(),
    val subjects:     List<Subject>    = emptyList(),
    val lectures:     List<Lecture>    = emptyList(),
    val filterSubId:  String?          = null,
    val filterType:   NoteType?        = null,
)

@HiltViewModel
class NotesViewModel @Inject constructor(
    private val noteRepo:    NoteRepository,
    private val lectureRepo: LectureRepository,
    private val subjectRepo: SubjectRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(NotesUiState())
    val state: StateFlow<NotesUiState> = _state.asStateFlow()

    private val _toast = MutableSharedFlow<String>()
    val toast: SharedFlow<String> = _toast.asSharedFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            val subjects  = subjectRepo.getAll()
            val lectures  = lectureRepo.getAll()
            val notes     = noteRepo.getAll()
            val lecMap    = lectures.associateBy { it.id }
            val subMap    = subjects.associateBy { it.id }

            val items = notes.mapNotNull { note ->
                val lec = lecMap[note.lectureId] ?: return@mapNotNull null
                val sub = subMap[lec.subjectId]  ?: return@mapNotNull null
                NoteItem(note, lec, sub)
            }

            val cur = _state.value
            _state.update {
                it.copy(
                    isLoading = false,
                    allItems  = items,
                    filtered  = applyFilter(items, cur.filterSubId, cur.filterType),
                    subjects  = subjects,
                    lectures  = lectures,
                )
            }
        }
    }

    fun setFilterSubject(subId: String?) {
        _state.update {
            it.copy(filterSubId = subId,
                filtered = applyFilter(it.allItems, subId, it.filterType))
        }
    }

    fun setFilterType(type: NoteType?) {
        _state.update {
            it.copy(filterType = type,
                filtered = applyFilter(it.allItems, it.filterSubId, type))
        }
    }

    fun addNote(lectureId: String, text: String, type: NoteType) {
        viewModelScope.launch {
            if (text.isBlank()) { _toast.emit("Note cannot be empty"); return@launch }
            noteRepo.insert(Note(
                id        = "note_${System.currentTimeMillis()}",
                lectureId = lectureId,
                text      = text.trim(),
                type      = type,
                createdAt = TimeUtils.today(),
                resolved  = false,
            ))
            _toast.emit("Note saved!")
            load()
        }
    }

    fun toggleResolved(noteId: String, lectureId: String, current: Boolean) {
        viewModelScope.launch {
            noteRepo.setResolved(noteId, !current)
            load()
        }
    }

    fun deleteNote(noteId: String) {
        viewModelScope.launch {
            noteRepo.delete(noteId)
            _toast.emit("Note deleted")
            load()
        }
    }

    private fun applyFilter(
        items:   List<NoteItem>,
        subId:   String?,
        type:    NoteType?,
    ): List<NoteItem> = items.filter { item ->
        (subId == null || item.subject.id == subId) &&
        (type  == null || item.note.type  == type)
    }.sortedByDescending { it.note.createdAt }
}
