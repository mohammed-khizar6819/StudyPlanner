package com.studyplan.app.data.repository
import com.studyplan.app.data.db.dao.MetaDao
import com.studyplan.app.data.db.entity.MetaEntity
import com.studyplan.app.domain.model.AppMeta
import com.studyplan.app.domain.repository.MetaRepository
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MetaRepositoryImpl @Inject constructor(
    private val dao: MetaDao,
) : MetaRepository {
    override fun observe()                           = dao.observe().map { it?.toDomain() }
    override suspend fun get()                       = dao.get()?.toDomain()
    override suspend fun upsert(m: AppMeta)          = dao.upsert(MetaEntity.fromDomain(m))
    override suspend fun updateLastBuiltDate(d: String) = dao.updateLastBuiltDate(d)
    override suspend fun setOnboarded()              = dao.setOnboarded()
    override suspend fun deleteAll()                 = dao.deleteAll()
}
