package com.studyplan.app.domain.model

/**
 * One slot in the schedule for a specific date.
 * In the HTML: schedule[date] = [{ lectureId, subjectId, plannedSeconds, ... }]
 */
data class ScheduleEntry(
    val id:               Long,          // auto-generated Room primary key
    val date:             String,        // YYYY-MM-DD
    val lectureId:        String,
    val subjectId:        String,
    val plannedSeconds:   Long,
    val completedSeconds: Long,          // 0 until session is logged
    val status:           ScheduleEntryStatus,
)
