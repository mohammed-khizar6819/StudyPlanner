@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.onboarding

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studyplan.app.domain.engine.SchedulerEngine
import com.studyplan.app.domain.engine.TimeUtils
import com.studyplan.app.domain.model.*
import com.studyplan.app.domain.repository.*
import com.studyplan.app.data.db.DatabaseInitializer
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class OnboardingViewModel @Inject constructor(
    private val dbInitializer:   DatabaseInitializer,
    private val settingsRepo:    SettingsRepository,
    private val metaRepo:        MetaRepository,
    private val subjectRepo:     SubjectRepository,
    private val schedulerEngine: SchedulerEngine,
) : ViewModel() {

    /** True = show onboarding, False = go to main app */
    private val _showOnboarding = MutableStateFlow<Boolean?>(null) // null = loading
    val showOnboarding: StateFlow<Boolean?> = _showOnboarding.asStateFlow()

    init {
        viewModelScope.launch {
            val needsOnboarding = dbInitializer.initIfNeeded()
            _showOnboarding.value = needsOnboarding
        }
    }

    fun completeOnboarding(
        subjectName:     String,
        subjectCode:     String,
        startDate:       String,
        deadline:        String,
        dailyHours:      Double,
        bufferDayOfWeek: Int,
    ) {
        viewModelScope.launch {
            val today = TimeUtils.today()

            // Update settings
            val settings = settingsRepo.get() ?: return@launch
            settingsRepo.upsert(settings.copy(
                startDate        = startDate,
                dailyStudyHours  = dailyHours,
                bufferDayOfWeek  = bufferDayOfWeek,
            ))

            // Create first subject
            val subjectId = "sub_${System.currentTimeMillis()}"
            subjectRepo.insert(Subject(
                id              = subjectId,
                name            = subjectCode,
                fullName        = subjectName,
                deadline        = deadline,
                examDate        = "",
                dailyHours      = dailyHours,
                priority        = 1,
                color           = "#374151",
                createdAt       = today,
                revisionEnabled = false,
                revisionRound   = 0,
            ))

            // Mark onboarded + build schedule
            metaRepo.setOnboarded()
            schedulerEngine.buildSchedule(forceRebuildToday = true)

            _showOnboarding.value = false
        }
    }
}
