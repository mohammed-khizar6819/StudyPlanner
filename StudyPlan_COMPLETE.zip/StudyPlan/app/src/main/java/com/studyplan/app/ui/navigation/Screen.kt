package com.studyplan.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Style
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.ui.graphics.vector.ImageVector

// ═══════════════════════════════════════════════════════════════════
//  NAVIGATION DESTINATIONS
//  All 10 screens from the HTML sidebar, mapped to typed routes.
//  Keyboard shortcut keys are stored here for the gesture-hints sheet.
// ═══════════════════════════════════════════════════════════════════

sealed class Screen(
    val route: String,
    val label: String,
    val icon: ImageVector,
    val shortcutKey: String,  // from HTML keyboard shortcuts
) {
    data object Dashboard : Screen(
        route       = "dashboard",
        label       = "Dashboard",
        icon        = Icons.Outlined.GridView,
        shortcutKey = "D",
    )
    data object Today : Screen(
        route       = "today",
        label       = "Today's Plan",
        icon        = Icons.Outlined.DateRange,
        shortcutKey = "T",
    )
    data object Subjects : Screen(
        route       = "subjects",
        label       = "Subjects",
        icon        = Icons.Outlined.MenuBook,
        shortcutKey = "S",
    )
    data object Lectures : Screen(
        route       = "lectures",
        label       = "Lectures",
        icon        = Icons.Outlined.School,
        shortcutKey = "L",
    )
    data object Analytics : Screen(
        route       = "analytics",
        label       = "Analytics",
        icon        = Icons.Outlined.BarChart,
        shortcutKey = "A",
    )
    data object Notes : Screen(
        route       = "notes",
        label       = "Notes & Doubts",
        icon        = Icons.Outlined.Description,
        shortcutKey = "N",
    )
    data object Timer : Screen(
        route       = "timer",
        label       = "Timer",
        icon        = Icons.Outlined.Timer,
        shortcutKey = "P",
    )
    data object Calendar : Screen(
        route       = "calendar",
        label       = "Calendar",
        icon        = Icons.Outlined.CalendarMonth,
        shortcutKey = "C",
    )
    data object Flashcards : Screen(
        route       = "flashcards",
        label       = "Flashcards",
        icon        = Icons.Outlined.Style,
        shortcutKey = "F",
    )
    data object Settings : Screen(
        route       = "settings",
        label       = "Settings",
        icon        = Icons.Outlined.Settings,
        shortcutKey = "",
    )

    companion object {
        val all: List<Screen> = listOf(
            Dashboard, Today, Subjects, Lectures, Analytics,
            Notes, Timer, Calendar, Flashcards, Settings,
        )

        // Screens shown in the primary nav section (above divider)
        val primary: List<Screen> = listOf(
            Dashboard, Today, Subjects, Lectures, Analytics,
            Notes, Timer, Calendar, Flashcards,
        )

        // Screens in the utility section (below divider)
        val utility: List<Screen> = listOf(Settings)
    }
}
