package com.studyplan.app.data.repository
import com.studyplan.app.data.db.dao.SavedPlanDao
import com.studyplan.app.data.db.entity.SavedPlanEntity
import com.studyplan.app.domain.model.SavedPlan
import com.studyplan.app.domain.repository.SavedPlanRepository
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SavedPlanRepositoryImpl @Inject constructor(
    private val dao: SavedPlanDao,
) : SavedPlanRepository {
    override fun observeAll()                   = dao.observeAll().map { it.map { e -> e.toDomain() } }
    override suspend fun getAll()               = dao.getAll().map { it.toDomain() }
    override suspend fun getById(id: String)    = dao.getById(id)?.toDomain()
    override suspend fun insert(p: SavedPlan)   = dao.insert(SavedPlanEntity.fromDomain(p))
    override suspend fun delete(id: String)     = dao.deleteById(id)
    override suspend fun deleteAll()            = dao.deleteAll()
}
