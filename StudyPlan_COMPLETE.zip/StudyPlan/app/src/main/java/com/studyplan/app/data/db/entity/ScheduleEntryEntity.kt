package com.studyplan.app.data.db.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.studyplan.app.domain.model.ScheduleEntry
import com.studyplan.app.domain.model.ScheduleEntryStatus

@Entity(
    tableName = "schedule_entries",
    indices   = [Index("date"), Index("lectureId"), Index("subjectId")],
)
data class ScheduleEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date:             String,
    val lectureId:        String,
    val subjectId:        String,
    val plannedSeconds:   Long,
    val completedSeconds: Long,
    val status:           ScheduleEntryStatus,
) {
    fun toDomain() = ScheduleEntry(id, date, lectureId, subjectId,
        plannedSeconds, completedSeconds, status)
    companion object {
        fun fromDomain(e: ScheduleEntry) = ScheduleEntryEntity(
            e.id, e.date, e.lectureId, e.subjectId,
            e.plannedSeconds, e.completedSeconds, e.status)
    }
}
