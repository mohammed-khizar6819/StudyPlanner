package com.studyplan.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.googlefonts.Font
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.unit.sp
import com.studyplan.app.R

// ═══════════════════════════════════════════════════════════════════
//  GOOGLE FONTS PROVIDER
//  Uses ui-text-google-fonts — fonts downloaded at runtime via GMS.
//  Falls back to system sans-serif gracefully if download fails.
// ═══════════════════════════════════════════════════════════════════

@androidx.compose.ui.text.ExperimentalTextApi
val GoogleFontsProvider = GoogleFont.Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage   = "com.google.android.gms",
    certificates      = R.array.com_google_android_gms_fonts_certs,
)

// ═══════════════════════════════════════════════════════════════════
//  FONT FAMILIES
//  HTML mapping:
//    --head = Bricolage Grotesque  (display, headlines, titles)
//    --body = Figtree              (all body / label text)
//    --mono = JetBrains Mono       (durations, dates, code)
// ═══════════════════════════════════════════════════════════════════

@androidx.compose.ui.text.ExperimentalTextApi
val BricolageGrotesque: FontFamily = FontFamily(
    Font(googleFont = GoogleFont("Bricolage Grotesque"), fontProvider = GoogleFontsProvider, weight = FontWeight.Normal),
    Font(googleFont = GoogleFont("Bricolage Grotesque"), fontProvider = GoogleFontsProvider, weight = FontWeight.Medium),
    Font(googleFont = GoogleFont("Bricolage Grotesque"), fontProvider = GoogleFontsProvider, weight = FontWeight.SemiBold),
    Font(googleFont = GoogleFont("Bricolage Grotesque"), fontProvider = GoogleFontsProvider, weight = FontWeight.Bold),
    Font(googleFont = GoogleFont("Bricolage Grotesque"), fontProvider = GoogleFontsProvider, weight = FontWeight.ExtraBold),
)

@androidx.compose.ui.text.ExperimentalTextApi
val Figtree: FontFamily = FontFamily(
    Font(googleFont = GoogleFont("Figtree"), fontProvider = GoogleFontsProvider, weight = FontWeight.Light),
    Font(googleFont = GoogleFont("Figtree"), fontProvider = GoogleFontsProvider, weight = FontWeight.Normal),
    Font(googleFont = GoogleFont("Figtree"), fontProvider = GoogleFontsProvider, weight = FontWeight.Medium),
    Font(googleFont = GoogleFont("Figtree"), fontProvider = GoogleFontsProvider, weight = FontWeight.SemiBold),
    Font(googleFont = GoogleFont("Figtree"), fontProvider = GoogleFontsProvider, weight = FontWeight.Bold),
)

@androidx.compose.ui.text.ExperimentalTextApi
val JetBrainsMono: FontFamily = FontFamily(
    Font(googleFont = GoogleFont("JetBrains Mono"), fontProvider = GoogleFontsProvider, weight = FontWeight.Normal),
    Font(googleFont = GoogleFont("JetBrains Mono"), fontProvider = GoogleFontsProvider, weight = FontWeight.Medium),
)

// ═══════════════════════════════════════════════════════════════════
//  TYPOGRAPHY SCALE
// ═══════════════════════════════════════════════════════════════════

@androidx.compose.ui.text.ExperimentalTextApi
val StudyPlanTypography = Typography(
    displayLarge = TextStyle(
        fontFamily    = BricolageGrotesque,
        fontWeight    = FontWeight.ExtraBold,
        fontSize      = 40.sp,
        lineHeight    = 44.sp,
        letterSpacing = (-2.8).sp,
    ),
    headlineLarge = TextStyle(
        fontFamily    = BricolageGrotesque,
        fontWeight    = FontWeight.Bold,
        fontSize      = 22.sp,
        lineHeight    = 28.sp,
        letterSpacing = (-0.66).sp,
    ),
    headlineMedium = TextStyle(
        fontFamily    = BricolageGrotesque,
        fontWeight    = FontWeight.Bold,
        fontSize      = 18.sp,
        lineHeight    = 24.sp,
        letterSpacing = (-0.45).sp,
    ),
    headlineSmall = TextStyle(
        fontFamily    = BricolageGrotesque,
        fontWeight    = FontWeight.Bold,
        fontSize      = 16.sp,
        lineHeight    = 22.sp,
        letterSpacing = (-0.32).sp,
    ),
    titleLarge = TextStyle(
        fontFamily    = BricolageGrotesque,
        fontWeight    = FontWeight.SemiBold,
        fontSize      = 17.sp,
        lineHeight    = 22.sp,
        letterSpacing = (-0.51).sp,
    ),
    titleMedium = TextStyle(
        fontFamily    = Figtree,
        fontWeight    = FontWeight.SemiBold,
        fontSize      = 14.sp,
        lineHeight    = 20.sp,
        letterSpacing = (-0.21).sp,
    ),
    titleSmall = TextStyle(
        fontFamily    = Figtree,
        fontWeight    = FontWeight.SemiBold,
        fontSize      = 13.sp,
        lineHeight    = 18.sp,
        letterSpacing = 0.sp,
    ),
    bodyLarge = TextStyle(
        fontFamily    = Figtree,
        fontWeight    = FontWeight.Normal,
        fontSize      = 14.sp,
        lineHeight    = 21.7.sp,
        letterSpacing = 0.sp,
    ),
    bodyMedium = TextStyle(
        fontFamily    = Figtree,
        fontWeight    = FontWeight.Normal,
        fontSize      = 13.sp,
        lineHeight    = 20.sp,
        letterSpacing = 0.sp,
    ),
    bodySmall = TextStyle(
        fontFamily    = Figtree,
        fontWeight    = FontWeight.Normal,
        fontSize      = 12.sp,
        lineHeight    = 18.sp,
        letterSpacing = 0.sp,
    ),
    labelLarge = TextStyle(
        fontFamily    = Figtree,
        fontWeight    = FontWeight.Medium,
        fontSize      = 13.sp,
        lineHeight    = 18.sp,
        letterSpacing = 0.sp,
    ),
    labelMedium = TextStyle(
        fontFamily    = Figtree,
        fontWeight    = FontWeight.Medium,
        fontSize      = 12.sp,
        lineHeight    = 16.sp,
        letterSpacing = 0.sp,
    ),
    labelSmall = TextStyle(
        fontFamily    = Figtree,
        fontWeight    = FontWeight.Bold,
        fontSize      = 10.sp,
        lineHeight    = 14.sp,
        letterSpacing = 1.0.sp,
    ),
)

// ── Mono convenience styles ───────────────────────────────────────
@androidx.compose.ui.text.ExperimentalTextApi
val MonoTextStyle = TextStyle(
    fontFamily    = JetBrainsMono,
    fontWeight    = FontWeight.Normal,
    fontSize      = 13.sp,
    lineHeight    = 20.sp,
    letterSpacing = 0.sp,
)

@androidx.compose.ui.text.ExperimentalTextApi
val MonoTextStyleSmall = TextStyle(
    fontFamily    = JetBrainsMono,
    fontWeight    = FontWeight.Normal,
    fontSize      = 11.sp,
    lineHeight    = 16.sp,
    letterSpacing = 0.sp,
)

// ── Non-experimental aliases for use in non-annotated composables ──
// These are safe to use without @OptIn since the font resolution falls
// back to system fonts if download fails (no crash path).
@Suppress("OPT_IN_USAGE")
val HeadingFontFamily: FontFamily get() = BricolageGrotesque
@Suppress("OPT_IN_USAGE")
val BodyFontFamily: FontFamily get() = Figtree
@Suppress("OPT_IN_USAGE")
val MonoFontFamily: FontFamily get() = JetBrainsMono
