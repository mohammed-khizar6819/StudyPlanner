package com.studyplan.app.data.db

import androidx.room.TypeConverter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import com.studyplan.app.domain.model.LectureDifficulty
import com.studyplan.app.domain.model.LectureStatus
import com.studyplan.app.domain.model.LectureTag
import com.studyplan.app.domain.model.NoteType
import com.studyplan.app.domain.model.ScheduleEntryStatus

/**
 * Room TypeConverters — handle all non-primitive field types.
 * Lists are stored as JSON arrays; enums are stored as their string value.
 */
class Converters {

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val stringListType = Types.newParameterizedType(List::class.java, String::class.java)
    private val stringListAdapter = moshi.adapter<List<String>>(stringListType)

    // ── String lists (vacationDates, achievedMilestones, tags) ────
    @TypeConverter fun fromStringList(list: List<String>): String =
        stringListAdapter.toJson(list)

    @TypeConverter fun toStringList(json: String): List<String> =
        runCatching { stringListAdapter.fromJson(json) ?: emptyList() }.getOrDefault(emptyList())

    // ── LectureStatus ─────────────────────────────────────────────
    @TypeConverter fun fromLectureStatus(status: LectureStatus): String = status.value
    @TypeConverter fun toLectureStatus(value: String): LectureStatus   = LectureStatus.from(value)

    // ── ScheduleEntryStatus ───────────────────────────────────────
    @TypeConverter fun fromEntryStatus(status: ScheduleEntryStatus): String = status.value
    @TypeConverter fun toEntryStatus(value: String): ScheduleEntryStatus   = ScheduleEntryStatus.from(value)

    // ── NoteType ──────────────────────────────────────────────────
    @TypeConverter fun fromNoteType(type: NoteType): String = type.value
    @TypeConverter fun toNoteType(value: String): NoteType = NoteType.from(value)

    // ── LectureDifficulty ─────────────────────────────────────────
    @TypeConverter fun fromDifficulty(d: LectureDifficulty): String = d.value
    @TypeConverter fun toDifficulty(value: String): LectureDifficulty = LectureDifficulty.from(value)

    // ── LectureTag list ───────────────────────────────────────────
    @TypeConverter fun fromTagList(tags: List<LectureTag>): String =
        stringListAdapter.toJson(tags.map { it.value })

    @TypeConverter fun toTagList(json: String): List<LectureTag> =
        toStringList(json).mapNotNull { LectureTag.from(it) }
}
