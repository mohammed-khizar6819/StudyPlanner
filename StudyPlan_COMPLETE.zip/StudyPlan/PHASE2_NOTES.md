# Phase 2 — Data Layer Summary

## What was built

### Domain Models (11 files)
| File | Purpose |
|---|---|
| `LectureStatus.kt` | pending / partial / complete — mirrors HTML string values |
| `ScheduleEntryStatus.kt` | scheduled / done / partial_done |
| `NoteType.kt` | note / doubt / key |
| `LectureTag.kt` | hw / nm / th / im — with display labels |
| `LectureDifficulty.kt` | easy / medium / hard — with spaced-rep weights |
| `Subject.kt` | Full subject domain model |
| `Lecture.kt` | Full lecture domain model |
| `ScheduleEntry.kt` | One schedule slot per date per lecture |
| `Note.kt` | Note/doubt/key attached to a lecture |
| `SessionLog.kt` | One study session event (for TOD heatmap) |
| `AppSettings.kt` | All 16 settings fields, exact match to HTML |
| `AppMeta.kt` | initialized, version, lastBuiltDate, onboarded, milestones |
| `SavedPlan.kt` | Named snapshot with full snapshotJson |

### Room Database
- `AppDatabase.kt` — 8 entities, version 1, schema exported to `app/schemas/`
- `Converters.kt` — TypeConverters for all enums + List<String> + List<LectureTag>

### 8 Entities (exact DB column mapping)
`SubjectEntity`, `LectureEntity`, `ScheduleEntryEntity`, `NoteEntity`,
`SessionLogEntity`, `SettingsEntity` (single-row), `MetaEntity` (single-row),
`SavedPlanEntity`

### 8 DAOs (complete query coverage)
All CRUD + every query needed by the Scheduler and Stats engines in Phase 3.

### 8 Repository Interfaces + 8 Implementations
Clean architecture — engines depend on interfaces, not Room directly.

### JSON Backup System
- `StudyPlanBackup.kt` — Moshi `@JsonClass` models matching `studyPlanner_v3`
  HTML format exactly (same field names, same structure)
- `BackupMapper.kt` — bidirectional `toBackup()` / `fromBackup()` conversion
  Used by: JSON export, JSON import, multi-plan save/load, PDF report

### Hilt DI
- `DatabaseModule.kt` — provides `AppDatabase` + all 8 DAOs
- `RepositoryModule.kt` — `@Binds` all 8 interface → implementation pairs

### Initialization
- `DatabaseInitializer.kt` — mirrors `Store.init()`:
  - Fresh install: seeds default `AppSettings` + `AppMeta`
  - Existing data: applies version migrations
  - Returns `true` if onboarding is needed

### Unit Tests
- `ConvertersTest.kt` — roundtrip tests for all TypeConverters + edge cases
- `BackupMapperTest.kt` — toBackup/fromBackup roundtrips, grouping logic,
  empty backup handling

## JSON Cross-Compatibility

The `StudyPlanBackup` JSON structure is identical to the HTML's
`studyPlanner_v3` localStorage format. A user can:
1. Export JSON from the web app
2. Import it into the Android app (and vice versa)

Key field names that must not change: `settings`, `subjects`, `lectures`,
`schedule`, `notes`, `sessionLogs`, `meta`, `startDate`, `bufferDayOfWeek`,
`dailyStudyHours`, `plannedSeconds`, `completedSeconds`, `todayStudied`,
`revisionEnabled`, `revisionRound`, `vacationDates`, `achievedMilestones`.

## Next: Phase 3 — Core Engine

Implements (all in `domain/engine/`):
- `TimeUtils.kt` — local-date aware (critical for UTC+5:30)
- `SchedulerEngine.kt` — full buildSchedule() with all 6 modes
- `StatsEngine.kt` — getStats() + getWeeklyStats() with cache
- `BacklogHandler.kt` — 4 strategies
- `ConsistencyScore.kt` — streak × completion rate formula
- `ReportCard.kt` — weekly report data + share text
- `UndoManager.kt` — 5.5s expiry
- `MultiPlanManager.kt` — snapshot save/load/delete

All with unit tests.
