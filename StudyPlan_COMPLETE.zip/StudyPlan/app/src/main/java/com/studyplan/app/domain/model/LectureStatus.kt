package com.studyplan.app.domain.model

/** Mirrors the HTML status strings: "pending" | "partial" | "complete" */
enum class LectureStatus(val value: String) {
    PENDING("pending"),
    PARTIAL("partial"),
    COMPLETE("complete");
    companion object {
        fun from(value: String) = entries.firstOrNull { it.value == value } ?: PENDING
    }
}
