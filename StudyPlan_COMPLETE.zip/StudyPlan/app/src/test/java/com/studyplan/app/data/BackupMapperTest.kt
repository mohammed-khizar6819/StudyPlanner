package com.studyplan.app.data

import com.studyplan.app.data.db.entity.*
import com.studyplan.app.data.json.BackupMapper
import com.studyplan.app.data.json.BackupMeta
import com.studyplan.app.data.json.BackupSettings
import com.studyplan.app.data.json.StudyPlanBackup
import com.studyplan.app.domain.model.*
import org.junit.Assert.*
import org.junit.Test

class BackupMapperTest {

    private val today = "2024-06-01"

    private fun makeSettings() = SettingsEntity(1, today, 6.0, 0, 0.0,
        false, false, 4.0, 8.0, 7, false, 8, 0, false, 9, emptyList())

    private fun makeMeta() = MetaEntity(1, true, 5, today, true, emptyList())

    private fun makeSubject(id: String = "sub_1") = SubjectEntity(
        id, "FR", "Financial Reporting", "", "", 6.0, 1, "#374151", today, false, 0)

    private fun makeLecture(id: String = "lec_1", subjectId: String = "sub_1") = LectureEntity(
        id, subjectId, 1, "01", "Basics", 5400L, 5400L,
        LectureStatus.PENDING, null, 0L, null, "Chapter 1",
        listOf(LectureTag.HIGH_WEIGHTAGE), LectureDifficulty.MEDIUM)

    @Test fun `toBackup produces correct subject count`() {
        val backup = BackupMapper.toBackup(
            makeSettings(), makeMeta(), listOf(makeSubject(), makeSubject("sub_2")),
            emptyList(), emptyList(), emptyList(), emptyList()
        )
        assertEquals(2, backup.subjects.size)
    }

    @Test fun `toBackup schedule groups by date correctly`() {
        val entries = listOf(
            ScheduleEntryEntity(1, "2024-06-01", "lec_1", "sub_1", 3600L, 0L, ScheduleEntryStatus.SCHEDULED),
            ScheduleEntryEntity(2, "2024-06-01", "lec_2", "sub_1", 1800L, 0L, ScheduleEntryStatus.SCHEDULED),
            ScheduleEntryEntity(3, "2024-06-02", "lec_3", "sub_1", 3600L, 0L, ScheduleEntryStatus.DONE),
        )
        val backup = BackupMapper.toBackup(makeSettings(), makeMeta(), emptyList(),
            emptyList(), entries, emptyList(), emptyList())
        assertEquals(2, backup.schedule.keys.size)
        assertEquals(2, backup.schedule["2024-06-01"]?.size)
        assertEquals(1, backup.schedule["2024-06-02"]?.size)
    }

    @Test fun `toBackup notes grouped by lectureId`() {
        val notes = listOf(
            NoteEntity("n1", "lec_1", "Note A", NoteType.NOTE, today, false),
            NoteEntity("n2", "lec_1", "Note B", NoteType.KEY,  today, false),
            NoteEntity("n3", "lec_2", "Doubt",  NoteType.DOUBT, today, false),
        )
        val backup = BackupMapper.toBackup(makeSettings(), makeMeta(), emptyList(),
            emptyList(), emptyList(), notes, emptyList())
        assertEquals(2, backup.notes.keys.size)
        assertEquals(2, backup.notes["lec_1"]?.size)
        assertEquals(1, backup.notes["lec_2"]?.size)
    }

    @Test fun `fromBackup roundtrip preserves lecture tags`() {
        val backup = BackupMapper.toBackup(
            makeSettings(), makeMeta(),
            listOf(makeSubject()),
            listOf(makeLecture()),
            emptyList(), emptyList(), emptyList()
        )
        val restored = BackupMapper.fromBackup(backup)
        val lecture = restored.lectures.first()
        assertEquals(listOf(LectureTag.HIGH_WEIGHTAGE), lecture.tags)
    }

    @Test fun `fromBackup restores settings correctly`() {
        val settings = makeSettings().copy(dailyStudyHours = 8.0, bufferDayOfWeek = 6)
        val backup = BackupMapper.toBackup(settings, makeMeta(),
            emptyList(), emptyList(), emptyList(), emptyList(), emptyList())
        val restored = BackupMapper.fromBackup(backup)
        assertEquals(8.0, restored.settings.dailyStudyHours, 0.001)
        assertEquals(6, restored.settings.bufferDayOfWeek)
    }

    @Test fun `fromBackup handles empty backup gracefully`() {
        val emptyBackup = StudyPlanBackup(
            BackupSettings(today, 6.0, 0),
            emptyList(), emptyList(), emptyMap(), emptyMap(),
            emptyList(), BackupMeta()
        )
        val restored = BackupMapper.fromBackup(emptyBackup)
        assertTrue(restored.subjects.isEmpty())
        assertTrue(restored.lectures.isEmpty())
        assertTrue(restored.entries.isEmpty())
    }
}
