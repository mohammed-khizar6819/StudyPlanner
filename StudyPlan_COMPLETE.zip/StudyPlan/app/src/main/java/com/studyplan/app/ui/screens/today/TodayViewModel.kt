package com.studyplan.app.ui.screens.today

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studyplan.app.domain.engine.*
import com.studyplan.app.domain.model.*
import com.studyplan.app.domain.repository.*
import com.studyplan.app.domain.model.NoteType
import com.studyplan.app.domain.model.Note
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class TodayUiState(
    val isLoading:    Boolean          = true,
    val entries:      List<TodayEntry> = emptyList(),
    val isRestDay:    Boolean          = false,
    val isBeforeStart: Boolean         = false,
    val dateDisplay:  String           = "",
    val dayName:      String           = "",
)

@HiltViewModel
class TodayViewModel @Inject constructor(
    private val schedulerEngine: SchedulerEngine,
    private val settingsRepo:    SettingsRepository,
    private val undoManager:     UndoManager,
    private val lectureRepo:     LectureRepository,
    private val scheduleRepo:    ScheduleRepository,
    private val noteRepo:        NoteRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(TodayUiState())
    val state: StateFlow<TodayUiState> = _state.asStateFlow()

    val undoPending: StateFlow<UndoManager.PendingAction?> = undoManager.pending

    private val _toast = MutableSharedFlow<String>()
    val toast: SharedFlow<String> = _toast.asSharedFlow()

    init { loadToday() }

    fun loadToday() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            val today     = TimeUtils.today()
            val settings  = settingsRepo.get()
            val isRest    = settings?.bufferDayOfWeek?.let {
                it != -1 && TimeUtils.dayOfWeek(today) == it
            } ?: false
            val isVacation = settings?.vacationDates?.contains(today) ?: false
            val isBefore   = (settings?.startDate ?: today) > today
            val entries    = schedulerEngine.getTodayPlan()

            _state.update {
                it.copy(
                    isLoading     = false,
                    entries       = entries,
                    isRestDay     = isRest || isVacation,
                    isBeforeStart = isBefore,
                    dateDisplay   = TimeUtils.formatDisplay(today),
                    dayName       = TimeUtils.dayName(today),
                )
            }
        }
    }

    /** Mark session done — with undo support */
    fun markDone(entry: TodayEntry) {
        viewModelScope.launch {
            // Snapshot for undo
            val snapshot      = entry.lecture.copy()
            val snapCompleted = entry.entry.completedSeconds
            val snapStatus    = entry.entry.status

            schedulerEngine.completeSession(entry.lecture.id)
            _toast.emit("Session marked done!")

            undoManager.register("Marked done") {
                // Restore lecture state
                lectureRepo.updateProgress(snapshot)
                // Restore entry status
                val today2 = TimeUtils.today()
                val entries = schedulerEngine.getTodayPlan()
                val entryToRestore = entries.find { it.lecture.id == snapshot.id }
                if (entryToRestore != null) {
                    scheduleRepo.updateCompletion(entryToRestore.entry.id, snapCompleted, snapStatus)
                }
                schedulerEngine.buildSchedule(forceRebuildToday = false)
                loadToday()
            }
            loadToday()
        }
    }

    /** Log partial time studied */
    fun logPartial(lectureId: String, seconds: Long) {
        viewModelScope.launch {
            val ok = schedulerEngine.partialComplete(lectureId, seconds)
            if (ok) {
                _toast.emit("+${TimeUtils.toDisplay(seconds)} logged!")
            } else {
                _toast.emit("Already complete")
            }
            loadToday()
        }
    }

    /** Quick-log: +15min / +30min / +1h */
    fun quickLog(entry: TodayEntry, seconds: Long) {
        viewModelScope.launch {
            val today   = TimeUtils.today()
            val prev    = if (entry.lecture.todayDate == today) entry.lecture.todayStudied else 0L
            val newTotal = prev + seconds
            val ok = schedulerEngine.partialComplete(entry.lecture.id, newTotal)
            if (ok) _toast.emit("+${TimeUtils.toDisplay(seconds)} logged!")
            else    _toast.emit("Already complete")
            loadToday()
        }
    }

    fun addQuickNote(lectureId: String, text: String, type: NoteType) {
        viewModelScope.launch {
            noteRepo.insert(Note(
                id        = "note_${System.currentTimeMillis()}",
                lectureId = lectureId,
                text      = text.trim(),
                type      = type,
                createdAt = TimeUtils.today(),
                resolved  = false,
            ))
            _toast.emit("Note saved!")
        }
    }

    fun executeUndo() {
        viewModelScope.launch {
            undoManager.execute()
            loadToday()
        }
    }
}
