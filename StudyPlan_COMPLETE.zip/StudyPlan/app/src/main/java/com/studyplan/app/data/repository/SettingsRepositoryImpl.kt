package com.studyplan.app.data.repository
import com.studyplan.app.data.db.dao.SettingsDao
import com.studyplan.app.data.db.entity.SettingsEntity
import com.studyplan.app.domain.model.AppSettings
import com.studyplan.app.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SettingsRepositoryImpl @Inject constructor(
    private val dao: SettingsDao,
) : SettingsRepository {
    override fun observe() = dao.observe().map { it?.toDomain() }
    override suspend fun get()                   = dao.get()?.toDomain()
    override suspend fun upsert(s: AppSettings)  = dao.upsert(SettingsEntity.fromDomain(s))
    override suspend fun deleteAll()             = dao.deleteAll()
}
