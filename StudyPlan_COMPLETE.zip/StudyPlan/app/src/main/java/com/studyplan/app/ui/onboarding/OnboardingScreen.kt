@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.onboarding

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.studyplan.app.domain.engine.TimeUtils
import com.studyplan.app.ui.components.*
import com.studyplan.app.ui.theme.*

// ── Onboarding steps ─────────────────────────────────────────────
private data class OnboardStep(val title: String, val desc: String)

private val STEPS = listOf(
    OnboardStep("Welcome to StudyPlan",
        "Your smart exam preparation companion. Set up your plan in 3 quick steps."),
    OnboardStep("What are you studying?",
        "Add your subject or exam name so we can track your lectures and progress."),
    OnboardStep("When do you start?",
        "Set your study start date and exam deadline to build your schedule."),
    OnboardStep("How much will you study?",
        "Set your daily study hours and weekly rest day."),
)

/**
 * Full-screen onboarding wizard shown once on first launch.
 * Matches HTML Onboarding object exactly.
 * [onComplete] is called when user finishes — passing all fields needed
 * to seed the first subject and settings.
 */
@Composable
fun OnboardingScreen(
    onComplete: (
        subjectName:  String,
        subjectCode:  String,
        startDate:    String,
        deadline:     String,
        dailyHours:   Double,
        bufferDayOfWeek: Int,
    ) -> Unit,
) {
    var step         by remember { mutableIntStateOf(0) }

    // Step 1 fields
    var subjectName  by remember { mutableStateOf("") }
    var subjectCode  by remember { mutableStateOf("") }
    // Step 2 fields
    val today        = TimeUtils.today()
    var startDate    by remember { mutableStateOf(today) }
    var deadline     by remember { mutableStateOf(TimeUtils.addDays(today, 120)) }
    // Step 3 fields
    var dailyHours   by remember { mutableStateOf("6") }
    var bufferDay    by remember { mutableIntStateOf(0) }  // Sunday

    val toast        = LocalToastHost.current

    Dialog(
        onDismissRequest = { /* non-dismissable */ },
        properties       = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress      = false,
            dismissOnClickOutside   = false,
        ),
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.studyColors.bg.copy(alpha = 0.95f)),
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.studyColors.surface)
                    .padding(28.dp),
            ) {
                val colors = MaterialTheme.studyColors

                // Step dots
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    STEPS.indices.forEach { i ->
                        Box(
                            modifier = Modifier
                                .size(if (i == step) 10.dp else 7.dp)
                                .clip(CircleShape)
                                .background(if (i == step) colors.primary else colors.border),
                        )
                    }
                }
                Spacer(Modifier.height(20.dp))

                // Title & description
                Text(STEPS[step].title, fontFamily = HeadingFontFamily,
                    fontWeight = FontWeight.Bold, fontSize = 20.sp,
                    color = colors.text, letterSpacing = (-0.6).sp,
                    textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text(STEPS[step].desc, fontFamily = BodyFontFamily,
                    fontSize = 13.sp, color = colors.text2,
                    textAlign = TextAlign.Center, lineHeight = 20.sp)
                Spacer(Modifier.height(24.dp))

                // Step body
                AnimatedContent(targetState = step, label = "step") { s ->
                    Column(modifier = Modifier.fillMaxWidth()) {
                        when (s) {
                            0 -> {
                                // Welcome — no inputs
                                Text(
                                    "Track lectures, build a daily schedule, measure your progress, and stay on top of every subject — all in one place.",
                                    fontFamily = BodyFontFamily, fontSize = 14.sp,
                                    color = colors.text2, lineHeight = 22.sp,
                                    textAlign = TextAlign.Center,
                                )
                            }
                            1 -> {
                                FieldLabel("Subject / Exam Name")
                                StudyTextField(value = subjectName,
                                    onValueChange = { subjectName = it },
                                    placeholder = "e.g. Financial Reporting")
                                Spacer(Modifier.height(12.dp))
                                FieldLabel("Short Code (optional)")
                                StudyTextField(value = subjectCode,
                                    onValueChange = { subjectCode = it.uppercase().take(10) },
                                    placeholder = "e.g. FR")
                            }
                            2 -> {
                                DatePickerField(value = startDate, onSelect = { startDate = it },
                                    label = "Study Start Date")
                                Spacer(Modifier.height(12.dp))
                                DatePickerField(value = deadline, onSelect = { deadline = it },
                                    label = "Exam Deadline")
                            }
                            3 -> {
                                FieldLabel("Daily Study Hours")
                                StudyTextField(value = dailyHours,
                                    onValueChange = { dailyHours = it },
                                    placeholder = "6",
                                    keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal)
                                Spacer(Modifier.height(12.dp))
                                FieldLabel("Weekly Rest Day")
                                val restOptions = listOf(
                                    DropdownOption(-1, "No Rest Day"),
                                    DropdownOption(0,  "Sunday"),
                                    DropdownOption(1,  "Monday"),
                                    DropdownOption(6,  "Saturday"),
                                )
                                StudyDropdown(options = restOptions, selected = bufferDay,
                                    onSelect = { bufferDay = it })
                            }
                        }
                    }
                }

                Spacer(Modifier.height(28.dp))

                // Footer buttons
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier              = Modifier.fillMaxWidth(),
                ) {
                    if (step > 0) {
                        OutlineButton("← Back", onClick = { step-- })
                    } else {
                        Spacer(Modifier.width(1.dp))
                    }
                    PrimaryButton(
                        text    = if (step == STEPS.lastIndex) "Start Planning →" else "Next →",
                        onClick = {
                            when (step) {
                                1 -> {
                                    if (subjectName.isBlank()) {
                                        toast.show("Please enter a subject name", true)
                                        return@PrimaryButton
                                    }
                                }
                                2 -> {
                                    if (deadline <= startDate) {
                                        toast.show("Deadline must be after start date", true)
                                        return@PrimaryButton
                                    }
                                }
                            }
                            if (step < STEPS.lastIndex) {
                                step++
                            } else {
                                // Complete
                                val hrs = dailyHours.toDoubleOrNull()?.coerceIn(0.5, 24.0) ?: 6.0
                                val code = subjectCode.ifBlank {
                                    subjectName.take(4).uppercase()
                                }
                                onComplete(subjectName, code, startDate, deadline, hrs, bufferDay)
                            }
                        },
                    )
                }
            }
        }
    }
}
