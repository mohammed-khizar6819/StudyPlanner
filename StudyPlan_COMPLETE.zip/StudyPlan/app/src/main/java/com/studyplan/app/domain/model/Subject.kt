package com.studyplan.app.domain.model

/**
 * Domain model — mirrors the HTML subject object exactly.
 * Stored as SubjectEntity in Room; mapped via BackupMapper for JSON I/O.
 */
data class Subject(
    val id:              String,
    val name:            String,        // short code, e.g. "FR"
    val fullName:        String,        // full name, e.g. "Financial Reporting"
    val deadline:        String,        // YYYY-MM-DD or ""
    val examDate:        String,        // YYYY-MM-DD or ""
    val dailyHours:      Double,        // hours per day allocated to this subject
    val priority:        Int,           // scheduling priority weight
    val color:           String,        // hex color string e.g. "#374151"
    val createdAt:       String,        // YYYY-MM-DD
    val revisionEnabled: Boolean,
    val revisionRound:   Int,           // 0=full 1=50% 2=25%
)
