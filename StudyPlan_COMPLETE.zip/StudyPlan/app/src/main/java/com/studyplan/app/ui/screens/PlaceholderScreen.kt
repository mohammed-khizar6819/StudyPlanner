@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyplan.app.ui.theme.BricolageGrotesque
import com.studyplan.app.ui.theme.Figtree
import com.studyplan.app.ui.theme.studyColors

/**
 * Temporary placeholder shown for screens not yet implemented.
 * Replaced phase by phase with full implementations.
 */
@Composable
fun PlaceholderScreen(title: String) {
    val colors = MaterialTheme.studyColors
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .fillMaxSize()
            .background(colors.bg)
            .padding(32.dp),
    ) {
        Text(
            text       = title,
            fontFamily = BricolageGrotesque,
            fontWeight = FontWeight.Bold,
            fontSize   = 26.sp,
            color      = colors.text,
            letterSpacing = (-0.03).sp,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text       = "Coming in a future phase",
            fontFamily = Figtree,
            fontWeight = FontWeight.Normal,
            fontSize   = 13.sp,
            color      = colors.text3,
        )
    }
}
