package com.studyplan.app.alarm

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.studyplan.app.MainActivity
import com.studyplan.app.R
import com.studyplan.app.StudyPlanApplication
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class AlarmReceiver : BroadcastReceiver() {

    @Inject lateinit var alarmScheduler: AlarmScheduler
    @Inject lateinit var settingsDataSource: SettingsRepository

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != AlarmScheduler.ACTION_ALARM) return

        // Post notification
        postAlarmNotification(context)

        // Auto-reschedule for next day using saved settings
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val settings = settingsDataSource.get()
                if (settings != null && settings.alarmEnabled) {
                    alarmScheduler.rescheduleNextDay(settings.alarmHour, settings.alarmMinute)
                }
            } finally {
                pending.finish()
            }
        }
    }

    private fun postAlarmNotification(context: Context) {
        val tapIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val tapPending = PendingIntent.getActivity(
            context, 0, tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification = NotificationCompat.Builder(context, StudyPlanApplication.CHANNEL_STUDY_ALARM)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("⏰ Study Alarm")
            .setContentText("Time to start your study session!")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(tapPending)
            .setAutoCancel(true)
            .build()
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(ALARM_NOTIFICATION_ID, notification)
    }

    companion object {
        const val ALARM_NOTIFICATION_ID = 1001
    }
}
