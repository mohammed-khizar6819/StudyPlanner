package com.studyplan.app.data.db.dao

import androidx.room.*
import com.studyplan.app.data.db.entity.ScheduleEntryEntity
import com.studyplan.app.domain.model.ScheduleEntryStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface ScheduleEntryDao {
    @Query("SELECT * FROM schedule_entries WHERE date = :date ORDER BY subjectId, lectureId")
    fun observeForDate(date: String): Flow<List<ScheduleEntryEntity>>

    @Query("SELECT * FROM schedule_entries WHERE date = :date ORDER BY subjectId, lectureId")
    suspend fun getForDate(date: String): List<ScheduleEntryEntity>

    @Query("SELECT * FROM schedule_entries WHERE date >= :start AND date <= :end ORDER BY date, subjectId")
    suspend fun getInRange(start: String, end: String): List<ScheduleEntryEntity>

    @Query("SELECT * FROM schedule_entries WHERE date < :date ORDER BY date")
    suspend fun getBeforeDate(date: String): List<ScheduleEntryEntity>

    @Query("SELECT * FROM schedule_entries WHERE lectureId = :lectureId")
    suspend fun getForLecture(lectureId: String): List<ScheduleEntryEntity>

    @Query("SELECT DISTINCT date FROM schedule_entries WHERE date >= :start ORDER BY date")
    suspend fun getDatesFrom(start: String): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: ScheduleEntryEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entries: List<ScheduleEntryEntity>)

    @Update
    suspend fun update(entry: ScheduleEntryEntity)

    @Query("UPDATE schedule_entries SET completedSeconds = :completed, status = :status WHERE id = :id")
    suspend fun updateCompletion(id: Long, completed: Long, status: ScheduleEntryStatus)

    @Query("DELETE FROM schedule_entries WHERE date = :date")
    suspend fun deleteForDate(date: String)

    @Query("DELETE FROM schedule_entries WHERE date >= :date")
    suspend fun deleteFromDate(date: String)

    @Query("DELETE FROM schedule_entries WHERE lectureId = :lectureId AND date < :today AND status != 'done'")
    suspend fun deletePastIncompleteForLecture(lectureId: String, today: String)

    @Query("DELETE FROM schedule_entries WHERE lectureId IN (:lectureIds) AND date < :today AND status != 'done'")
    suspend fun deletePastIncompleteForLectures(lectureIds: List<String>, today: String)

    @Query("DELETE FROM schedule_entries WHERE date < :date AND status = 'scheduled'")
    suspend fun deletePastUnworked(date: String)

    @Query("DELETE FROM schedule_entries")
    suspend fun deleteAll()
}
