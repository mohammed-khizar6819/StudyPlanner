@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyplan.app.ui.theme.BodyFontFamily
import com.studyplan.app.ui.theme.StudyPlanRadius
import com.studyplan.app.ui.theme.studyColors

// ═══════════════════════════════════════════════════════════════════
//  DROPDOWN FIELD — select-style control
//  Matches HTML <select class="input-field">
// ═══════════════════════════════════════════════════════════════════

data class DropdownOption<T>(val value: T, val label: String)

@Composable
fun <T> StudyDropdown(
    options:   List<DropdownOption<T>>,
    selected:  T,
    onSelect:  (T) -> Unit,
    modifier:  Modifier = Modifier,
    label:     String?  = null,
) {
    val colors      = MaterialTheme.studyColors
    var expanded    by remember { mutableStateOf(false) }
    val selectedLabel = options.find { it.value == selected }?.label ?: "—"

    if (label != null) FieldLabel(label)

    Box(modifier = modifier) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(StudyPlanRadius.md))
                .background(colors.surface)
                .border(1.dp, colors.border, RoundedCornerShape(StudyPlanRadius.md))
                .clickable(
                    indication        = null,
                    interactionSource = remember { MutableInteractionSource() },
                    onClick           = { expanded = true },
                )
                .padding(horizontal = 12.dp, vertical = 9.dp),
        ) {
            Text(
                text       = selectedLabel,
                fontFamily = BodyFontFamily,
                fontSize   = 13.sp,
                color      = colors.text,
                modifier   = Modifier.weight(1f),
            )
            Icon(Icons.Outlined.KeyboardArrowDown, null,
                tint = colors.text3, modifier = Modifier.size(16.dp))
        }

        DropdownMenu(
            expanded         = expanded,
            onDismissRequest = { expanded = false },
            modifier         = Modifier.background(colors.surface),
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = {
                        Text(option.label, fontFamily = BodyFontFamily, fontSize = 13.sp,
                            fontWeight = if (option.value == selected) FontWeight.SemiBold else FontWeight.Normal,
                            color = colors.text)
                    },
                    onClick = {
                        onSelect(option.value)
                        expanded = false
                    },
                )
            }
        }
    }
}
