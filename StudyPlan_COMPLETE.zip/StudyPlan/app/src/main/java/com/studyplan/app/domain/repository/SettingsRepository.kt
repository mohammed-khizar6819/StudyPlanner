package com.studyplan.app.domain.repository
import com.studyplan.app.domain.model.AppSettings
import kotlinx.coroutines.flow.Flow

interface SettingsRepository {
    fun observe(): Flow<AppSettings?>
    suspend fun get(): AppSettings?
    suspend fun upsert(settings: AppSettings)
    suspend fun deleteAll()
}
