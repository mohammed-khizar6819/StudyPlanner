@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.components.dialog

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.studyplan.app.ui.animation.modalUpEnter
import com.studyplan.app.ui.animation.modalUpExit
import com.studyplan.app.ui.components.DangerButton
import com.studyplan.app.ui.components.OutlineButton
import com.studyplan.app.ui.components.PrimaryButton
import com.studyplan.app.ui.theme.HeadingFontFamily
import com.studyplan.app.ui.theme.BodyFontFamily
import com.studyplan.app.ui.theme.StudyPlanRadius
import com.studyplan.app.ui.theme.studyColors

@Composable
fun StudyPlanDialog(
    visible:    Boolean,
    title:      String,
    onDismiss:  () -> Unit,
    wide:       Boolean = false,
    footer:     @Composable RowScope.() -> Unit = {},
    content:    @Composable ColumnScope.() -> Unit,
) {
    if (!visible) return
    val colors = MaterialTheme.studyColors

    Dialog(
        onDismissRequest = onDismiss,
        properties       = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        AnimatedVisibility(visible = visible, enter = modalUpEnter(), exit = modalUpExit()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(if (wide) 0.96f else 0.92f)
                    .wrapContentHeight()
                    .clip(RoundedCornerShape(StudyPlanRadius.lg))
                    .background(colors.surface)
                    .border(1.dp, colors.border, RoundedCornerShape(StudyPlanRadius.lg)),
            ) {
                // Header
                Text(
                    text       = title,
                    fontFamily = HeadingFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize   = 16.sp,
                    color      = colors.text,
                    letterSpacing = (-0.4).sp,
                    modifier   = Modifier.fillMaxWidth()
                        .padding(horizontal = 22.dp, vertical = 18.dp),
                )
                HorizontalDivider(color = colors.border, thickness = 1.dp)

                // Body
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 22.dp, vertical = 18.dp),
                    content = content,
                )
                HorizontalDivider(color = colors.border, thickness = 1.dp)

                // Footer
                Row(
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.fillMaxWidth()
                        .padding(horizontal = 22.dp, vertical = 14.dp),
                    content = footer,
                )
            }
        }
    }
}

@Composable
fun ConfirmDialog(
    visible:     Boolean,
    title:       String,
    message:     String,
    confirmText: String  = "Confirm",
    cancelText:  String  = "Cancel",
    destructive: Boolean = false,
    onConfirm:   () -> Unit,
    onDismiss:   () -> Unit,
) {
    StudyPlanDialog(
        visible   = visible,
        title     = title,
        onDismiss = onDismiss,
        footer    = {
            OutlineButton(cancelText, onClick = onDismiss)
            Spacer(Modifier.width(8.dp))
            if (destructive) DangerButton(confirmText, onClick = { onConfirm(); onDismiss() })
            else             PrimaryButton(confirmText, onClick = { onConfirm(); onDismiss() })
        },
    ) {
        Text(message, fontFamily = BodyFontFamily, fontSize = 13.sp,
            color = MaterialTheme.studyColors.text2, lineHeight = 20.sp)
    }
}
