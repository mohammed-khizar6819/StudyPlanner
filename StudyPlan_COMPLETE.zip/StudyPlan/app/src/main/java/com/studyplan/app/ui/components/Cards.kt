@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyplan.app.ui.animation.PROGRESS_MS
import com.studyplan.app.ui.animation.EaseOut
import com.studyplan.app.ui.theme.HeadingFontFamily
import com.studyplan.app.ui.theme.BodyFontFamily
import com.studyplan.app.ui.theme.StudyPlanRadius
import com.studyplan.app.ui.theme.studyColors

// ═══════════════════════════════════════════════════════════════════
//  SURFACE CARD — base container with border + radius
// ═══════════════════════════════════════════════════════════════════
@Composable
fun SurfaceCard(
    modifier:  Modifier = Modifier,
    padding:   PaddingValues = PaddingValues(20.dp, 18.dp),
    content:   @Composable ColumnScope.() -> Unit,
) {
    val colors = MaterialTheme.studyColors
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(StudyPlanRadius.lg))
            .background(colors.surface)
            .border(1.dp, colors.border, RoundedCornerShape(StudyPlanRadius.lg))
            .padding(padding),
        content = content,
    )
}

// ═══════════════════════════════════════════════════════════════════
//  METRIC CARD — large number + label (Dashboard top row)
//  Matches HTML .metric-card
// ═══════════════════════════════════════════════════════════════════
@Composable
fun MetricCard(
    label:    String,
    value:    String,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.studyColors
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(StudyPlanRadius.lg))
            .background(colors.surface)
            .border(1.dp, colors.border, RoundedCornerShape(StudyPlanRadius.lg))
            .padding(horizontal = 18.dp, vertical = 16.dp),
    ) {
        Text(
            text       = value,
            fontFamily = HeadingFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize   = 28.sp,
            color      = colors.text,
            letterSpacing = (-1.12).sp,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text          = label.uppercase(),
            fontFamily    = Figtree,
            fontWeight    = FontWeight.Bold,
            fontSize      = 9.sp,
            color         = colors.text3,
            letterSpacing = 1.sp,
        )
    }
}

// ═══════════════════════════════════════════════════════════════════
//  ANIMATED PROGRESS BAR
//  Resets to 0 then animates to target on each composition.
//  Mirrors HTML .progress-bar-fill CSS transition trick.
// ═══════════════════════════════════════════════════════════════════
@Composable
fun AnimatedProgressBar(
    progress:   Float,              // 0f..1f
    modifier:   Modifier = Modifier,
    height:     Dp       = 4.dp,
    trackColor: Color?   = null,
    fillColor:  Color?   = null,
) {
    val colors = MaterialTheme.studyColors
    val track  = trackColor ?: colors.border
    val fill   = fillColor  ?: colors.primary

    // Trigger: first frame → 0, then animate to real value
    var triggered by remember { mutableStateOf(false) }
    LaunchedEffect(progress) { triggered = true }

    val animProgress by animateFloatAsState(
        targetValue   = if (triggered) progress.coerceIn(0f, 1f) else 0f,
        animationSpec = tween(PROGRESS_MS, easing = EaseOut),
        label         = "progress",
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(height / 2))
            .background(track),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(animProgress)
                .fillMaxHeight()
                .clip(RoundedCornerShape(height / 2))
                .background(fill),
        )
    }
}

// ═══════════════════════════════════════════════════════════════════
//  INFO CARD — key/value rows
//  Matches HTML .info-card, .info-row
// ═══════════════════════════════════════════════════════════════════
@Composable
fun InfoCard(
    modifier: Modifier = Modifier,
    content:  @Composable ColumnScope.() -> Unit,
) {
    SurfaceCard(modifier = modifier, padding = PaddingValues(0.dp), content = content)
}

@Composable
fun InfoRow(
    label:    String,
    value:    String,
    isLast:   Boolean = false,
) {
    val colors = MaterialTheme.studyColors
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment     = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .run { if (!isLast) border(bottom = 1.dp, color = colors.border) else this }
            .padding(horizontal = 18.dp, vertical = 8.dp),
    ) {
        Text(label, fontFamily = BodyFontFamily, fontSize = 12.sp, color = colors.text3)
        Text(value, fontFamily = BodyFontFamily, fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp, color = colors.text)
    }
}

// ─────────────────────────────────────────────────────────────────
//  Badge — colored pill label
//  Matches HTML .badge variants
// ─────────────────────────────────────────────────────────────────
enum class BadgeType { GREEN, RED, YELLOW, BLUE, NEUTRAL }

@Composable
fun Badge(text: String, type: BadgeType = BadgeType.NEUTRAL, modifier: Modifier = Modifier) {
    val colors = MaterialTheme.studyColors
    val (bg, fg) = when (type) {
        BadgeType.GREEN   -> colors.greenX  to colors.green
        BadgeType.RED     -> colors.redX    to colors.red
        BadgeType.YELLOW  -> colors.yellowX to colors.yellow
        BadgeType.BLUE    -> colors.blueX   to colors.blue
        BadgeType.NEUTRAL -> colors.surface2 to colors.text2
    }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(100.dp))
            .background(bg)
            .padding(horizontal = 7.dp, vertical = 2.dp),
    ) {
        Text(text, fontFamily = BodyFontFamily, fontWeight = FontWeight.Bold,
            fontSize = 10.sp, color = fg, letterSpacing = 0.sp)
    }
}

// ── Subject color dot ─────────────────────────────────────────────
@Composable
fun SubjectColorDot(colorHex: String, size: Dp = 8.dp, modifier: Modifier = Modifier) {
    val color = runCatching {
        val hex = colorHex.trimStart('#')
        Color(android.graphics.Color.parseColor("#$hex"))
    }.getOrElse { MaterialTheme.studyColors.text3 }
    Box(modifier = modifier.size(size).clip(RoundedCornerShape(size / 2)).background(color))
}

// ── Subject color bar (left accent on subject cards) ─────────────
@Composable
fun SubjectColorBar(colorHex: String, modifier: Modifier = Modifier) {
    val color = runCatching {
        Color(android.graphics.Color.parseColor("#${colorHex.trimStart('#')}"))
    }.getOrElse { MaterialTheme.studyColors.text3 }
    Box(modifier = modifier.width(3.dp).height(38.dp)
        .clip(RoundedCornerShape(2.dp)).background(color))
}
