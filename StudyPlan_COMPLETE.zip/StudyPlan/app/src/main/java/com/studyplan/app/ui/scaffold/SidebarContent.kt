@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.scaffold


import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyplan.app.ui.navigation.Screen
import com.studyplan.app.ui.theme.BricolageGrotesque
import com.studyplan.app.ui.theme.Figtree
import com.studyplan.app.ui.theme.studyColors

// ═══════════════════════════════════════════════════════════════════
//  SIDEBAR CONTENT
//  Renders in both the permanent sidebar (tablet) and the
//  ModalDrawerSheet (phone). Pure state-in / callback-out.
// ═══════════════════════════════════════════════════════════════════

@Composable
fun SidebarContent(
    currentRoute: String?,
    onNavItemClick: (String) -> Unit,
    isDarkTheme: Boolean,
    onThemeToggle: () -> Unit,
    // Today's progress — wired up in Phase 5; defaults to 0 for Phase 1
    todayDone: Int  = 0,
    todayTotal: Int = 0,
    isTimerRunning: Boolean = false,   // timer dot — wired in Phase 9
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.studyColors

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(colors.bg)
            .verticalScroll(rememberScrollState()),
    ) {
        // ── Brand ─────────────────────────────────────────────────
        SidebarBrand()

        // ── Section label ─────────────────────────────────────────
        NavSectionLabel(text = "Menu")

        // ── Primary nav items ─────────────────────────────────────
        Screen.primary.forEach { screen ->
            NavItem(
                screen      = screen,
                isActive    = currentRoute == screen.route,
                onClick     = { onNavItemClick(screen.route) },
                showTimerDot = screen == Screen.Timer && isTimerRunning,
            )
        }

        Spacer(Modifier.height(8.dp))
        HorizontalDivider(color = colors.border, thickness = 1.dp)
        Spacer(Modifier.height(4.dp))

        // ── Utility nav items ─────────────────────────────────────
        Screen.utility.forEach { screen ->
            NavItem(
                screen   = screen,
                isActive = currentRoute == screen.route,
                onClick  = { onNavItemClick(screen.route) },
            )
        }

        Spacer(Modifier.weight(1f))

        // ── Today's Progress mini-widget ──────────────────────────
        AnimatedVisibility(
            visible = todayTotal > 0,
            enter   = fadeIn(tween(200)),
            exit    = fadeOut(tween(200)),
        ) {
            TodayProgressWidget(
                done  = todayDone,
                total = todayTotal,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }

        // ── Theme toggle ──────────────────────────────────────────
        ThemeToggleButton(
            isDarkTheme = isDarkTheme,
            onClick     = onThemeToggle,
            modifier    = Modifier.padding(horizontal = 8.dp),
        )

        // ── Motivational quote ────────────────────────────────────
        SidebarQuote(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
        )
    }
}

// ─────────────────────────────────────────────────────────────────
//  Brand
// ─────────────────────────────────────────────────────────────────
@Composable
private fun SidebarBrand() {
    val colors = MaterialTheme.studyColors
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 20.dp),
    ) {
        // Brand icon — 3-bar progress mark (matches HTML SVG)
        BrandIcon()
        Spacer(Modifier.width(10.dp))
        Column {
            Text(
                text       = "StudyPlan",
                fontFamily = BricolageGrotesque,
                fontWeight = FontWeight.Bold,
                fontSize   = 14.sp,
                color      = colors.text,
                letterSpacing = (-0.02).sp,
            )
            Text(
                text       = "STUDY TRACKER",
                fontFamily = Figtree,
                fontWeight = FontWeight.Bold,
                fontSize   = 9.sp,
                color      = colors.text3,
                letterSpacing = 1.4.sp,
            )
        }
    }
}

@Composable
private fun BrandIcon() {
    val colors = MaterialTheme.studyColors
    // Mirrors the 3-stacked-bars SVG from HTML
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(32.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(colors.text),
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(3.dp),
            modifier = Modifier.padding(6.dp),
        ) {
            // Full bar
            Box(Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(1.5.dp)).background(colors.bg))
            // 70% bar
            Box(Modifier.fillMaxWidth(0.70f).height(3.dp).clip(RoundedCornerShape(1.5.dp)).background(colors.bg.copy(alpha = 0.7f)))
            // 45% bar
            Box(Modifier.fillMaxWidth(0.45f).height(3.dp).clip(RoundedCornerShape(1.5.dp)).background(colors.bg.copy(alpha = 0.4f)))
        }
    }
}

// ─────────────────────────────────────────────────────────────────
//  Section label (e.g. "MENU")
// ─────────────────────────────────────────────────────────────────
@Composable
private fun NavSectionLabel(text: String) {
    val colors = MaterialTheme.studyColors
    Text(
        text      = text.uppercase(),
        fontFamily = Figtree,
        fontWeight = FontWeight.Bold,
        fontSize   = 9.sp,
        color      = colors.text3.copy(alpha = 0.6f),
        letterSpacing = 2.sp,
        modifier   = Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp),
    )
}

// ─────────────────────────────────────────────────────────────────
//  Nav Item — exact port of .nav-item CSS rules
// ─────────────────────────────────────────────────────────────────
@Composable
fun NavItem(
    screen: Screen,
    isActive: Boolean,
    onClick: () -> Unit,
    showTimerDot: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.studyColors
    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 1.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(if (isActive) colors.hover else colors.bg)
            .clickable(
                interactionSource = interactionSource,
                indication        = null,  // we handle hover state ourselves
                onClick           = onClick,
            ),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
        ) {
            // ── Active indicator bar (left 2dp accent) ────────────
            Box(
                modifier = Modifier
                    .width(2.dp)
                    .height(14.dp)
                    .clip(RoundedCornerShape(topEnd = 2.dp, bottomEnd = 2.dp))
                    .background(if (isActive) colors.text else colors.bg),
            )

            Spacer(Modifier.width(6.dp))

            // ── Icon ──────────────────────────────────────────────
            Icon(
                imageVector        = screen.icon,
                contentDescription = screen.label,
                tint               = if (isActive) colors.text else colors.text3,
                modifier           = Modifier.size(14.dp),
            )

            Spacer(Modifier.width(9.dp))

            // ── Label ─────────────────────────────────────────────
            Text(
                text       = screen.label,
                fontFamily = Figtree,
                fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal,
                fontSize   = 13.sp,
                color      = if (isActive) colors.text else colors.text3,
                maxLines   = 1,
                overflow   = TextOverflow.Ellipsis,
                modifier   = Modifier.weight(1f),
            )

            // ── Timer dot (shown when timer is running) ───────────
            if (showTimerDot) {
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .clip(RoundedCornerShape(50))
                        .background(colors.text),
                )
                Spacer(Modifier.width(4.dp))
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────
//  Today's Progress Mini-Widget (sidebar footer)
// ─────────────────────────────────────────────────────────────────
@Composable
private fun TodayProgressWidget(
    done: Int,
    total: Int,
    modifier: Modifier = Modifier,
) {
    val colors   = MaterialTheme.studyColors
    val progress = if (total > 0) done.toFloat() / total else 0f

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(colors.surface)
            .padding(horizontal = 12.dp, vertical = 10.dp),
    ) {
        Text(
            text       = "TODAY'S PROGRESS",
            fontFamily = Figtree,
            fontWeight = FontWeight.Bold,
            fontSize   = 9.sp,
            color      = colors.text3,
            letterSpacing = 1.sp,
        )
        Spacer(Modifier.height(5.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text       = "$done/$total",
                fontFamily = Figtree,
                fontWeight = FontWeight.Bold,
                fontSize   = 12.sp,
                color      = colors.text,
            )
            LinearProgressIndicator(
                progress         = { progress },
                modifier         = Modifier.weight(1f).height(2.dp),
                color            = colors.text,
                trackColor       = colors.border,
                strokeCap        = StrokeCap.Round,
                gapSize          = 0.dp,
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────
//  Theme Toggle Button
// ─────────────────────────────────────────────────────────────────
@Composable
private fun ThemeToggleButton(
    isDarkTheme: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.studyColors
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 7.dp),
    ) {
        Icon(
            imageVector        = if (isDarkTheme) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
            contentDescription = if (isDarkTheme) "Switch to light theme" else "Switch to dark theme",
            tint               = colors.text3,
            modifier           = Modifier.size(14.dp),
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text       = if (isDarkTheme) "Light Mode" else "Dark Mode",
            fontFamily = Figtree,
            fontWeight = FontWeight.Medium,
            fontSize   = 12.sp,
            color      = colors.text3,
        )
    }
}

// ─────────────────────────────────────────────────────────────────
//  Motivational Quote
// ─────────────────────────────────────────────────────────────────
@Composable
private fun SidebarQuote(modifier: Modifier = Modifier) {
    val colors = MaterialTheme.studyColors
    Column(modifier = modifier) {
        Text(
            text       = "Stay Focused",
            fontFamily = Figtree,
            fontWeight = FontWeight.Bold,
            fontSize   = 9.sp,
            color      = colors.text3,
            letterSpacing = 1.sp,
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text       = "\"Success is the sum of small efforts, repeated day in and day out.\"",
            fontFamily = Figtree,
            fontWeight = FontWeight.Normal,
            fontSize   = 11.sp,
            color      = colors.text3,
            fontStyle  = FontStyle.Italic,
            lineHeight = 16.sp,
        )
    }
}
