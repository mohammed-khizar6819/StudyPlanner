@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyplan.app.ui.theme.HeadingFontFamily
import com.studyplan.app.ui.theme.BodyFontFamily
import com.studyplan.app.ui.theme.studyColors

// ═══════════════════════════════════════════════════════════════════
//  EMPTY STATE — shown when a list has no items
//  Matches HTML .empty-state
// ═══════════════════════════════════════════════════════════════════

@Composable
fun EmptyState(
    title:    String,
    subtitle: String?        = null,
    icon:     ImageVector    = Icons.Outlined.Add,
    cta:      String?        = null,
    onCta:    (() -> Unit)?  = null,
    modifier: Modifier       = Modifier,
) {
    val colors = MaterialTheme.studyColors
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 80.dp, horizontal = 24.dp),
    ) {
        Icon(
            imageVector        = icon,
            contentDescription = null,
            tint               = colors.text3,
            modifier           = Modifier.size(36.dp),
        )
        Spacer(Modifier.height(20.dp))
        Text(
            text       = title,
            fontFamily = HeadingFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize   = 15.sp,
            color      = colors.text,
            textAlign  = TextAlign.Center,
        )
        if (subtitle != null) {
            Spacer(Modifier.height(8.dp))
            Text(
                text       = subtitle,
                fontFamily = BodyFontFamily,
                fontSize   = 13.sp,
                color      = colors.text3,
                textAlign  = TextAlign.Center,
                lineHeight = 20.sp,
            )
        }
        if (cta != null && onCta != null) {
            Spacer(Modifier.height(20.dp))
            PrimaryButton(cta, onClick = onCta)
        }
    }
}
