package com.studyplan.app.di

import com.studyplan.app.io.DataExporter
import com.studyplan.app.io.DataImporter
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

// DataExporter and DataImporter use @Inject constructor + @Singleton
// so Hilt creates them automatically. No @Provides needed.
@Module
@InstallIn(SingletonComponent::class)
object IoModule
