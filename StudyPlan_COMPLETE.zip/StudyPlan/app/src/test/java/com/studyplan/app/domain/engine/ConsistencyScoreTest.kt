package com.studyplan.app.domain.engine

import org.junit.Assert.*
import org.junit.Test
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Tests for ConsistencyScore calculation logic.
 */
class ConsistencyScoreTest {

    private fun computeScore(completionRate: Double, attendance: Double, streakDays: Int): Int {
        val streakComponent = min(100.0, (streakDays.toDouble() / 14) * 100)
        return ((completionRate * 0.40) + (attendance * 0.35) + (streakComponent * 0.25))
            .roundToInt().coerceIn(0, 100)
    }

    @Test fun `perfect score gives 100`() {
        assertEquals(100, computeScore(100.0, 100.0, 14))
    }

    @Test fun `zero activity gives 0`() {
        assertEquals(0, computeScore(0.0, 0.0, 0))
    }

    @Test fun `partial completion gives intermediate score`() {
        val score = computeScore(60.0, 70.0, 7)
        assertTrue("Score should be between 50 and 80", score in 50..80)
    }

    @Test fun `streak capped at 14 for 100 streak component`() {
        val streakAt14  = min(100.0, (14.0 / 14) * 100)
        val streakAt100 = min(100.0, (100.0 / 14) * 100)
        assertEquals(100.0, streakAt14,  0.001)
        assertEquals(100.0, streakAt100, 0.001)
    }

    @Test fun `label mapping correct`() {
        fun label(score: Int) = when {
            score >= 80 -> "Excellent"
            score >= 60 -> "Good"
            score >= 40 -> "Fair"
            score >= 20 -> "Needs Work"
            else        -> "Critical"
        }
        assertEquals("Excellent",  label(80))
        assertEquals("Good",       label(65))
        assertEquals("Fair",       label(45))
        assertEquals("Needs Work", label(25))
        assertEquals("Critical",   label(10))
    }

    @Test fun `score is always 0-100`() {
        val score = computeScore(200.0, 200.0, 1000)
        assertTrue(score <= 100)
        val score2 = computeScore(-10.0, -10.0, -5)
        assertTrue(score2 >= 0)
    }
}
