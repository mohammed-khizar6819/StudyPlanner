@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.today

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studyplan.app.domain.engine.TodayEntry
import com.studyplan.app.domain.engine.TimeUtils
import com.studyplan.app.domain.model.NoteType
import com.studyplan.app.domain.model.ScheduleEntryStatus
import com.studyplan.app.ui.animation.cardUpEnter
import com.studyplan.app.ui.animation.CARD_STAGGER_DELAYS
import com.studyplan.app.ui.components.*
import com.studyplan.app.ui.components.dialog.StudyPlanDialog
import com.studyplan.app.ui.theme.*
import androidx.compose.animation.AnimatedVisibility

@Composable
fun TodayScreen(vm: TodayViewModel = hiltViewModel()) {
    val state  by vm.state.collectAsStateWithLifecycle()
    val undo   by vm.undoPending.collectAsStateWithLifecycle()
    val colors  = MaterialTheme.studyColors
    val toast   = LocalToastHost.current

    LaunchedEffect(Unit) { vm.toast.collect { toast.show(it) } }

    // Wire undo toast
    LaunchedEffect(undo) {
        undo?.let { toast.showWithUndo(it.label) }
    }

    var partialEntry   by remember { mutableStateOf<TodayEntry?>(null) }
    var partialSeconds by remember { mutableStateOf("") }
    var showNoteDialog by remember { mutableStateOf(false) }
    var preselectedLec by remember { mutableStateOf<String?>(null) }

    if (state.isLoading) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = colors.text, strokeWidth = 2.dp,
                modifier = Modifier.size(28.dp))
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.bg)
            .verticalScroll(rememberScrollState()),
    ) {
        PageHeader(
            title    = "Today's Plan",
            subtitle = "${state.dayName}, ${state.dateDisplay}",
        )

        Column(modifier = Modifier.padding(horizontal = 16.dp)) {

            // Rest day / vacation
            if (state.isRestDay) {
                EmptyState(
                    icon     = Icons.Outlined.Weekend,
                    title    = "Rest Day",
                    subtitle = "Today is your scheduled rest day. Enjoy the break!",
                    modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp),
                )
                return@Column
            }

            // Before start date
            if (state.isBeforeStart) {
                EmptyState(
                    icon     = Icons.Outlined.CalendarMonth,
                    title    = "Plan Hasn't Started",
                    subtitle = "Your study plan hasn't started yet. Check your start date in Settings.",
                    modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp),
                )
                return@Column
            }

            // No plan for today
            if (state.entries.isEmpty()) {
                EmptyState(
                    icon     = Icons.Outlined.CheckCircle,
                    title    = "All done for today!",
                    subtitle = "No sessions scheduled. You're ahead of the plan.",
                    modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp),
                )
                return@Column
            }

            // Progress summary
            val done  = state.entries.count { it.entry.status == ScheduleEntryStatus.DONE ||
                                               it.entry.status == ScheduleEntryStatus.PARTIAL_DONE }
            val total = state.entries.size
            Row(
                verticalAlignment     = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier              = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            ) {
                Text("$done / $total completed", fontFamily = BodyFontFamily,
                    fontSize = 13.sp, color = colors.text2)
                Badge(
                    text = if (done == total) "All Done ✓" else "${"%.0f".format(done.toFloat()/total*100)}%",
                    type = if (done == total) BadgeType.GREEN else BadgeType.NEUTRAL,
                )
            }
            AnimatedProgressBar(progress = if (total > 0) done.toFloat() / total else 0f)
            Spacer(Modifier.height(14.dp))

            // Session cards — staggered animation
            state.entries.forEachIndexed { idx, entry ->
                AnimatedVisibility(
                    visible = true,
                    enter   = cardUpEnter(CARD_STAGGER_DELAYS.getOrElse(idx) { idx * 40 }),
                ) {
                    TodaySessionCard(
                        entry      = entry,
                        onDone     = { vm.markDone(entry) },
                        onPartial  = { partialEntry = entry; partialSeconds = "" },
                        onQuickLog = { secs -> vm.quickLog(entry, secs) },
                        onAddNote  = { preselectedLec = entry.lecture.id; showNoteDialog = true },
                    )
                }
                Spacer(Modifier.height(8.dp))
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    // Quick note dialog — opens from session card "📝 Note" button
    if (showNoteDialog) {
        QuickNoteFromTodayDialog(
            lectureId  = preselectedLec,
            onDismiss  = { showNoteDialog = false; preselectedLec = null },
            onSave     = { lecId, text, type ->
                vm.addQuickNote(lecId, text, type)
                showNoteDialog = false
                preselectedLec = null
            },
        )
    }

    // Partial time dialog
    partialEntry?.let { entry ->
        PartialSessionDialog(
            lectureName   = entry.lecture.name,
            maxSeconds    = entry.lecture.remaining,
            inputValue    = partialSeconds,
            onInputChange = { partialSeconds = it },
            onConfirm     = {
                val secs = TimeUtils.toSeconds(partialSeconds)
                if (secs > 0) {
                    vm.logPartial(entry.lecture.id, secs)
                    partialEntry = null
                } else {
                    toast.show("Enter a valid time (hh:mm:ss)", isError = true)
                }
            },
            onDismiss = { partialEntry = null },
        )
    }
}

// ── Session Card ──────────────────────────────────────────────────
@Composable
private fun TodaySessionCard(
    entry:     TodayEntry,
    onDone:    () -> Unit,
    onPartial: () -> Unit,
    onQuickLog: (Long) -> Unit,
    onAddNote:  () -> Unit = {},
) {
    val colors  = MaterialTheme.studyColors
    val isDone  = entry.entry.status == ScheduleEntryStatus.DONE
    val isPartial = entry.entry.status == ScheduleEntryStatus.PARTIAL_DONE
    val cardBg  = when {
        isDone    -> colors.cardDoneBg
        isPartial -> colors.cardDoneBg.copy(alpha = 0.5f)
        else      -> colors.surface
    }
    val borderColor = when {
        isDone    -> colors.green.copy(alpha = 0.3f)
        isPartial -> colors.green.copy(alpha = 0.15f)
        else      -> colors.border
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(cardBg)
            .border(1.dp, borderColor, RoundedCornerShape(10.dp))
            .padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SubjectColorDot(entry.subject.color, size = 8.dp)
            Spacer(Modifier.width(8.dp))
            Text(
                text       = entry.lecture.name,
                fontFamily = BodyFontFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize   = 13.sp,
                color      = if (isDone) colors.text3 else colors.text,
                textDecoration = if (isDone) TextDecoration.LineThrough else null,
                modifier   = Modifier.weight(1f),
                maxLines   = 2,
                overflow   = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text       = TimeUtils.toDisplay(entry.entry.plannedSeconds),
                fontFamily = MonoFontFamily,
                fontSize   = 12.sp,
                color      = colors.text3,
            )
        }

        // Tags
        if (entry.lecture.tags.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                entry.lecture.tags.forEach { tag ->
                    Badge(text = tag.label, type = BadgeType.NEUTRAL)
                }
            }
        }

        // Partial progress bar
        if (isPartial && entry.entry.completedSeconds > 0) {
            Spacer(Modifier.height(8.dp))
            AnimatedProgressBar(
                progress = (entry.entry.completedSeconds.toFloat() / entry.entry.plannedSeconds)
                    .coerceIn(0f, 1f),
                height   = 2.dp,
                fillColor = colors.green,
            )
        }

        if (!isDone) {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                // Mark Done button — with green check style
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(colors.checkBtnBg)
                        .border(1.dp, colors.checkBtnBorder, RoundedCornerShape(6.dp))
                        .clickable(
                            indication = null,
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            onClick = onDone,
                        )
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                ) {
                    Icon(Icons.Outlined.CheckCircle, null, tint = colors.green,
                        modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("Done", fontFamily = BodyFontFamily, fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp, color = colors.green)
                }

                // Partial
                XsButton("Partial", onClick = onPartial, variant = ButtonVariant.OUTLINE)

                Spacer(Modifier.weight(1f))

                // Quick-log +15m +30m +1h
                listOf(900L to "+15m", 1800L to "+30m", 3600L to "+1h").forEach { (secs, label) ->
                    XsButton(label, onClick = { onQuickLog(secs) }, variant = ButtonVariant.OUTLINE)
                }
            }
        }
    }
}

// ── Partial Session Dialog ────────────────────────────────────────
@Composable
private fun PartialSessionDialog(
    lectureName:  String,
    maxSeconds:   Long,
    inputValue:   String,
    onInputChange: (String) -> Unit,
    onConfirm:    () -> Unit,
    onDismiss:    () -> Unit,
) {
    StudyPlanDialog(
        visible   = true,
        title     = "Log Partial Session",
        onDismiss = onDismiss,
        footer    = {
            OutlineButton("Cancel", onClick = onDismiss)
            Spacer(Modifier.width(8.dp))
            PrimaryButton("Log", onClick = onConfirm)
        },
    ) {
        val colors = MaterialTheme.studyColors
        Text(lectureName, fontFamily = BodyFontFamily, fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp, color = colors.text)
        Spacer(Modifier.height(4.dp))
        Text("Remaining: ${TimeUtils.toDisplay(maxSeconds)}",
            fontFamily = MonoFontFamily, fontSize = 11.sp, color = colors.text3)
        Spacer(Modifier.height(14.dp))
        FieldLabel("Time studied (hh:mm:ss)")
        StudyTextField(
            value         = inputValue,
            onValueChange = onInputChange,
            placeholder   = "00:45:00",
            keyboardType  = androidx.compose.ui.text.input.KeyboardType.Ascii,
        )
        Spacer(Modifier.height(4.dp))
        FieldHint("Enter the time you actually studied, e.g. 00:45:00")
    }
}


// ── Quick Note Dialog (from Today's Plan) ────────────────────────
@Composable
private fun QuickNoteFromTodayDialog(
    lectureId: String?,
    onDismiss: () -> Unit,
    onSave:    (lecId: String, text: String, type: NoteType) -> Unit,
) {
    if (lectureId == null) { onDismiss(); return }
    var text     by remember { mutableStateOf("") }
    var noteType by remember { mutableStateOf(NoteType.NOTE) }
    val toast    = LocalToastHost.current

    StudyPlanDialog(
        visible   = true,
        title     = "Add Note",
        onDismiss = onDismiss,
        footer    = {
            OutlineButton("Cancel", onClick = onDismiss)
            Spacer(Modifier.width(8.dp))
            PrimaryButton("Save Note") {
                if (text.isBlank()) { toast.show("Note cannot be empty", true); return@PrimaryButton }
                onSave(lectureId, text, noteType)
            }
        },
    ) {
        FieldLabel("Type")
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier              = Modifier.fillMaxWidth(),
        ) {
            listOf(NoteType.NOTE to "📝 Note", NoteType.DOUBT to "❓ Doubt", NoteType.KEY to "⭐ Key Point")
                .forEach { (type, label) ->
                    TagToggleButton(label, noteType == type, { noteType = type }, Modifier.weight(1f))
                }
        }
        Spacer(Modifier.height(12.dp))
        FieldLabel("Content")
        StudyTextArea(value = text, onValueChange = { text = it },
            placeholder = "Write your note, doubt or key point…", minLines = 4)
    }
}