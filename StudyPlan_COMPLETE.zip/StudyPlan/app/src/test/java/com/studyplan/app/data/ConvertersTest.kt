package com.studyplan.app.data

import com.studyplan.app.data.db.Converters
import com.studyplan.app.domain.model.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class ConvertersTest {

    private lateinit var converters: Converters

    @Before fun setUp() { converters = Converters() }

    @Test fun `string list roundtrip`() {
        val list = listOf("2024-01-01", "2024-03-15", "2024-12-31")
        val json = converters.fromStringList(list)
        assertEquals(list, converters.toStringList(json))
    }

    @Test fun `empty string list roundtrip`() {
        val list = emptyList<String>()
        assertEquals(list, converters.toStringList(converters.fromStringList(list)))
    }

    @Test fun `LectureStatus roundtrip - all values`() {
        LectureStatus.entries.forEach { status ->
            assertEquals(status, converters.toLectureStatus(converters.fromLectureStatus(status)))
        }
    }

    @Test fun `LectureStatus unknown falls back to PENDING`() {
        assertEquals(LectureStatus.PENDING, converters.toLectureStatus("unknown_value"))
    }

    @Test fun `ScheduleEntryStatus roundtrip`() {
        ScheduleEntryStatus.entries.forEach { s ->
            assertEquals(s, converters.toEntryStatus(converters.fromEntryStatus(s)))
        }
    }

    @Test fun `NoteType roundtrip`() {
        NoteType.entries.forEach { t ->
            assertEquals(t, converters.toNoteType(converters.fromNoteType(t)))
        }
    }

    @Test fun `LectureDifficulty roundtrip`() {
        LectureDifficulty.entries.forEach { d ->
            assertEquals(d, converters.toDifficulty(converters.fromDifficulty(d)))
        }
    }

    @Test fun `LectureDifficulty null falls back to MEDIUM`() {
        assertEquals(LectureDifficulty.MEDIUM, LectureDifficulty.from(null))
    }

    @Test fun `LectureTag list roundtrip`() {
        val tags = listOf(LectureTag.HIGH_WEIGHTAGE, LectureTag.IMPORTANT)
        assertEquals(tags, converters.toTagList(converters.fromTagList(tags)))
    }

    @Test fun `LectureTag list empty roundtrip`() {
        val tags = emptyList<LectureTag>()
        assertEquals(tags, converters.toTagList(converters.fromTagList(tags)))
    }
}
