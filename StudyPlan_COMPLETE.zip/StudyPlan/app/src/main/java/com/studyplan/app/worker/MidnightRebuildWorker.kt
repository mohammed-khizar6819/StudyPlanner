package com.studyplan.app.worker

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.studyplan.app.domain.engine.SchedulerEngine
import com.studyplan.app.domain.repository.MetaRepository
import com.studyplan.app.domain.engine.TimeUtils
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

/**
 * Runs once per day at midnight (via WorkManager periodic work).
 * Triggers buildSchedule() for the new day — mirrors HTML's
 * "if meta.lastBuiltDate !== today { buildSchedule(true) }" check.
 */
@HiltWorker
class MidnightRebuildWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params:  WorkerParameters,
    private val schedulerEngine: SchedulerEngine,
    private val metaRepo:        MetaRepository,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val today     = TimeUtils.today()
            val meta      = metaRepo.get()
            if (meta?.lastBuiltDate != today) {
                schedulerEngine.buildSchedule(forceRebuildToday = true)
                metaRepo.updateLastBuiltDate(today)
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        const val WORK_NAME = "midnight_schedule_rebuild"
    }
}

/**
 * Schedules MidnightRebuildWorker as a daily periodic job.
 * Uses KEEP so it won't duplicate if already enqueued.
 */
class MidnightRebuildScheduler(private val context: Context) {
    fun schedule() {
        val request = PeriodicWorkRequestBuilder<MidnightRebuildWorker>(1, TimeUnit.DAYS)
            .setConstraints(Constraints.Builder()
                .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                .build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            MidnightRebuildWorker.WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request,
        )
    }
}
