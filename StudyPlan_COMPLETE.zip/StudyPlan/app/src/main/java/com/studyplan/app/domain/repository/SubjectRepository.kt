package com.studyplan.app.domain.repository
import com.studyplan.app.domain.model.Subject
import kotlinx.coroutines.flow.Flow

interface SubjectRepository {
    fun observeAll(): Flow<List<Subject>>
    suspend fun getAll(): List<Subject>
    suspend fun getById(id: String): Subject?
    suspend fun insert(subject: Subject)
    suspend fun insertAll(subjects: List<Subject>)
    suspend fun update(subject: Subject)
    suspend fun delete(id: String)
    suspend fun deleteAll()
}
