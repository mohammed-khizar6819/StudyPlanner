package com.studyplan.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.studyplan.app.domain.model.Subject

@Entity(tableName = "subjects")
data class SubjectEntity(
    @PrimaryKey val id:              String,
    val name:            String,
    val fullName:        String,
    val deadline:        String,
    val examDate:        String,
    val dailyHours:      Double,
    val priority:        Int,
    val color:           String,
    val createdAt:       String,
    val revisionEnabled: Boolean,
    val revisionRound:   Int,
) {
    fun toDomain() = Subject(id, name, fullName, deadline, examDate,
        dailyHours, priority, color, createdAt, revisionEnabled, revisionRound)
    companion object {
        fun fromDomain(s: Subject) = SubjectEntity(s.id, s.name, s.fullName,
            s.deadline, s.examDate, s.dailyHours, s.priority, s.color,
            s.createdAt, s.revisionEnabled, s.revisionRound)
    }
}
