@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.analytics

import android.content.Intent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.studyplan.app.domain.engine.*
import com.studyplan.app.domain.engine.AppStats
import com.studyplan.app.ui.components.*
import com.studyplan.app.ui.theme.*

@Composable
fun AnalyticsScreen(vm: AnalyticsViewModel = hiltViewModel()) {
    val state   by vm.state.collectAsStateWithLifecycle()
    val colors   = MaterialTheme.studyColors
    val context  = LocalContext.current
    val toast    = LocalToastHost.current

    // Share sheet on report text
    LaunchedEffect(Unit) {
        vm.shareText.collect { text ->
            val intent = Intent(Intent.ACTION_SEND).apply {
                type    = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            context.startActivity(Intent.createChooser(intent, "Share Study Report"))
        }
    }

    if (state.isLoading) {
        Box(Modifier.fillMaxSize(), Alignment.Center) {
            CircularProgressIndicator(color = colors.text, strokeWidth = 2.dp,
                modifier = Modifier.size(28.dp))
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.bg)
            .verticalScroll(rememberScrollState()),
    ) {
        PageHeader(title = "Analytics", subtitle = "Study insights & progress tracking")

        Column(modifier = Modifier.padding(horizontal = 16.dp)) {

            // ── Week Summary strip ────────────────────────────────
            SurfaceCard {
                SectionTitle("This Week")
                Spacer(Modifier.height(10.dp))
                WeekSummaryRow(state.weekly)
            }
            Spacer(Modifier.height(16.dp))

            // ── Weekly Bar Chart ──────────────────────────────────
            SurfaceCard {
                SectionTitle("Daily Progress")
                Spacer(Modifier.height(10.dp))
                WeeklyBarChart(days = state.weekly.days)
            }
            Spacer(Modifier.height(16.dp))

            // ── Per-subject weekly breakdown ──────────────────────
            if (state.weekly.subjectWeekly.isNotEmpty()) {
                SurfaceCard {
                    SectionTitle("Subject Breakdown (This Week)")
                    Spacer(Modifier.height(10.dp))
                    state.weekly.subjectWeekly.forEach { sub ->
                        SubjectWeeklyRow(sub)
                        Spacer(Modifier.height(8.dp))
                    }
                }
                Spacer(Modifier.height(16.dp))
            }

            // ── Consistency Score + Velocity side by side ─────────
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier              = Modifier.fillMaxWidth(),
            ) {
                SurfaceCard(modifier = Modifier.weight(1f)) {
                    SectionTitle("Consistency")
                    Spacer(Modifier.height(8.dp))
                    ConsistencyArc(
                        result   = state.consistency,
                        modifier = Modifier.fillMaxWidth().height(100.dp),
                    )
                }
                SurfaceCard(modifier = Modifier.weight(1f)) {
                    SectionTitle("Velocity (8w)")
                    Spacer(Modifier.height(8.dp))
                    VelocityChart(weekly = state.weekly)
                }
            }
            Spacer(Modifier.height(16.dp))

            // ── Time of Day Heatmap ───────────────────────────────
            SurfaceCard {
                SectionTitle("Best Study Hours")
                Spacer(Modifier.height(8.dp))
                TODHeatmap(logs = state.sessionLogs)
            }
            Spacer(Modifier.height(16.dp))

            // ── Study Streak Calendar ─────────────────────────────
            SurfaceCard {
                SectionTitle("Study Chain (5 weeks)")
                Spacer(Modifier.height(10.dp))
                ChainCalendar(weekly = state.weekly)
            }
            Spacer(Modifier.height(16.dp))

            // ── Prediction Chart ──────────────────────────────────
            SurfaceCard {
                SectionTitle("Pace vs Required")
                Spacer(Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier              = Modifier.padding(bottom = 8.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(14.dp, 2.dp).background(colors.primary))
                        Spacer(Modifier.width(5.dp))
                        Text("Actual", fontFamily = BodyFontFamily, fontSize = 11.sp,
                            color = colors.text3)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(14.dp, 2.dp).background(colors.borderStrong))
                        Spacer(Modifier.width(5.dp))
                        Text("Required", fontFamily = BodyFontFamily, fontSize = 11.sp,
                            color = colors.text3)
                    }
                }
                PredictionChart(
                    weekly  = state.weekly,
                    overall = state.overall,
                )
            }
            Spacer(Modifier.height(16.dp))

            // ── Weekly Report Card ────────────────────────────────
            ReportCardSection(
                weekly   = state.weekly,
                onShare  = { vm.shareReport() },
            )
            Spacer(Modifier.height(32.dp))
        }
    }
}

// ── Subject weekly breakdown row ──────────────────────────────────
@Composable
private fun SubjectWeeklyRow(sub: SubjectWeekly) {
    val colors = MaterialTheme.studyColors
    Row(
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier              = Modifier.fillMaxWidth(),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            SubjectColorDot(sub.color, size = 7.dp)
            Spacer(Modifier.width(8.dp))
            Text(sub.name, fontFamily = BodyFontFamily, fontWeight = FontWeight.Medium,
                fontSize = 13.sp, color = colors.text)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(TimeUtils.toDisplay(sub.weekStudied), fontFamily = MonoFontFamily,
                fontSize = 12.sp, color = colors.text2)
            Badge("${sub.weekLecsDone} done", BadgeType.NEUTRAL)
        }
    }
}

// ── Report Card section ───────────────────────────────────────────
@Composable
private fun ReportCardSection(weekly: WeeklyStats, onShare: () -> Unit) {
    val colors = MaterialTheme.studyColors
    SurfaceCard {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment     = Alignment.CenterVertically,
            modifier              = Modifier.fillMaxWidth(),
        ) {
            SectionTitle("Weekly Report Card")
            SmButton(
                text    = "Share",
                variant = ButtonVariant.OUTLINE,
                onClick = onShare,
            )
        }
        Spacer(Modifier.height(12.dp))

        val today = TimeUtils.today()
        val from  = TimeUtils.addDays(today, -6)

        listOf(
            TimeUtils.formatDisplay(from) + " – " + TimeUtils.formatDisplay(today) to "Period",
            TimeUtils.toDisplay(weekly.weekStudiedSecs)                              to "Total Studied",
            "${weekly.weekDone}"                                                     to "Lectures Done",
            "${weekly.streak} days"                                                  to "Streak",
            "${weekly.completionRate}%"                                              to "Completion Rate",
        ).forEachIndexed { i, (value, label) ->
            InfoRow(label = label, value = value, isLast = i == 4)
        }

        Spacer(Modifier.height(8.dp))
        // Overall progress bar
        val (bestLabel, bestHours) = weekly.bestDay?.let {
            it.dayName to TimeUtils.toDisplay(it.studiedSecs)
        } ?: ("—" to "")
        if (weekly.bestDay != null) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier              = Modifier.fillMaxWidth(),
            ) {
                Text("Best day: $bestLabel", fontFamily = BodyFontFamily,
                    fontSize = 12.sp, color = colors.text3)
                Text(bestHours, fontFamily = MonoFontFamily,
                    fontSize = 12.sp, color = colors.text2)
            }
        }
    }
}
