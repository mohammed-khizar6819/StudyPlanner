@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.settings

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studyplan.app.alarm.AlarmScheduler
import com.studyplan.app.domain.engine.*
import com.studyplan.app.domain.model.*
import com.studyplan.app.domain.repository.*
import com.studyplan.app.io.DataExporter
import com.studyplan.app.io.DataImporter
import com.studyplan.app.io.ImportResult
import com.studyplan.app.worker.NotifWorkerScheduler
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val isLoading:    Boolean        = true,
    val settings:     AppSettings?   = null,
    val savedPlans:   List<SavedPlan> = emptyList(),
    val alarmTimeUntil: String       = "",
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepo:    SettingsRepository,
    private val metaRepo:        MetaRepository,
    private val schedulerEngine: SchedulerEngine,
    private val statsEngine:     StatsEngine,
    private val multiPlanMgr:    MultiPlanManager,
    private val savedPlanRepo:   SavedPlanRepository,
    private val alarmScheduler:  AlarmScheduler,
    private val notifScheduler:  NotifWorkerScheduler,
    private val dataExporter:    DataExporter,
    private val dataImporter:    DataImporter,
    private val subjectRepo:     SubjectRepository,
    private val lectureRepo:     LectureRepository,
    private val scheduleRepo:    ScheduleRepository,
    private val noteRepo:        NoteRepository,
    private val sessionRepo:     SessionLogRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(SettingsUiState())
    val state: StateFlow<SettingsUiState> = _state.asStateFlow()

    private val _toast      = MutableSharedFlow<String>()
    val toast: SharedFlow<String> = _toast.asSharedFlow()

    private val _shareIntent = MutableSharedFlow<android.content.Intent>()
    val shareIntent: SharedFlow<android.content.Intent> = _shareIntent.asSharedFlow()

    private val _printRequest = MutableSharedFlow<Unit>()
    val printRequest: SharedFlow<Unit> = _printRequest.asSharedFlow()

    private val _importResult = MutableSharedFlow<ImportResult>()
    val importResult: SharedFlow<ImportResult> = _importResult.asSharedFlow()

    // Activity reference needed for PrintManager (weak, set from screen)
    var activityRef: Activity? = null

    init { load() }

    fun load() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            val settings = settingsRepo.get()
            val plans    = savedPlanRepo.getAll()
            val timeUntil = settings?.let {
                if (it.alarmEnabled) alarmScheduler.timeUntilDisplay(it.alarmHour, it.alarmMinute)
                else ""
            } ?: ""
            _state.update {
                it.copy(isLoading = false, settings = settings,
                    savedPlans = plans, alarmTimeUntil = timeUntil)
            }
        }
    }

    fun setSetting(key: String, value: Any) {
        viewModelScope.launch {
            val current = settingsRepo.get() ?: return@launch
            val updated = when (key) {
                "startDate"           -> current.copy(startDate = value as String)
                "dailyStudyHours"     -> {
                    val hrs = (value as Double).coerceIn(0.5, 24.0)
                    // Single subject: sync subject dailyHours
                    val subs = subjectRepo.getAll()
                    if (subs.size == 1) subjectRepo.update(subs[0].copy(dailyHours = hrs))
                    current.copy(dailyStudyHours = hrs)
                }
                "bufferDayOfWeek"     -> current.copy(bufferDayOfWeek = (value as Int))
                "weeklyGoalHours"     -> current.copy(weeklyGoalHours = (value as Double).coerceAtLeast(0.0))
                "interleaveSubjects"  -> current.copy(interleaveSubjects = value as Boolean)
                "intensityRampEnabled"-> current.copy(intensityRampEnabled = value as Boolean)
                "intensityStartHours" -> current.copy(intensityStartHours = (value as Double).coerceIn(1.0, 24.0))
                "intensityEndHours"   -> current.copy(intensityEndHours = (value as Double).coerceIn(1.0, 24.0))
                "examLockDays"        -> current.copy(examLockDays = (value as Int).coerceIn(0, 30))
                else -> return@launch
            }
            settingsRepo.upsert(updated)
            schedulerEngine.buildSchedule(forceRebuildToday = true)
            statsEngine.invalidate()
            _toast.emit("Saved!")
            load()
        }
    }

    fun toggleAlarm(enabled: Boolean) {
        viewModelScope.launch {
            val settings = settingsRepo.get() ?: return@launch
            settingsRepo.upsert(settings.copy(alarmEnabled = enabled))
            if (enabled) alarmScheduler.schedule(settings.alarmHour, settings.alarmMinute)
            else         alarmScheduler.cancel()
            load()
        }
    }

    fun setAlarmTime(hour: Int, minute: Int) {
        viewModelScope.launch {
            val settings = settingsRepo.get() ?: return@launch
            settingsRepo.upsert(settings.copy(alarmHour = hour, alarmMinute = minute))
            if (settings.alarmEnabled) alarmScheduler.schedule(hour, minute)
            load()
        }
    }

    fun toggleNotif(enabled: Boolean) {
        viewModelScope.launch {
            val settings = settingsRepo.get() ?: return@launch
            settingsRepo.upsert(settings.copy(notifEnabled = enabled))
            if (enabled) notifScheduler.schedule(settings.notifHour)
            else         notifScheduler.cancel()
            load()
        }
    }

    fun setNotifHour(hour: Int) {
        viewModelScope.launch {
            val settings = settingsRepo.get() ?: return@launch
            settingsRepo.upsert(settings.copy(notifHour = hour))
            if (settings.notifEnabled) notifScheduler.schedule(hour)
            load()
        }
    }

    // ── Multi-plan ────────────────────────────────────────────────
    fun saveCurrentPlan(name: String) {
        viewModelScope.launch {
            multiPlanMgr.save(name)
            _toast.emit("Plan \"$name\" saved!")
            load()
        }
    }

    fun loadPlan(id: String) {
        viewModelScope.launch {
            multiPlanMgr.load(id)
            statsEngine.invalidate()
            _toast.emit("Plan loaded!")
            load()
        }
    }

    fun deletePlan(id: String) {
        viewModelScope.launch {
            multiPlanMgr.delete(id)
            _toast.emit("Plan deleted")
            load()
        }
    }

    fun newBlankPlan(name: String) {
        viewModelScope.launch {
            multiPlanMgr.newBlank(name)
            statsEngine.invalidate()
            _toast.emit("New plan \"$name\" created!")
            load()
        }
    }

    // ── Export ────────────────────────────────────────────────────
    fun exportJson() {
        viewModelScope.launch {
            runCatching {
                val intent = dataExporter.buildJsonShareIntent()
                _shareIntent.emit(intent)
            }.onFailure { _toast.emit("Export failed: ${it.message}") }
        }
    }

    fun exportPdf() {
        viewModelScope.launch {
            _printRequest.emit(Unit)
        }
    }

    suspend fun doPrint(activity: Activity) {
        runCatching { dataExporter.printReport(activity) }
            .onFailure { _toast.emit("Print failed: ${it.message}") }
    }

    // ── Import ────────────────────────────────────────────────────
    fun importJson(uri: android.net.Uri) {
        viewModelScope.launch {
            val json = dataImporter.readBackupFromUri(uri)
            if (json == null || !dataImporter.validateJson(json)) {
                _toast.emit("Invalid backup file")
                return@launch
            }
            val result = dataImporter.importBackup(json)
            _importResult.emit(result)
            if (result is ImportResult.Success) {
                _toast.emit(result.message)
                load()
            }
        }
    }

    // ── Reset ─────────────────────────────────────────────────────
    fun resetApp() {
        viewModelScope.launch {
            scheduleRepo.deleteAll()
            noteRepo.deleteAll()
            sessionRepo.deleteAll()
            lectureRepo.deleteAll()
            subjectRepo.deleteAll()
            settingsRepo.deleteAll()
            metaRepo.deleteAll()
            statsEngine.invalidate()
            _toast.emit("App reset — please restart")
            load()
        }
    }
}
