@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
package com.studyplan.app.ui.screens.flashcards

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studyplan.app.domain.model.*
import com.studyplan.app.domain.repository.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class FlashCard(
    val front:      String,   // lecture name
    val back:       String,   // key-point note text (may contain HTML)
    val subjectName: String,
    val subjectColor: String,
    val lectureId:  String,
    val noteId:     String,
)

data class FlashcardsUiState(
    val isLoading:     Boolean         = true,
    val deck:          List<FlashCard> = emptyList(),
    val currentIndex:  Int             = 0,
    val isFlipped:     Boolean         = false,
    val isShuffled:    Boolean         = false,
    val filterSubId:   String?         = null,
    val subjects:      List<Subject>   = emptyList(),
    val totalInDeck:   Int             = 0,
)

@HiltViewModel
class FlashcardsViewModel @Inject constructor(
    private val noteRepo:    NoteRepository,
    private val lectureRepo: LectureRepository,
    private val subjectRepo: SubjectRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(FlashcardsUiState())
    val state: StateFlow<FlashcardsUiState> = _state.asStateFlow()

    private var originalDeck: List<FlashCard> = emptyList()

    init { load() }

    fun load(filterSubId: String? = _state.value.filterSubId) {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            val subjects = subjectRepo.getAll()
            val lectures = lectureRepo.getAll()
            val subMap   = subjects.associateBy { it.id }

            // Build deck from KEY type notes only — matching HTML flashcards logic
            val deck = lectures
                .filter { filterSubId == null || it.subjectId == filterSubId }
                .flatMap { lec ->
                    val sub   = subMap[lec.subjectId] ?: return@flatMap emptyList()
                    val notes = noteRepo.getKeyPointsForLecture(lec.id)
                    notes.map { note ->
                        FlashCard(
                            front        = lec.name,
                            back         = note.text,
                            subjectName  = sub.name,
                            subjectColor = sub.color,
                            lectureId    = lec.id,
                            noteId       = note.id,
                        )
                    }
                }

            originalDeck = deck
            val cur = _state.value
            val finalDeck = if (cur.isShuffled) deck.shuffled() else deck

            _state.update {
                it.copy(
                    isLoading    = false,
                    deck         = finalDeck,
                    currentIndex = 0,
                    isFlipped    = false,
                    filterSubId  = filterSubId,
                    subjects     = subjects,
                    totalInDeck  = finalDeck.size,
                )
            }
        }
    }

    fun setFilter(subId: String?) = load(subId)

    fun flipCard() {
        _state.update { it.copy(isFlipped = !it.isFlipped) }
    }

    fun next() {
        _state.update { s ->
            if (s.deck.isEmpty()) return@update s
            s.copy(
                currentIndex = (s.currentIndex + 1) % s.deck.size,
                isFlipped    = false,
            )
        }
    }

    fun previous() {
        _state.update { s ->
            if (s.deck.isEmpty()) return@update s
            s.copy(
                currentIndex = (s.currentIndex - 1 + s.deck.size) % s.deck.size,
                isFlipped    = false,
            )
        }
    }

    fun shuffle() {
        val isNowShuffled = !_state.value.isShuffled
        val newDeck = if (isNowShuffled) originalDeck.shuffled() else originalDeck
        _state.update {
            it.copy(
                deck         = newDeck,
                isShuffled   = isNowShuffled,
                currentIndex = 0,
                isFlipped    = false,
            )
        }
    }
}
