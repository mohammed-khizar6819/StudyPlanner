package com.studyplan.app.ui.screens.notes

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.sp

/**
 * Converts the simple HTML subset used by the rich-text note editor
 * into a Compose AnnotatedString.
 *
 * Supported tags (same as HTML execCommand output):
 *   <b>, <strong>  → bold
 *   <i>, <em>      → italic
 *   <u>            → underline
 *   <br>, <p>, <div> → newline
 *   <ul>, <ol>, <li> → bullet/numbered list items
 *   <blockquote>   → indented text
 *   All other tags stripped, plain text preserved.
 *
 * For plain-text notes (no HTML tags), returns the text as-is.
 */
fun htmlToAnnotatedString(html: String): AnnotatedString {
    if (html.isBlank()) return AnnotatedString("")
    // Fast path: no tags at all
    if (!html.contains('<')) return AnnotatedString(html)

    return buildAnnotatedString {
        var i = 0
        var listCounter = 0
        var inOrderedList = false
        val stack = ArrayDeque<String>()  // tracks open tags for style application

        while (i < html.length) {
            if (html[i] == '<') {
                val end = html.indexOf('>', i)
                if (end == -1) { append(html[i]); i++; continue }
                val tag = html.substring(i + 1, end).trim().lowercase()
                val isClose = tag.startsWith('/')
                val tagName = if (isClose) tag.substring(1).trim() else tag.split(" ")[0]

                when {
                    // Inline open tags — push style
                    !isClose && tagName in listOf("b", "strong") -> {
                        stack.addLast(tagName)
                        pushStyle(SpanStyle(fontWeight = FontWeight.Bold))
                    }
                    !isClose && tagName in listOf("i", "em") -> {
                        stack.addLast(tagName)
                        pushStyle(SpanStyle(fontStyle = FontStyle.Italic))
                    }
                    !isClose && tagName == "u" -> {
                        stack.addLast(tagName)
                        pushStyle(SpanStyle(textDecoration = TextDecoration.Underline))
                    }
                    !isClose && tagName == "blockquote" -> {
                        stack.addLast(tagName)
                        pushStyle(SpanStyle(fontStyle = FontStyle.Italic,
                            letterSpacing = 0.sp))
                        append("  ")  // indent
                    }
                    // Close tags — pop style
                    isClose && tagName in listOf("b","strong","i","em","u","blockquote") -> {
                        if (stack.isNotEmpty()) {
                            stack.removeLastOrNull()
                            pop()
                        }
                    }
                    // Block / list elements → newlines
                    !isClose && tagName in listOf("br") ->
                        append('\n')
                    !isClose && tagName in listOf("p","div") -> {
                        if (length > 0 && last() != '\n') append('\n')
                    }
                    isClose && tagName in listOf("p","div") ->
                        if (length > 0 && last() != '\n') append('\n')
                    !isClose && tagName == "ul" ->
                        inOrderedList = false
                    !isClose && tagName == "ol" -> {
                        inOrderedList = true
                        listCounter = 0
                    }
                    isClose && tagName in listOf("ul","ol") -> {
                        inOrderedList = false
                        listCounter = 0
                    }
                    !isClose && tagName == "li" -> {
                        if (length > 0 && last() != '\n') append('\n')
                        if (inOrderedList) {
                            listCounter++
                            append("$listCounter. ")
                        } else {
                            append("• ")
                        }
                    }
                    isClose && tagName == "li" ->
                        if (length > 0 && last() != '\n') append('\n')
                    // Ignore all other tags (strip them)
                }
                i = end + 1
            } else {
                // Decode common HTML entities
                when {
                    html.startsWith("&amp;",  i) -> { append('&');  i += 5 }
                    html.startsWith("&lt;",   i) -> { append('<');  i += 4 }
                    html.startsWith("&gt;",   i) -> { append('>');  i += 4 }
                    html.startsWith("&nbsp;", i) -> { append(' ');  i += 6 }
                    html.startsWith("&#39;",  i) -> { append('\''); i += 5 }
                    html.startsWith("&quot;", i) -> { append('"');  i += 6 }
                    else -> { append(html[i]); i++ }
                }
            }
        }
        // Clean up trailing whitespace
    }.let { annotated ->
        val trimmed = annotated.text.trimEnd()
        if (trimmed.length == annotated.text.length) annotated
        else AnnotatedString(trimmed, annotated.spanStyles, annotated.paragraphStyles)
    }
}
