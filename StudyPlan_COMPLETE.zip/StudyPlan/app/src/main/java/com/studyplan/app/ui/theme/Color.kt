package com.studyplan.app.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

// ═══════════════════════════════════════════════════════════════════
//  RAW COLOR PALETTE
//  These are the exact hex values from the HTML CSS variables.
//  Never use these directly in composables — use StudyPlanColors.
// ═══════════════════════════════════════════════════════════════════

// Neutrals
internal val Raw_FAFAFA = Color(0xFFFAFAFA)
internal val Raw_FFFFFF = Color(0xFFFFFFFF)
internal val Raw_F5F5F5 = Color(0xFFF5F5F5)
internal val Raw_F0F0F0 = Color(0xFFF0F0F0)
internal val Raw_E8E8E8 = Color(0xFFE8E8E8)
internal val Raw_D0D0D0 = Color(0xFFD0D0D0)
internal val Raw_111111 = Color(0xFF111111)
internal val Raw_555555 = Color(0xFF555555)
internal val Raw_999999 = Color(0xFF999999)

internal val Raw_1A1A1A = Color(0xFF1A1A1A)
internal val Raw_222222 = Color(0xFF222222)
internal val Raw_2A2A2A = Color(0xFF2A2A2A)
internal val Raw_2E2E2E = Color(0xFF2E2E2E)
internal val Raw_3A3A3A = Color(0xFF3A3A3A)
internal val Raw_EEEEEE = Color(0xFFEEEEEE)
internal val Raw_AAAAAA = Color(0xFFAAAAAA)
internal val Raw_666666 = Color(0xFF666666)

// Semantic colors
internal val Raw_Green_Light  = Color(0xFF16a34a)
internal val Raw_Red_Light    = Color(0xFFdc2626)
internal val Raw_Yellow_Light = Color(0xFFca8a04)
internal val Raw_Blue_Light   = Color(0xFF2563eb)

internal val Raw_Green_Dark   = Color(0xFF22c55e)
internal val Raw_Red_Dark     = Color(0xFFef4444)
internal val Raw_Yellow_Dark  = Color(0xFFeab308)
internal val Raw_Blue_Dark    = Color(0xFF60a5fa)

// Subject color palette (the COLORS array from HTML)
val SubjectColors = listOf(
    Color(0xFF374151), // neutral gray
    Color(0xFF6366f1), // indigo
    Color(0xFF0891b2), // cyan
    Color(0xFF059669), // emerald
    Color(0xFF7c3aed), // violet
    Color(0xFFdb2777), // pink
    Color(0xFFd97706), // amber
    Color(0xFF16a34a), // green
)

// ═══════════════════════════════════════════════════════════════════
//  STUDYPLAN COLORS — Semantic token container
//  Maps 1-to-1 with CSS custom properties on :root and [data-theme="dark"]
//  Access via: MaterialTheme.studyColors
// ═══════════════════════════════════════════════════════════════════

@Immutable
data class StudyPlanColors(
    // ── Backgrounds ───────────────────────────────────────────────
    val bg: Color,
    val surface: Color,
    val surface2: Color,
    val hover: Color,

    // ── Borders ───────────────────────────────────────────────────
    val border: Color,
    val borderStrong: Color,

    // ── Text ──────────────────────────────────────────────────────
    val text: Color,
    val text2: Color,
    val text3: Color,

    // ── Primary (black light / white dark) ────────────────────────
    val primary: Color,
    val primaryL: Color,        // primary tinted background
    val primaryX: Color,        // primary at 5–6% opacity
    val onPrimary: Color,       // text on filled primary button
    val focusRing: Color,
    val focusBorder: Color,

    // ── Semantic status colors ─────────────────────────────────────
    val green: Color,
    val greenX: Color,          // green at ~8% opacity
    val red: Color,
    val redX: Color,
    val yellow: Color,
    val yellowX: Color,
    val blue: Color,
    val blueX: Color,

    // ── Semantic composites ───────────────────────────────────────
    val alertWarnBg: Color,
    val alertWarnText: Color,
    val alertErrorBg: Color,
    val cardDoneBg: Color,
    val missedRowBg: Color,
    val missedRowBd: Color,
    val wrMissedBorder: Color,
    val wrGreatBorder: Color,
    val checkBtnBg: Color,
    val checkBtnBorder: Color,

    // ── Heatmap scale ─────────────────────────────────────────────
    val heat0: Color,           // empty / lightest
    val heat1: Color,
    val heat2: Color,
    val heat3: Color,
    val heat4: Color,           // most active / darkest

    // ── Meta ──────────────────────────────────────────────────────
    val isDark: Boolean,
)

// ═══════════════════════════════════════════════════════════════════
//  LIGHT THEME — exact match of :root CSS block
// ═══════════════════════════════════════════════════════════════════

val LightStudyPlanColors = StudyPlanColors(
    bg            = Raw_FAFAFA,
    surface       = Raw_FFFFFF,
    surface2      = Raw_F5F5F5,
    hover         = Raw_F0F0F0,
    border        = Raw_E8E8E8,
    borderStrong  = Raw_D0D0D0,
    text          = Raw_111111,
    text2         = Raw_555555,
    text3         = Raw_999999,
    primary       = Raw_111111,
    primaryL      = Raw_F5F5F5,
    primaryX      = Raw_111111.copy(alpha = 0.05f),
    onPrimary     = Raw_FFFFFF,
    focusRing     = Raw_111111.copy(alpha = 0.10f),
    focusBorder   = Raw_111111.copy(alpha = 0.30f),

    green         = Raw_Green_Light,
    greenX        = Raw_Green_Light.copy(alpha = 0.08f),
    red           = Raw_Red_Light,
    redX          = Raw_Red_Light.copy(alpha = 0.08f),
    yellow        = Raw_Yellow_Light,
    yellowX       = Raw_Yellow_Light.copy(alpha = 0.08f),
    blue          = Raw_Blue_Light,
    blueX         = Raw_Blue_Light.copy(alpha = 0.08f),

    alertWarnBg   = Raw_111111.copy(alpha = 0.05f),
    alertWarnText = Raw_555555,
    alertErrorBg  = Raw_Red_Light.copy(alpha = 0.08f),
    cardDoneBg    = Raw_Green_Light.copy(alpha = 0.05f),
    missedRowBg   = Raw_Red_Light.copy(alpha = 0.05f),
    missedRowBd   = Raw_Red_Light.copy(alpha = 0.12f),
    wrMissedBorder = Raw_Red_Light.copy(alpha = 0.15f),
    wrGreatBorder  = Raw_Green_Light.copy(alpha = 0.15f),
    checkBtnBg     = Raw_Green_Light.copy(alpha = 0.08f),
    checkBtnBorder = Raw_Green_Light.copy(alpha = 0.20f),

    heat0 = Raw_F0F0F0,
    heat1 = Raw_D0D0D0,
    heat2 = Color(0xFF909090),
    heat3 = Color(0xFF505050),
    heat4 = Raw_111111,

    isDark = false,
)

// ═══════════════════════════════════════════════════════════════════
//  DARK THEME — exact match of [data-theme="dark"] CSS block
// ═══════════════════════════════════════════════════════════════════

val DarkStudyPlanColors = StudyPlanColors(
    bg            = Raw_111111,
    surface       = Raw_1A1A1A,
    surface2      = Raw_222222,
    hover         = Raw_2A2A2A,
    border        = Raw_2E2E2E,
    borderStrong  = Raw_3A3A3A,
    text          = Raw_EEEEEE,
    text2         = Raw_AAAAAA,
    text3         = Raw_666666,
    primary       = Raw_EEEEEE,
    primaryL      = Raw_EEEEEE.copy(alpha = 0.06f),
    primaryX      = Raw_EEEEEE.copy(alpha = 0.06f),
    onPrimary     = Raw_111111,
    focusRing     = Raw_EEEEEE.copy(alpha = 0.12f),
    focusBorder   = Raw_EEEEEE.copy(alpha = 0.28f),

    green         = Raw_Green_Dark,
    greenX        = Raw_Green_Dark.copy(alpha = 0.10f),
    red           = Raw_Red_Dark,
    redX          = Raw_Red_Dark.copy(alpha = 0.10f),
    yellow        = Raw_Yellow_Dark,
    yellowX       = Raw_Yellow_Dark.copy(alpha = 0.10f),
    blue          = Raw_Blue_Dark,
    blueX         = Raw_Blue_Dark.copy(alpha = 0.10f),

    alertWarnBg   = Raw_EEEEEE.copy(alpha = 0.06f),
    alertWarnText = Color(0xFF888888),
    alertErrorBg  = Raw_Red_Dark.copy(alpha = 0.10f),
    cardDoneBg    = Raw_Green_Dark.copy(alpha = 0.05f),
    missedRowBg   = Raw_Red_Dark.copy(alpha = 0.06f),
    missedRowBd   = Raw_Red_Dark.copy(alpha = 0.15f),
    wrMissedBorder = Raw_Red_Dark.copy(alpha = 0.20f),
    wrGreatBorder  = Raw_Green_Dark.copy(alpha = 0.20f),
    checkBtnBg     = Raw_Green_Dark.copy(alpha = 0.10f),
    checkBtnBorder = Raw_Green_Dark.copy(alpha = 0.22f),

    heat0 = Raw_222222,
    heat1 = Color(0xFF333333),
    heat2 = Color(0xFF555555),
    heat3 = Color(0xFF888888),
    heat4 = Raw_EEEEEE,

    isDark = true,
)

// ═══════════════════════════════════════════════════════════════════
//  COMPOSITION LOCAL
//  Usage anywhere: val colors = LocalStudyPlanColors.current
//         or via: MaterialTheme.studyColors
// ═══════════════════════════════════════════════════════════════════

val LocalStudyPlanColors = staticCompositionLocalOf<StudyPlanColors> {
    LightStudyPlanColors
}
