package com.studyplan.app.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.studyplan.app.data.db.dao.*
import com.studyplan.app.data.db.entity.*

@Database(
    entities = [
        SubjectEntity::class,
        LectureEntity::class,
        ScheduleEntryEntity::class,
        NoteEntity::class,
        SessionLogEntity::class,
        SettingsEntity::class,
        MetaEntity::class,
        SavedPlanEntity::class,
    ],
    version  = 1,
    exportSchema = true,
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun subjectDao():       SubjectDao
    abstract fun lectureDao():       LectureDao
    abstract fun scheduleEntryDao(): ScheduleEntryDao
    abstract fun noteDao():          NoteDao
    abstract fun sessionLogDao():    SessionLogDao
    abstract fun settingsDao():      SettingsDao
    abstract fun metaDao():          MetaDao
    abstract fun savedPlanDao():     SavedPlanDao

    companion object {
        const val DATABASE_NAME = "studyplan_db"
        const val MAX_SESSION_LOGS = 1000
    }
}
