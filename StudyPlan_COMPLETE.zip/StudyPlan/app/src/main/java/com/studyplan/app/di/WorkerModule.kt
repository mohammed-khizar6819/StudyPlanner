package com.studyplan.app.di

import android.content.Context
import com.studyplan.app.alarm.AlarmScheduler
import com.studyplan.app.worker.MidnightRebuildScheduler
import com.studyplan.app.worker.NotifWorkerScheduler
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object WorkerModule {

    @Provides @Singleton
    fun provideAlarmScheduler(@ApplicationContext ctx: Context) = AlarmScheduler(ctx)

    @Provides @Singleton
    fun provideMidnightRebuildScheduler(@ApplicationContext ctx: Context) =
        MidnightRebuildScheduler(ctx)

    @Provides @Singleton
    fun provideNotifWorkerScheduler(@ApplicationContext ctx: Context) =
        NotifWorkerScheduler(ctx)
}
