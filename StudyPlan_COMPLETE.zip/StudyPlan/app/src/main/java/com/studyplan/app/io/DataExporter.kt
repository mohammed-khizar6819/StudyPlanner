package com.studyplan.app.io

import android.content.Context
import android.content.Intent
import android.webkit.WebView
import android.webkit.WebViewClient
import android.print.PrintAttributes
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import com.studyplan.app.data.db.entity.*
import com.studyplan.app.data.json.BackupMapper
import com.studyplan.app.data.json.StudyPlanBackup
import com.studyplan.app.domain.engine.StatsEngine
import com.studyplan.app.domain.engine.TimeUtils
import com.studyplan.app.domain.repository.*
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DataExporter @Inject constructor(
    @ApplicationContext private val context: Context,
    private val subjectRepo:  SubjectRepository,
    private val lectureRepo:  LectureRepository,
    private val scheduleRepo: ScheduleRepository,
    private val noteRepo:     NoteRepository,
    private val sessionRepo:  SessionLogRepository,
    private val settingsRepo: SettingsRepository,
    private val metaRepo:     MetaRepository,
    private val statsEngine:  StatsEngine,
) {
    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    private val adapter = moshi.adapter(StudyPlanBackup::class.java).indent("  ")

    // ── JSON Export ───────────────────────────────────────────────
    /** Builds JSON backup string — full studyPlanner_v3 compatible format */
    suspend fun buildJsonBackup(): String = withContext(Dispatchers.IO) {
        val settings = settingsRepo.get()
        val meta     = metaRepo.get()
        val subjects = subjectRepo.getAll()
        val lectures = lectureRepo.getAll()
        val entries  = scheduleRepo.getInRange("2000-01-01", "2099-12-31")
        val notes    = noteRepo.getAll()
        val logs     = sessionRepo.getAll()

        val backup = BackupMapper.toBackup(
            settings?.let { SettingsEntity.fromDomain(it) },
            meta?.let { MetaEntity.fromDomain(it) },
            subjects.map { SubjectEntity.fromDomain(it) },
            lectures.map { LectureEntity.fromDomain(it) },
            entries.map  { ScheduleEntryEntity.fromDomain(it) },
            notes.map    { NoteEntity.fromDomain(it) },
            logs.map     { SessionLogEntity.fromDomain(it) },
        )
        adapter.toJson(backup)
    }

    /** Saves JSON to file and returns a content URI for sharing */
    suspend fun exportJsonToFile(): android.net.Uri = withContext(Dispatchers.IO) {
        val json = buildJsonBackup()
        val dir  = File(context.getExternalFilesDir(null), "studyplan_exports")
            .also { it.mkdirs() }
        val file = File(dir, "studyplan_backup_${TimeUtils.today()}.json")
        file.writeText(json)
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    /** Builds the share intent for JSON export */
    suspend fun buildJsonShareIntent(): Intent {
        val uri = exportJsonToFile()
        return Intent(Intent.ACTION_SEND).apply {
            type        = "application/json"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "StudyPlan Backup ${TimeUtils.today()}")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    // ── PDF Report Export ─────────────────────────────────────────
    /** Builds the HTML report string — identical to HTML exportPDF() */
    suspend fun buildReportHtml(): String = withContext(Dispatchers.IO) {
        val stats    = statsEngine.getStats()
        val subjects = subjectRepo.getAll()
        val lectures = lectureRepo.getAll()
        val settings = settingsRepo.get()
        val today    = TimeUtils.today()

        val subjectRows = subjects.joinToString("") { sub ->
            val ss = stats.subjectStats.find { it.id == sub.id }
            "<tr><td>${sub.fullName.ifEmpty { sub.name }}</td>" +
            "<td>${ss?.completedCount ?: 0}/${ss?.totalCount ?: 0}</td>" +
            "<td>${ss?.pct ?: 0}%</td>" +
            "<td>${if (sub.deadline.isNotEmpty()) TimeUtils.formatDisplay(sub.deadline) else "—"}</td></tr>"
        }

        val recentRows = lectures
            .filter { it.status.value == "complete" && it.completedOn != null }
            .sortedByDescending { it.completedOn }
            .take(10)
            .joinToString("") { lec ->
                val sub = subjects.find { it.id == lec.subjectId }
                "<tr><td>[${sub?.name ?: "?"}] ${lec.name}</td>" +
                "<td>${TimeUtils.toHMS(lec.duration)}</td>" +
                "<td>${TimeUtils.formatDisplay(lec.completedOn ?: "")}</td></tr>"
            }

        """<!DOCTYPE html><html><head><title>StudyPlan Report</title>
<style>
  body{font-family:system-ui,sans-serif;color:#1a1a1a;padding:32px;max-width:800px;margin:0 auto;font-size:13px}
  h1{font-size:22px;margin-bottom:4px;letter-spacing:-.03em}
  h2{font-size:14px;margin:20px 0 8px;text-transform:uppercase;letter-spacing:.08em;color:#666;font-weight:700}
  table{width:100%;border-collapse:collapse;margin-bottom:14px}
  th,td{text-align:left;padding:7px 10px;border-bottom:1px solid #eee;font-size:12px}
  th{background:#f5f5f3;font-weight:700;font-size:11px;text-transform:uppercase;letter-spacing:.05em}
  .stat-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px}
  .stat-box{background:#f5f5f3;border-radius:8px;padding:14px;text-align:center}
  .stat-val{font-size:20px;font-weight:800;letter-spacing:-.04em;color:#111111}
  .stat-lbl{font-size:10px;text-transform:uppercase;letter-spacing:.08em;color:#888;font-weight:700;margin-top:2px}
  @media print{button{display:none}}
</style></head><body>
<h1>📚 StudyPlan Report</h1>
<p style="color:#888;font-size:12px">Generated ${TimeUtils.formatDisplay(today)}${
    if (settings?.startDate?.isNotEmpty() == true) " · Started " + TimeUtils.formatDisplay(settings.startDate) else ""
}</p>
<div class="stat-grid">
  <div class="stat-box"><div class="stat-val">${stats.pct}%</div><div class="stat-lbl">Overall</div></div>
  <div class="stat-box"><div class="stat-val">${lectures.count { it.status.value == "complete" }}</div><div class="stat-lbl">Done</div></div>
  <div class="stat-box"><div class="stat-val">${TimeUtils.toDisplay(stats.completedSecs)}</div><div class="stat-lbl">Studied</div></div>
  <div class="stat-box"><div class="stat-val">${stats.studyDaysLeft}</div><div class="stat-lbl">Days Left</div></div>
</div>
<h2>Subject Progress</h2>
<table><thead><tr><th>Subject</th><th>Completed</th><th>%</th><th>Deadline</th></tr></thead>
<tbody>$subjectRows</tbody></table>
${if (recentRows.isNotEmpty()) """<h2>Recently Completed (last 10)</h2>
<table><thead><tr><th>Lecture</th><th>Duration</th><th>Completed</th></tr></thead>
<tbody>$recentRows</tbody></table>""" else ""}
<p style="color:#aaa;font-size:11px;margin-top:24px">StudyPlan — Exam Tracker</p>
</body></html>"""
    }

    /** Prints the report using Android PrintManager (system print/PDF dialog) */
    suspend fun printReport(activity: android.app.Activity) {
        val html = buildReportHtml()
        withContext(Dispatchers.Main) {
            val webView = WebView(activity)
            webView.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    val printManager = activity.getSystemService(Context.PRINT_SERVICE) as PrintManager
                    val printAdapter = view.createPrintDocumentAdapter("StudyPlan_Report_${TimeUtils.today()}")
                    printManager.print(
                        "StudyPlan Report",
                        printAdapter,
                        PrintAttributes.Builder().build(),
                    )
                }
            }
            webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
        }
    }
}
